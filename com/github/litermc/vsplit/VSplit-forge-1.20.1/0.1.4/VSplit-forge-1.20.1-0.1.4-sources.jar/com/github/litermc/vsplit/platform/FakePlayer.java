// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vsplit.platform;

import com.github.litermc.vsplit.Constants;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class FakePlayer extends net.minecraftforge.common.util.FakePlayer {
	private static final EntityDimensions DIMENSIONS = EntityDimensions.m_20398_(0, 0);

	private FakePlayer(ServerLevel serverLevel, GameProfile gameProfile) {
		super(serverLevel, gameProfile);
		this.m_20331_(true);
		this.m_6210_();
	}

	static FakePlayer create(ServerLevel serverLevel, GameProfile profile) {
		return new FakePlayer(serverLevel, profile);
	}

	@Override
	protected int m_8088_() {
		return 0;
	}

	@Override
	public boolean m_6459_(ServerPlayer player) {
		return false;
	}

	@Override
	public boolean m_6097_() {
		return false;
	}

	@Override
	public boolean m_20147_() {
		return true;
	}

	@Override
	public boolean m_142066_() {
		return false;
	}

	@Override
	public boolean m_142065_() {
		return false;
	}

	@Override
	public boolean m_6087_() {
		return false;
	}

	@Override
	public boolean m_6094_() {
		return false;
	}

	@Override
	public boolean m_20145_() {
		return true;
	}

	@Override
	public boolean m_5801_() {
		return false;
	}

	@Override
	public boolean m_5789_() {
		return false;
	}

	@Override
	public boolean m_7066_(final ItemStack stack) {
		return false;
	}

	@Override
	public EntityDimensions m_6972_(final Pose pose) {
		return DIMENSIONS;
	}

	@Override
	public float m_20236_(final Pose pose) {
		return 0;
	}

	@Override
	public float m_6431_(final Pose pose, final EntityDimensions dims) {
		return 0;
	}

	@Override
	public void m_8119_() {
	}
}
