package com.github.litermc.vsplit.util;

import com.github.litermc.vtil.api.assemble.AssembleApi;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

import org.valkyrienskies.core.api.ships.ServerShip;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;

public final class AssembleUtil {
	private AssembleUtil() {}

	private static final Direction[] NO_DOWN_DIRECTIONS = new Direction[]{
		Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST,
	};
	private static final Direction[] HORIZONTAL_DIRECTIONS = new Direction[]{
		Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST,
	};
	private static final Vec3i[] NO_DOWN_CORNER_OFFSETS = new Vec3i[]{
		new Vec3i(0, 0, 1),
		new Vec3i(0, 0, -1),
		new Vec3i(0, 1, 0),
		new Vec3i(0, 1, 1),
		new Vec3i(0, 1, -1),
		new Vec3i(1, 0, 0),
		new Vec3i(1, 0, 1),
		new Vec3i(1, 0, -1),
		new Vec3i(1, 1, 0),
		new Vec3i(1, 1, 1),
		new Vec3i(1, 1, -1),
		new Vec3i(-1, 0, 0),
		new Vec3i(-1, 0, 1),
		new Vec3i(-1, 0, -1),
		new Vec3i(-1, 1, 0),
		new Vec3i(-1, 1, 1),
		new Vec3i(-1, 1, -1)
	};

	public static ServerShip assembleTree(final ServerLevel level, final BlockPos pos, final BlockState original) {
		final List<BlockPos> blocks = findTreeBlocks(level, pos, original.m_60734_());
		if (blocks.size() == 0) {
			return null;
		}
		return AssembleApi.createShip(level, Set.copyOf(blocks));
	}

	private static List<BlockPos> findTreeBlocks(final ServerLevel level, final BlockPos pos, final Block block) {
		final List<BlockPos> blocks = findTreeLogs(level, pos, block);
		final Set<BlockPos> logs = new HashSet<>(blocks);
		final Set<BlockPos> accessed = new HashSet<>(logs);
		final Queue<Pair<BlockPos, Integer>> queue = new ArrayDeque<>();
		accessed.add(pos);
		Stream.of(HORIZONTAL_DIRECTIONS)
			.map(pos::m_121945_)
			.filter(Predicate.not(accessed::contains))
			.peek(accessed::add)
			.map(p -> new Pair<>(p, 0))
			.forEach(queue::add);
		for (final BlockPos logPos : blocks) {
			Stream.of(NO_DOWN_DIRECTIONS)
				.map(logPos::m_121945_)
				.filter(Predicate.not(accessed::contains))
				.peek(accessed::add)
				.map(p -> new Pair<>(p, 0))
				.forEach(queue::add);
		}
		while (!queue.isEmpty()) {
			final Pair<BlockPos, Integer> pair = queue.remove();
			final BlockPos p = pair.left();
			final int dist = pair.right() + 1;
			final BlockState st = level.m_8055_(p);
			if (!st.m_204336_(BlockTags.f_13035_) || st.m_61145_(LeavesBlock.f_54419_).orElse(true)) {
				continue;
			}
			if (dist > st.m_61145_(LeavesBlock.f_54418_).orElse(0)) {
				continue;
			}
			final boolean invalid = Direction.m_235666_()
				.map(p::m_121945_)
				.filter(Predicate.not(logs::contains))
				.map(level::m_8055_)
				.anyMatch(s1 -> s1.m_204336_(BlockTags.f_215839_));
			if (invalid) {
				continue;
			}
			blocks.add(p);
			if (dist < 7) {
				Direction.m_235666_()
					.map(p::m_121945_)
					.filter(Predicate.not(accessed::contains))
					.peek(accessed::add)
					.map(p1 -> new Pair<>(p1, dist))
					.forEach(queue::add);
			}
		}
		return blocks;
	}

	private static List<BlockPos> findTreeLogs(final ServerLevel level, final BlockPos pos, final Block block) {
		final Set<BlockPos> accessed = new HashSet<>();
		final List<BlockPos> blocks = new ArrayList<>();
		final Deque<BlockPos> deque = new ArrayDeque<>();
		deque.addLast(pos.m_7494_());
		while (!deque.isEmpty()) {
			final BlockPos p = deque.removeLast();
			final BlockState st = level.m_8055_(p);
			if (st.m_60734_() != block) {
				continue;
			}
			blocks.add(p);
			Stream.of(NO_DOWN_CORNER_OFFSETS)
				.map(p::m_121955_)
				.filter(Predicate.not(accessed::contains))
				.peek(accessed::add)
				.forEach(deque::addLast);
		}
		return blocks;
	}
}
