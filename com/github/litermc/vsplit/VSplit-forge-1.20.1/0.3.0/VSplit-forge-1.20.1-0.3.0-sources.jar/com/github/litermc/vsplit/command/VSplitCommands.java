package com.github.litermc.vsplit.command;

import com.github.litermc.vsplit.Constants;
import com.github.litermc.vsplit.api.clean.ShipCleaner;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.command.ShipArgument;
import org.valkyrienskies.mod.mixinducks.feature.command.VSCommandSource;

import java.util.Set;

public final class VSplitCommands {
	public static final String ROOT_LITERAL = Constants.MOD_ID;

	private VSplitCommands() {}

	public static void register(final CommandDispatcher<CommandSourceStack> dispatcher) {
		dispatcher.register(Commands.m_82127_(ROOT_LITERAL)
			.requires((source) -> source.m_6761_(2))
			.then(Commands.m_82127_("clean")
				.then(Commands.m_82129_("forceRemoval", BoolArgumentType.bool())
					.executes((ctx) -> VSplitCommands.clean(ctx, BoolArgumentType.getBool(ctx, "forceRemoval")))
				)
				.executes((ctx) -> VSplitCommands.clean(ctx, false))
			)
			.then(Commands.m_82127_("protect")
				.then(Commands.m_82129_("ships", ShipArgument.Companion.ships())
					.then(Commands.m_82129_("shouldProtect", BoolArgumentType.bool())
						.executes((ctx) -> VSplitCommands.protect(ctx, BoolArgumentType.getBool(ctx, "shouldProtect")))
					)
					.executes((ctx) -> VSplitCommands.protect(ctx, true))
				)
			)
		);
	}

	private static int clean(final CommandContext<CommandSourceStack> context, final boolean forceRemoval) throws CommandSyntaxException {
		final CommandSourceStack source = context.getSource();
		final MinecraftServer server = source.m_81377_();
		ShipCleaner.clean(server, forceRemoval);
		return 1;
	}

	private static int protect(final CommandContext<CommandSourceStack> context, final boolean shouldProtect) throws CommandSyntaxException {
		final CommandSourceStack source = context.getSource();
		final MinecraftServer server = source.m_81377_();
		final ServerShipWorldCore world = VSGameUtilsKt.getShipObjectWorld(server);
		final Set<Ship> ships = ShipArgument.Companion.getShips((CommandContext<VSCommandSource>) ((CommandContext<?>) (context)), "ships");
		int count = 0;
		for (final Ship ship : ships) {
			if (!(ship instanceof ServerShip serverShip)) {
				continue;
			}
			ShipCleaner.setShipProtected(serverShip, shouldProtect);
			count++;
		}
		final int finalCount = count;
		source.m_288197_(() -> Component.m_237110_("vsplit.command.protect.success", finalCount), false);
		return count;
	}
}
