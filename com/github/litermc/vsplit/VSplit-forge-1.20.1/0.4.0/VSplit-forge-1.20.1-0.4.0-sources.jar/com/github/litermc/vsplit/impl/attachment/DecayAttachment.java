package com.github.litermc.vsplit.impl.attachment;

import com.github.litermc.vsplit.api.attachment.ISplitListener;
import com.github.litermc.vsplit.config.Config;
import com.github.litermc.vsplit.config.DecayMethod;
import com.github.litermc.vsplit.util.ShipRandomTickGenerator;
import com.github.litermc.vtil.api.attachment.IServerTickListener;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.google.common.collect.ImmutableMap;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

@JsonAutoDetect(
	fieldVisibility = JsonAutoDetect.Visibility.NONE,
	isGetterVisibility = JsonAutoDetect.Visibility.NONE,
	getterVisibility = JsonAutoDetect.Visibility.NONE,
	setterVisibility = JsonAutoDetect.Visibility.NONE
)
public final class DecayAttachment implements IServerTickListener, ISplitListener {
	public static final String DECAY_PREFIX = "+decay+";
	private static final ImmutableMap<Block, Block> STAGED = addStagedDecayBlocks(new ImmutableMap.Builder<Block, Block>()).build();

	@JsonProperty("forceDecayCounter")
	private int forceDecayCounter;
	private final ShipRandomTickGenerator rnd = new ShipRandomTickGenerator(5, DecayAttachment::onRandomTick);

	private DecayAttachment() {
		this(-1);
	}

	public DecayAttachment(final int forceDecayCounter) {
		this.forceDecayCounter = forceDecayCounter;
	}

	@JsonGetter("decayRate")
	private int getDecayRate() {
		return this.rnd.getRate();
	}

	@JsonSetter("decayRate")
	private void setDecayRate(final int rate) {
		this.rnd.setRate(rate);
	}

	@Override
	public void onServerTick(final ServerLevel level, final LoadedServerShip ship) {
		final String slug = ship.getSlug();
		if (slug == null || !slug.startsWith(DECAY_PREFIX)) {
			ship.removeAttachment(DecayAttachment.class);
			return;
		}
		this.forceDecayCounter--;
		if (this.forceDecayCounter < 0) {
			ship.removeAttachment(DecayAttachment.class);
			VSGameUtilsKt.getShipObjectWorld(level).deleteShip(ship);
			return;
		}
		this.rnd.tick(level, ship);
	}

	@Override
	public void onShipSplit(final Context context) {
		if (Config.decayMethod == DecayMethod.NO_SPLIT) {
			final ServerLevel level = context.getLevel();
			context.getBlocks().forEach((pos) -> level.m_46961_(pos, true));
			return;
		}
		context.addAfterSplit((newShip) -> {
			newShip.setAttachment(new DecayAttachment(this.forceDecayCounter));
		});
	}

	private static ImmutableMap.Builder<Block, Block> addStagedDecayBlocks(final ImmutableMap.Builder<Block, Block> builder) {
		return builder
			.put(Blocks.f_50003_, Blocks.f_50008_)
			.put(Blocks.f_50001_, Blocks.f_50006_)
			.put(Blocks.f_271170_, Blocks.f_271326_)
			.put(Blocks.f_50695_, Blocks.f_50696_)
			.put(Blocks.f_50004_, Blocks.f_50009_)
			.put(Blocks.f_50002_, Blocks.f_50007_)
			.put(Blocks.f_220832_, Blocks.f_220835_)
			.put(Blocks.f_49999_, Blocks.f_50010_)
			.put(Blocks.f_50000_, Blocks.f_50005_)
			.put(Blocks.f_50686_, Blocks.f_50687_);
	}

	private static void onRandomTick(final ServerLevel level, final LoadedServerShip ship, final BlockPos pos, final BlockState state) {
		if (!state.m_60795_()) {
			destroyBlock(level, ship, pos);
		}
	}

	private static void destroyBlock(final ServerLevel level, final LoadedServerShip ship, final BlockPos pos) {
		final BlockState state = level.m_8055_(pos);
		final Block decayedBlock = STAGED.get(state.m_60734_());
		if (decayedBlock != null) {
			final BlockState[] newState = new BlockState[]{decayedBlock.m_49966_()};
			state.m_61148_().forEach((k, v) -> {
				newState[0] = trySetValue(newState[0], k, v);
			});
			level.m_7731_(pos, newState[0], Block.f_152402_);
			return;
		}
		level.m_46961_(pos, true);
	}

	private static <T extends Comparable<T>> BlockState trySetValue(
		final BlockState state,
		final Property<T> property,
		final Object value
	) {
		return state.m_263224_(property, (T) value);
	}
}
