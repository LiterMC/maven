package com.github.litermc.vsplit.impl.attachment;

import com.github.litermc.vtil.api.storage.IShipAdditionalData;
import com.github.litermc.vtil.api.storage.ShipDataStorage;
import net.minecraft.nbt.CompoundTag;
import org.valkyrienskies.core.api.ships.ServerShip;

public final class ShipCleanAttachment implements IShipAdditionalData {
	private boolean protecting = false;
	private boolean marked = false;

	public static ShipCleanAttachment get(final ServerShip ship) {
		return ShipDataStorage.get(ship).getOrCreate(ShipCleanAttachment.class);
	}

	public boolean isProtected() {
		return this.protecting;
	}

	public void setProtected(final boolean protecting) {
		this.protecting = protecting;
	}

	public boolean isMarked() {
		return this.marked;
	}

	public void setMarked(final boolean marked) {
		this.marked = marked;
	}

	@Override
	public void load(final CompoundTag data) {
		data.m_128379_("protected", this.protecting);
		data.m_128379_("marked", this.marked);
	}

	@Override
	public void save(final CompoundTag data) {
		this.protecting = data.m_128471_("protected");
		this.marked = data.m_128471_("marked");
	}
}
