// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vsplit.platform;

import com.github.litermc.vsplit.Constants;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4048;
import net.minecraft.class_4050;

public final class FakePlayer extends net.fabricmc.fabric.api.entity.FakePlayer {
	private static final class_4048 DIMENSIONS = class_4048.method_18385(0, 0);

	private FakePlayer(class_3218 serverLevel, GameProfile gameProfile) {
		super(serverLevel, gameProfile);
		this.method_5684(true);
		this.method_18382();
	}

	static FakePlayer create(class_3218 serverLevel, GameProfile profile) {
		return new FakePlayer(serverLevel, profile);
	}

	@Override
	protected int method_5691() {
		return 0;
	}

	@Override
	public boolean method_5680(class_3222 player) {
		return false;
	}

	@Override
	public boolean method_5732() {
		return false;
	}

	@Override
	public boolean method_5655() {
		return true;
	}

	@Override
	public boolean method_33190() {
		return false;
	}

	@Override
	public boolean method_36608() {
		return false;
	}

	@Override
	public boolean method_5863() {
		return false;
	}

	@Override
	public boolean method_5810() {
		return false;
	}

	@Override
	public boolean method_5767() {
		return false;
	}

	@Override
	public boolean method_6086() {
		return false;
	}

	@Override
	public boolean method_6102() {
		return false;
	}

	@Override
	public boolean method_18397(final class_1799 stack) {
		return false;
	}

	@Override
	public class_4048 method_18377(final class_4050 pose) {
		return DIMENSIONS;
	}

	@Override
	public float method_18381(final class_4050 pose) {
		return 0;
	}

	@Override
	public float method_18394(final class_4050 pose, final class_4048 dims) {
		return 0;
	}

	@Override
	public void method_5773() {
	}
}
