package com.github.litermc.vsplit;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Constants {
	public static final String MOD_ID = "vsplit";
	public static final String MOD_NAME = "VSplit";
	public static final String MOD_VERSION = "0.2.1";
	public static final Logger LOG = LoggerFactory.getLogger(MOD_NAME);
	public static final class_2561 MESSAGE_PREFIX = class_2561.method_43470("[" + MOD_NAME + "] ").method_27692(class_124.field_1064);

	private Constants() {}
}
