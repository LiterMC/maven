package com.github.litermc.vsplit.mixin;

import com.github.litermc.vsplit.util.SplitUtil;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2818.class)
public abstract class MixinLevelChunk extends class_2791 {
	protected MixinLevelChunk() {
		super(null, null, null, null, 0, null, null);
	}

	@Shadow
	@Final
	private class_1937 level;

	@Inject(
		method = "setBlockState",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/block/state/BlockState;onRemove(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V"
		)
	)
	private void setBlockState(
		final class_2338 pos, final class_2680 newState, final boolean moving,
		final CallbackInfoReturnable<class_2680> cir,
		final @Local(ordinal = 1) class_2680 oldState
	) {
		if (!(this.level instanceof final class_3218 serverLevel)) {
			return;
		}

		SplitUtil.onBlockUpdated(serverLevel, pos, oldState, newState);
	}
}
