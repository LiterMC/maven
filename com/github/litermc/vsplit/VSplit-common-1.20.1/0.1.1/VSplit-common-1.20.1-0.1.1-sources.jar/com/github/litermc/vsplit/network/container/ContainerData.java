// SPDX-FileCopyrightText: 2019 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vsplit.network.container;

import com.github.litermc.vsplit.network.NetworkMessage;
import com.github.litermc.vsplit.platform.PlatformHelper;
import java.util.function.Function;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;
import net.minecraft.class_3917;

/**
 * Additional data to send when opening a menu. Like {@link NetworkMessage}, this should be immutable.
 */
public interface ContainerData {
	void toBytes(class_2540 buf);

	static <C extends class_1703, T extends ContainerData> class_3917<C> toType(Function<class_2540, T> reader, Factory<C, T> factory) {
		return PlatformHelper.get().createMenuType(reader, factory);
	}

	interface Factory<C extends class_1703, T extends ContainerData> {
		C create(int id, class_1661 inventory, T data);
	}
}
