package com.github.litermc.vsplit.command;

import com.github.litermc.vsplit.Constants;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.server.MinecraftServer;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.mod.common.command.ShipArgument;
import org.valkyrienskies.mod.mixinducks.feature.command.VSCommandSource;

import java.util.Set;

public final class VSplitCommands {
	public static final String ROOT_LITERAL = Constants.MOD_ID;

	private VSplitCommands() {}

	public static void register(final CommandDispatcher<class_2168> dispatcher) {
		// dispatcher.register(Commands.literal(ROOT_LITERAL)
		// 	.requires((source) -> source.hasPermission(2))
		// 	.then(Commands.literal("delete")
		// 		.then(Commands.argument("ships", ShipArgument.Companion.ships())
		// 			.executes(VSplitCommands::delete)
		// 		)
		// 	)
		// );
	}

	// private static int delete(final CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
	// 	final CommandSourceStack source = context.getSource();
	// 	final MinecraftServer server = source.getServer();
	// 	final Set<Ship> ships = ShipArgument.Companion.getShips((CommandContext<VSCommandSource>)((CommandContext<?>)(context)), "ships");
	// 	int successCount = 0;
	// 	for (final Ship ship : ships) {
	// 		if (!(ship instanceof ServerShip serverShip)) {
	// 			continue;
	// 		}
	// 		final ServerLevel level = Utils.getLevel(serverShip.getChunkClaimDimension());
	// 		if (level == null) {
	// 			continue;
	// 		}
	// 		ShipAllocator.get(level).putShip(serverShip);
	// 		successCount++;
	// 	}
	// 	final int finalSuccessCount = successCount;
	// 	source.sendSuccess(() ->
	// 		Component.translatable("command.valkyrienskies.delete.success", finalSuccessCount),
	// 		true
	// 	);
	// 	return finalSuccessCount;
	// }
}
