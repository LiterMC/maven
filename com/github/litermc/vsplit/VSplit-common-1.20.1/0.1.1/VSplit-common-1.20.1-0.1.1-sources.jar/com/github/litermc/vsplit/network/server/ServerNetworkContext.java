// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vsplit.network.server;

import net.minecraft.class_3222;

/**
 * The context under which serverbound packets are evaluated.
 */
public interface ServerNetworkContext {
	/**
	 * Get the player who sent this packet.
	 *
	 * @return The sending player.
	 */
	class_3222 getSender();
}
