// SPDX-FileCopyrightText: 2019 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vsplit;

import com.github.litermc.vsplit.platform.PlatformHelper;
import com.github.litermc.vsplit.platform.RegistrationHelper;
import com.github.litermc.vsplit.platform.RegistryEntry;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_7924;

public final class VSplitRegistry {
	private VSplitRegistry() {}

	public static void register() {
		// Blocks.REGISTRY.register();
		// BlockEntities.REGISTRY.register();
		// Items.REGISTRY.register();
		// CreativeTabs.REGISTRY.register();
	}

	public static final class Blocks {
		private static final RegistrationHelper<class_2248> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41254);

		// public static final RegistryEntry<ChunkLoaderBlock> CHUNK_LOADER =
		// 	REGISTRY.register("chunk_loader", () -> new ChunkLoaderBlock(
		// 		BlockBehaviour.Properties.of()
		// 			.strength(5f)
		// 			.sound(SoundType.METAL)
		// 			.pushReaction(PushReaction.IGNORE)
		// 			.noOcclusion()
		// 			.isRedstoneConductor((state, level, pos) -> false)
		// 			.requiresCorrectToolForDrops()));

		public static void onRegisterRenderType(final BiConsumer<class_2248, class_1921> consumer) {
			// consumer.accept(CHUNK_LOADER.get(), RenderType.cutout());
		}

		private Blocks() {}
	}

	public static final class BlockEntities {
		private static final RegistrationHelper<class_2591<?>> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41255);

		private static <T extends class_2586> RegistryEntry<class_2591<T>> ofBlock(final RegistryEntry<? extends class_2248> block, final BiFunction<class_2338, class_2680, T> factory) {
			return REGISTRY.register(block.id().method_12832(), () -> PlatformHelper.get().createBlockEntityType(factory, block.get()));
		}

		// public static final RegistryEntry<BlockEntityType<ChunkLoaderBlockEntity>> CHUNK_LOADER =
		// 	ofBlock(Blocks.CHUNK_LOADER, ChunkLoaderBlockEntity::new);

		private BlockEntities() {}
	}

	public static final class Items {
		private static final RegistrationHelper<class_1792> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41197);
		private static final List<RegistryEntry<? extends class_1792>> TAB_ITEMS = new ArrayList<>();

		private static class_1792.class_1793 properties() {
			return new class_1792.class_1793();
		}

		private static <B extends class_2248, I extends class_1792> RegistryEntry<I> ofBlock(RegistryEntry<B> block, BiFunction<B, class_1792.class_1793, I> supplier) {
			final RegistryEntry<I> entry = REGISTRY.register(block.id().method_12832(), () -> supplier.apply(block.get(), properties()));
			TAB_ITEMS.add(entry);
			return entry;
		}

		// public static final RegistryEntry<BlockItem> CHUNK_LOADER = ofBlock(
		// 	Blocks.CHUNK_LOADER,
		// 	(block, props) -> new BlockItem(block, props.rarity(Rarity.EPIC).stacksTo(1))
		// );

		private Items() {}
	}

	static class CreativeTabs {
		static final RegistrationHelper<class_1761> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_44688);

		private static final RegistryEntry<class_1761> TAB = REGISTRY.register(
			"tab",
			() -> PlatformHelper.get().newCreativeModeTab()
				// .icon(() -> new ItemStack(Items.CHUNK_LOADER.get()))
				.method_47321(class_2561.method_43471("itemGroup." + Constants.MOD_ID))
				.method_47317((context, out) -> {
					Items.TAB_ITEMS.stream().map(RegistryEntry::get).forEach(out::method_45421);
				})
				.method_47324()
		);
	}
}
