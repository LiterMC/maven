package com.github.litermc.vsplit;

import com.github.litermc.vsplit.util.SplitUtil;
import com.github.litermc.vsplit.util.TaskUtil;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;

public final class VSplitListeners {
	private VSplitListeners() {}

	public static void onModInit() {
		VSplitRegistry.register();
	}

	public static void onServerLevelLoad(final class_3218 level) {
	}

	public static void onServerLevelUnload(final class_3218 level) {
	}

	public static void preServerTick(final MinecraftServer server) {
		TaskUtil.preServerTick();
	}

	public static void postServerTick(final MinecraftServer server) {
		SplitUtil.postServerTick();
		TaskUtil.postServerTick();
	}
}
