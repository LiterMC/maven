package com.github.litermc.vsplit.util;

import org.valkyrienskies.core.api.ships.LoadedServerShip;

import java.util.ArrayList;
import java.util.Random;
import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_3218;
import net.minecraft.class_4076;

public class ShipRandomTickGenerator {
	private final Random rnd = new Random();
	private final Ticker blockTicker;
	private int rate;

	public ShipRandomTickGenerator(final int rate, final Ticker blockTicker) {
		this.rate = rate;
		this.blockTicker = blockTicker;
	}

	public int getRate() {
		return this.rate;
	}

	public void setRate(final int rate) {
		this.rate = rate;
	}

	public void tick(final class_3218 level, final LoadedServerShip ship) {
		ship.getActiveChunksSet().forEach((chunkX, chunkZ) -> {
			final class_2818 chunk = level.method_8497(chunkX, chunkZ);
			final class_2826[] sections = chunk.method_12006();
			for (int i = 0; i < sections.length; i++) {
				final class_2826 section = sections[i];
				if (section.method_38292()) {
					continue;
				}
				final class_4076 spos = class_4076.method_18681(chunk.method_12004(), chunk.method_31604(i));
				for (int j = 0; j < this.rate; j++) {
					// section size is 16*16*16
					final int n = this.rnd.nextInt();
					final int x = n & 0xf, z = (n >> 8) & 0xf, y = (n >> 16) & 0xf;
					final class_2680 state = section.method_12254(x, y, z);
					this.blockTicker.tick(level, ship, spos.method_19767().method_10069(x, y, z), state);
				}
			}
		});
	}

	@FunctionalInterface
	public static interface Ticker {
		void tick(class_3218 level, LoadedServerShip ship, class_2338 pos, class_2680 state);
	}
}
