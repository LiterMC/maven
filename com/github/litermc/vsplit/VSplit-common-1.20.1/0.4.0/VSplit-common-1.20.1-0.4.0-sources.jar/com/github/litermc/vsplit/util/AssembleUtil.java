package com.github.litermc.vsplit.util;

import com.github.litermc.vtil.api.assemble.AssembleApi;
import org.valkyrienskies.core.api.ships.ServerShip;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;

public final class AssembleUtil {
	private AssembleUtil() {}

	private static final class_2350[] NO_DOWN_DIRECTIONS = new class_2350[]{
		class_2350.field_11036, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034,
	};
	private static final class_2350[] HORIZONTAL_DIRECTIONS = new class_2350[]{
		class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034,
	};
	private static final class_2382[] NO_DOWN_CORNER_OFFSETS = new class_2382[]{
		new class_2382(0, 0, 1),
		new class_2382(0, 0, -1),
		new class_2382(0, 1, 0),
		new class_2382(0, 1, 1),
		new class_2382(0, 1, -1),
		new class_2382(1, 0, 0),
		new class_2382(1, 0, 1),
		new class_2382(1, 0, -1),
		new class_2382(1, 1, 0),
		new class_2382(1, 1, 1),
		new class_2382(1, 1, -1),
		new class_2382(-1, 0, 0),
		new class_2382(-1, 0, 1),
		new class_2382(-1, 0, -1),
		new class_2382(-1, 1, 0),
		new class_2382(-1, 1, 1),
		new class_2382(-1, 1, -1)
	};

	public static ServerShip assembleTree(final class_3218 level, final class_2338 pos, final class_2680 original) {
		final List<class_2338> blocks = findTreeBlocks(level, pos, original.method_26204());
		if (blocks.size() == 0) {
			return null;
		}
		return AssembleApi.createShip(level, Set.copyOf(blocks));
	}

	private static List<class_2338> findTreeBlocks(final class_3218 level, final class_2338 pos, final class_2248 block) {
		final List<class_2338> blocks = findTreeLogs(level, pos, block);
		final Set<class_2338> logs = new HashSet<>(blocks);
		final Set<class_2338> accessed = new HashSet<>(logs);
		final Queue<Pair<class_2338, Integer>> queue = new ArrayDeque<>();
		accessed.add(pos);
		Stream.of(HORIZONTAL_DIRECTIONS)
			.map(pos::method_10093)
			.filter(Predicate.not(accessed::contains))
			.peek(accessed::add)
			.map(p -> new Pair<>(p, 0))
			.forEach(queue::add);
		for (final class_2338 logPos : blocks) {
			Stream.of(NO_DOWN_DIRECTIONS)
				.map(logPos::method_10093)
				.filter(Predicate.not(accessed::contains))
				.peek(accessed::add)
				.map(p -> new Pair<>(p, 0))
				.forEach(queue::add);
		}
		while (!queue.isEmpty()) {
			final Pair<class_2338, Integer> pair = queue.remove();
			final class_2338 p = pair.left();
			final int dist = pair.right() + 1;
			final class_2680 st = level.method_8320(p);
			if (!st.method_26164(class_3481.field_15503) || st.method_28500(class_2397.field_11200).orElse(true)) {
				continue;
			}
			if (dist > st.method_28500(class_2397.field_11199).orElse(0)) {
				continue;
			}
			final boolean invalid = class_2350.method_42013()
				.map(p::method_10093)
				.filter(Predicate.not(logs::contains))
				.map(level::method_8320)
				.anyMatch(s1 -> s1.method_26164(class_3481.field_39030));
			if (invalid) {
				continue;
			}
			blocks.add(p);
			if (dist < 7) {
				class_2350.method_42013()
					.map(p::method_10093)
					.filter(Predicate.not(accessed::contains))
					.peek(accessed::add)
					.map(p1 -> new Pair<>(p1, dist))
					.forEach(queue::add);
			}
		}
		return blocks;
	}

	private static List<class_2338> findTreeLogs(final class_3218 level, final class_2338 pos, final class_2248 block) {
		final Set<class_2338> accessed = new HashSet<>();
		final List<class_2338> blocks = new ArrayList<>();
		final Deque<class_2338> deque = new ArrayDeque<>();
		deque.addLast(pos.method_10084());
		while (!deque.isEmpty()) {
			final class_2338 p = deque.removeLast();
			final class_2680 st = level.method_8320(p);
			if (st.method_26204() != block) {
				continue;
			}
			blocks.add(p);
			Stream.of(NO_DOWN_CORNER_OFFSETS)
				.map(p::method_10081)
				.filter(Predicate.not(accessed::contains))
				.peek(accessed::add)
				.forEach(deque::addLast);
		}
		return blocks;
	}
}
