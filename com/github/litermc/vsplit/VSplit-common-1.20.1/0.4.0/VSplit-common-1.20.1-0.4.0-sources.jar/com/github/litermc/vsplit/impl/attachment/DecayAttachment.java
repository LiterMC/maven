package com.github.litermc.vsplit.impl.attachment;

import com.github.litermc.vsplit.api.attachment.ISplitListener;
import com.github.litermc.vsplit.config.Config;
import com.github.litermc.vsplit.config.DecayMethod;
import com.github.litermc.vsplit.util.ShipRandomTickGenerator;
import com.github.litermc.vtil.api.attachment.IServerTickListener;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.google.common.collect.ImmutableMap;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3218;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

@JsonAutoDetect(
	fieldVisibility = JsonAutoDetect.Visibility.NONE,
	isGetterVisibility = JsonAutoDetect.Visibility.NONE,
	getterVisibility = JsonAutoDetect.Visibility.NONE,
	setterVisibility = JsonAutoDetect.Visibility.NONE
)
public final class DecayAttachment implements IServerTickListener, ISplitListener {
	public static final String DECAY_PREFIX = "+decay+";
	private static final ImmutableMap<class_2248, class_2248> STAGED = addStagedDecayBlocks(new ImmutableMap.Builder<class_2248, class_2248>()).build();

	@JsonProperty("forceDecayCounter")
	private int forceDecayCounter;
	private final ShipRandomTickGenerator rnd = new ShipRandomTickGenerator(5, DecayAttachment::onRandomTick);

	private DecayAttachment() {
		this(-1);
	}

	public DecayAttachment(final int forceDecayCounter) {
		this.forceDecayCounter = forceDecayCounter;
	}

	@JsonGetter("decayRate")
	private int getDecayRate() {
		return this.rnd.getRate();
	}

	@JsonSetter("decayRate")
	private void setDecayRate(final int rate) {
		this.rnd.setRate(rate);
	}

	@Override
	public void onServerTick(final class_3218 level, final LoadedServerShip ship) {
		final String slug = ship.getSlug();
		if (slug == null || !slug.startsWith(DECAY_PREFIX)) {
			ship.removeAttachment(DecayAttachment.class);
			return;
		}
		this.forceDecayCounter--;
		if (this.forceDecayCounter < 0) {
			ship.removeAttachment(DecayAttachment.class);
			VSGameUtilsKt.getShipObjectWorld(level).deleteShip(ship);
			return;
		}
		this.rnd.tick(level, ship);
	}

	@Override
	public void onShipSplit(final Context context) {
		if (Config.decayMethod == DecayMethod.NO_SPLIT) {
			final class_3218 level = context.getLevel();
			context.getBlocks().forEach((pos) -> level.method_22352(pos, true));
			return;
		}
		context.addAfterSplit((newShip) -> {
			newShip.setAttachment(new DecayAttachment(this.forceDecayCounter));
		});
	}

	private static ImmutableMap.Builder<class_2248, class_2248> addStagedDecayBlocks(final ImmutableMap.Builder<class_2248, class_2248> builder) {
		return builder
			.put(class_2246.field_10533, class_2246.field_10622)
			.put(class_2246.field_10511, class_2246.field_10366)
			.put(class_2246.field_42729, class_2246.field_42732)
			.put(class_2246.field_22118, class_2246.field_22119)
			.put(class_2246.field_10010, class_2246.field_10244)
			.put(class_2246.field_10306, class_2246.field_10254)
			.put(class_2246.field_37545, class_2246.field_37548)
			.put(class_2246.field_10431, class_2246.field_10519)
			.put(class_2246.field_10037, class_2246.field_10436)
			.put(class_2246.field_22111, class_2246.field_22112);
	}

	private static void onRandomTick(final class_3218 level, final LoadedServerShip ship, final class_2338 pos, final class_2680 state) {
		if (!state.method_26215()) {
			destroyBlock(level, ship, pos);
		}
	}

	private static void destroyBlock(final class_3218 level, final LoadedServerShip ship, final class_2338 pos) {
		final class_2680 state = level.method_8320(pos);
		final class_2248 decayedBlock = STAGED.get(state.method_26204());
		if (decayedBlock != null) {
			final class_2680[] newState = new class_2680[]{decayedBlock.method_9564()};
			state.method_11656().forEach((k, v) -> {
				newState[0] = trySetValue(newState[0], k, v);
			});
			level.method_8652(pos, newState[0], class_2248.field_31036);
			return;
		}
		level.method_22352(pos, true);
	}

	private static <T extends Comparable<T>> class_2680 trySetValue(
		final class_2680 state,
		final class_2769<T> property,
		final Object value
	) {
		return state.method_47968(property, (T) value);
	}
}
