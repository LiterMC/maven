package com.github.litermc.vsplit.impl.clean;

import com.github.litermc.vsplit.api.clean.ICleanListener;
import com.github.litermc.vsplit.config.Config;
import com.github.litermc.vsplit.config.CoreBlockBehaviour;
import com.github.litermc.vtil.api.connectivity.BlockConnectivityApi;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;

import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public final class ShipBlockCountCleaner implements ICleanListener {
	public static final ShipBlockCountCleaner INSTANCE = new ShipBlockCountCleaner();

	@Override
	public int getShipCleanPriority() {
		return 10;
	}

	@Override
	public void onShipClean(final Context context) {
		if (!Config.enableBlockCountCleanup) {
			return;
		}
		if (context.getCleanSuggestion()) {
			return;
		}
		final class_3218 level = context.getLevel();
		final ServerShip ship = context.getShip();
		final int blocks = this.getShipBlocks(level, ship);
		if (blocks == Integer.MAX_VALUE) {
			return;
		}
		context.setCleanSuggestion(true);
	}

	@Override
	public void checkShipCleanStatus(final Context context, final Consumer<class_2561> messageConsumer) {
		if (!Config.enableBlockCountCleanup) {
			return;
		}
		final class_3218 level = context.getLevel();
		final ServerShip ship = context.getShip();
		int blocks = this.getShipBlocks(level, ship);
		if (blocks == Integer.MAX_VALUE) {
			return;
		}
		final boolean hasCore = blocks >= 0;
		if (hasCore) {
			blocks = -blocks;
		} else {
			messageConsumer.accept(class_2561.method_43471("vsplit.message.clean.core_block.hint"));
		}
		if (blocks < Config.minimumBlocksShipNeeds) {
			messageConsumer.accept(class_2561.method_43469("vsplit.message.clean.block_count.hint", blocks, Config.minimumBlocksShipNeeds));
		}
		context.setCleanSuggestion(true);
	}

	private int getShipBlocks(final class_3218 level, final ServerShip ship) {
		final AABBic box = ship.getShipAABB();
		if (box == null) {
			return 0;
		}
		final CoreBlockBehaviour behaviour = Config.coreBlockBehaviour;
		int blocks = 0;
		boolean hasCore = behaviour == CoreBlockBehaviour.IGNORED;
		for (final class_2338 pos : class_2338.method_10094(box.minX(), box.minY(), box.minZ(), box.maxX(), box.maxY(), box.maxZ())) {
			final class_2680 state = level.method_8320(pos);
			if (BlockConnectivityApi.isAir(state)) {
				continue;
			}
			// TODO: maintain a core flag instead of scan the whole ship?
			if (!hasCore && Config.coreBlocks.contains(class_7923.field_41175.method_10221(state.method_26204()))) {
				hasCore = true;
			}
			blocks++;
			if (blocks >= Config.minimumBlocksShipNeeds && (hasCore || behaviour != CoreBlockBehaviour.REQUIRED)) {
				return Integer.MAX_VALUE;
			}
		}
		return hasCore ? blocks : -blocks;
	}
}
