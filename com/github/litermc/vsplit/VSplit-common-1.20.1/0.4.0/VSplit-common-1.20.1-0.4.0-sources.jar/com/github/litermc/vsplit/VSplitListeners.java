package com.github.litermc.vsplit;

import com.github.litermc.vsplit.config.Config;
import com.github.litermc.vsplit.impl.attachment.DecayAttachment;
import com.github.litermc.vsplit.impl.clean.CleanScheduler;
import com.github.litermc.vsplit.util.AssembleUtil;
import com.github.litermc.vsplit.util.SplitUtil;
import com.github.litermc.vsplit.util.TaskUtil;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.server.MinecraftServer;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

public final class VSplitListeners {
	private VSplitListeners() {}

	public static void onModInit() {
		VSplitRegistry.register();
	}

	public static void onServerLevelLoad(final class_3218 level) {
	}

	public static void onServerLevelUnload(final class_3218 level) {
	}

	public static void onServerStarted(final MinecraftServer server) {
		CleanScheduler.onServerStarted(server);
	}

	public static void preServerTick(final MinecraftServer server) {
		TaskUtil.preServerTick();
	}

	public static void postServerTick(final MinecraftServer server) {
		SplitUtil.postServerTick();
		TaskUtil.postServerTick();
		CleanScheduler.postServerTick(server);
	}

	public static void onPlayerBreakBlock(final class_3222 player, final class_2338 pos) {
		if (!Config.enableTreeFalling) {
			return;
		}
		final class_3218 level = player.method_51469();
		if (VSGameUtilsKt.isBlockInShipyard(level, pos)) {
			return;
		}
		final class_2680 state = level.method_8320(pos);
		if (!state.method_26164(class_3481.field_39030)) {
			return;
		}
		if (state.method_28500(class_2465.field_11459).map(axis -> axis != class_2350.class_2351.field_11052).orElse(true)) {
			return;
		}
		final class_2338.class_2339 leafPos = pos.method_25503();
		final int maxY = Math.min(pos.method_10264() + 32, level.method_31600());
		for (int y = pos.method_10264() + 1; y <= maxY; y++) {
			leafPos.method_33098(y);
			final class_2680 st = level.method_8320(leafPos);
			if (st.method_26164(class_3481.field_15503)) {
				if (!st.method_28500(class_2397.field_11200).orElse(true)) {
					final ServerShip ship = AssembleUtil.assembleTree(level, pos, state);
					if (ship != null) {
						final int DEFAULT_FORCE_DECAY_TIMEOUT = 20 * 60 * 10; // 10 min
						ship.setSlug(DecayAttachment.DECAY_PREFIX + "tree-" + ship.getId());
						((LoadedServerShip) ship).setAttachment(new DecayAttachment(DEFAULT_FORCE_DECAY_TIMEOUT));
					}
				}
				return;
			}
			if (!st.method_26164(class_3481.field_39030)) {
				return;
			}
			if (st.method_28500(class_2465.field_11459).map(axis -> axis != class_2350.class_2351.field_11052).orElse(true)) {
				return;
			}
		}
	}
}
