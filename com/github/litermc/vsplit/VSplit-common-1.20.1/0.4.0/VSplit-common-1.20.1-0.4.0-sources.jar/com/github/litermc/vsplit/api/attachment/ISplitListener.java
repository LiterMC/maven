package com.github.litermc.vsplit.api.attachment;

import org.valkyrienskies.core.api.ships.LoadedServerShip;

import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * ISplitListener is an interface for ship attachments to define special logic on ship splitting.
 */
public interface ISplitListener {
	/**
	 * onShipSplit is invoked before each part of a ship is going to split out.
	 *
	 * @param context The ship split context. Should only be used inside the method's lifecycle.
	 */
	void onShipSplit(Context context);

	interface Context {
		/**
		 * Get the level where split happens
		 *
		 * @return the level the splitting ship is in
		 */
		class_3218 getLevel();

		/**
		 * Get the instance of the ship where the splitting is happening.
		 *
		 * @return the splitting ship.
		 */
		LoadedServerShip getShip();

		/**
		 * Get the blocks that is going to split out.
		 *
		 * @return immutable block set that will form a new ship. 
		 */
		Set<class_2338> getBlocks();

		/**
		 * Add a callback to be invoked after ship splitting.
		 * The callback will be provided with the instance of splitted ship.
		 *
		 * @param callback The after split callback.
		 */
		void addAfterSplit(Consumer<LoadedServerShip> callback);
	}
}
