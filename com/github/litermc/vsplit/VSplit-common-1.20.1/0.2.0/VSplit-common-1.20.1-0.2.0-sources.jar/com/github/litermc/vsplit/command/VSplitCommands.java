package com.github.litermc.vsplit.command;

import com.github.litermc.vsplit.Constants;
import com.github.litermc.vsplit.api.clean.ShipCleaner;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;

import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.command.ShipArgument;
import org.valkyrienskies.mod.mixinducks.feature.command.VSCommandSource;

import java.util.Set;

public final class VSplitCommands {
	public static final String ROOT_LITERAL = Constants.MOD_ID;

	private VSplitCommands() {}

	public static void register(final CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247(ROOT_LITERAL)
			.requires((source) -> source.method_9259(2))
			.then(class_2170.method_9247("clean")
				.then(class_2170.method_9244("forceRemoval", BoolArgumentType.bool())
					.executes((ctx) -> VSplitCommands.clean(ctx, BoolArgumentType.getBool(ctx, "forceRemoval")))
				)
				.executes((ctx) -> VSplitCommands.clean(ctx, false))
			)
			.then(class_2170.method_9247("protect")
				.then(class_2170.method_9244("ships", ShipArgument.Companion.ships())
					.then(class_2170.method_9244("shouldProtect", BoolArgumentType.bool())
						.executes((ctx) -> VSplitCommands.protect(ctx, BoolArgumentType.getBool(ctx, "shouldProtect")))
					)
					.executes((ctx) -> VSplitCommands.protect(ctx, true))
				)
			)
		);
	}

	private static int clean(final CommandContext<class_2168> context, final boolean forceRemoval) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		ShipCleaner.clean(server, forceRemoval);
		return 1;
	}

	private static int protect(final CommandContext<class_2168> context, final boolean shouldProtect) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final ServerShipWorldCore world = VSGameUtilsKt.getShipObjectWorld(server);
		final Set<Ship> ships = ShipArgument.Companion.getShips((CommandContext<VSCommandSource>) ((CommandContext<?>) (context)), "ships");
		int count = 0;
		for (final Ship ship : ships) {
			if (!(ship instanceof ServerShip serverShip)) {
				continue;
			}
			final LoadedServerShip loadedShip = world.getLoadedShips().getById(ship.getId());
			if (loadedShip == null) {
				continue;
			}
			ShipCleaner.setShipProtected(loadedShip, shouldProtect);
			count++;
		}
		final int finalCount = count;
		source.method_9226(() -> class_2561.method_43469("vsplit.command.protect.success", finalCount), false);
		return count;
	}
}
