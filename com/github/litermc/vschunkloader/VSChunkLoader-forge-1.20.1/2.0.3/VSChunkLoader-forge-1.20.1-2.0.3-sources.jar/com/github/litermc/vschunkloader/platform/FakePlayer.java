// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.util.IChunkLoaderFakePlayer;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public final class FakePlayer extends net.minecraftforge.common.util.FakePlayer implements IChunkLoaderFakePlayer {
	private static final int COUNTDOWN = 21;
	private static final int DISCARD_TIMEOUT = 30;
	private static final EntityDimensions DIMENSIONS = EntityDimensions.m_20398_(0, 0);

	private Vec3 position;
	private int countDown = COUNTDOWN;
	private int discarding = 0;
	private Runnable discardCallback = null;

	private FakePlayer(ServerLevel serverLevel, GameProfile gameProfile) {
		super(serverLevel, gameProfile);
		this.m_20331_(true);
		this.m_6210_();
	}

	static FakePlayer create(ServerLevel serverLevel, GameProfile profile) {
		return new FakePlayer(serverLevel, profile);
	}

	@Override
	protected int m_8088_() {
		return 0;
	}

	@Override
	public boolean m_6459_(ServerPlayer player) {
		return false;
	}

	@Override
	public boolean m_6097_() {
		return false;
	}

	@Override
	public boolean m_20147_() {
		return true;
	}

	@Override
	public boolean m_142066_() {
		return false;
	}

	@Override
	public boolean m_142065_() {
		return false;
	}

	@Override
	public boolean m_6087_() {
		return false;
	}

	@Override
	public boolean m_6094_() {
		return false;
	}

	@Override
	public boolean m_20145_() {
		return false;
	}

	@Override
	public boolean m_5801_() {
		return false;
	}

	@Override
	public boolean m_5789_() {
		return false;
	}

	@Override
	public boolean m_7066_(final ItemStack stack) {
		return false;
	}

	@Override
	public EntityDimensions m_6972_(final Pose pose) {
		return DIMENSIONS;
	}

	@Override
	public float m_20236_(final Pose pose) {
		return 0;
	}

	@Override
	public float m_6431_(final Pose pose, final EntityDimensions dims) {
		return 0;
	}

	@Override
	public void bindPosition(final Vec3 position) {
		this.position = position;
	}

	@Override
	public void setDiscardCallback(final Runnable callback) {
		this.discardCallback = callback;
	}

	@Override
	public void refreshCountDown() {
		this.countDown = COUNTDOWN;
	}

	@Override
	public void startDiscard() {
		this.discarding = 1;
	}

	@Override
	public boolean isDiscarding() {
		return this.discarding > 0;
	}

	@Override
	public void m_8119_() {
		if (this.discarding > 0) {
			this.discarding++;
			if (this.discarding > DISCARD_TIMEOUT) {
				this.m_146870_();
				Constants.LOG.debug("FakePlayer: Discarded: {} {}", this, this.position);
				if (this.discardCallback != null) {
					this.discardCallback.run();
				}
			}
			return;
		}
		if (this.countDown <= 0) {
			Constants.LOG.debug("FakePlayer: Discarding due to out of time: {} {}", this, this.position);
			this.startDiscard();
			return;
		}
		Constants.LOG.debug("FakePlayer: ticking cd={} {} {}", this.countDown, this, this.position);
		this.m_146867_();
		this.m_146884_(this.position);
		this.countDown--;
		this.m_284548_().m_7726_().m_8385_(this);
	}
}
