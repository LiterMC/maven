package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.attachment.AmmoShipAttachment;
import com.github.litermc.vschunkloader.compat.CompatMods;
import com.github.litermc.vschunkloader.config.Config;
import com.github.litermc.vtil.block.AbstractAssemblerBlockEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Clearable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.GameMasterBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.joml.Quaterniond;
import org.joml.RoundingMode;
import org.joml.Vector3d;
import org.joml.Vector3i;
import org.joml.primitives.AABBi;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.core.internal.world.VsiServerShipWorld;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class AmmoAssemblerBlockEntity extends AbstractAssemblerBlockEntity {
	private static final int MAX_DIM = 8 * 16;
	private static final String AMMO_DEFAULT_SLUG_PREFIX = "+assembled+ammo+";

	private boolean triggering = false;
	private volatile AssembleResult assembleResult = AssembleResult.SUCCESS;
	private int energyStored = 0;
	private int energyConsumption = Config.ammoAssembleEnergy; // TODO
	private final AABBi box = new AABBi();

	private Runnable assembleFinishCallback = null;
	Object energyStorage = null;
	Object peripheral = null;

	public AmmoAssemblerBlockEntity(BlockPos pos, BlockState state) {
		super(VSCRegistry.BlockEntities.AMMO_ASSEMBLER.get(), pos, state);
	}

	public boolean isAssembling() {
		return this.assembleResult.isWorking();
	}

	public boolean isAssembleSuccessed() {
		return this.assembleResult.isSuccess();
	}

	public int getEnergyConsumption() {
		return this.energyConsumption;
	}

	public AssembleResult getAssembleResult() {
		return this.assembleResult;
	}

	private void setAssembleResult(final AssembleResult result) {
		if (this.assembleResult == result) {
			return;
		}
		this.assembleResult = result;
		this.m_6596_();
		this.m_58904_().m_7731_(this.m_58899_(), this.m_58900_().m_61124_(AmmoAssemblerBlock.LED, result.getLED()), Block.f_152402_);
	}

	public int receiveEnergy(final int maxReceive, final boolean simulate) {
		final int avaliable = this.getMaxEnergyStored() - this.energyStored;
		if (avaliable <= 0) {
			return 0;
		}
		final int received = Math.min(Math.min(avaliable, maxReceive), (this.getMaxEnergyStored() + 99) / 100);
		if (!simulate) {
			this.energyStored += received;
		}
		return received;
	}

	public int getEnergyStored() {
		return this.energyStored;
	}

	public int getMaxEnergyStored() {
		return this.getEnergyConsumption();
	}

	@Override
	public void m_142466_(final CompoundTag data) {
		this.energyStored = data.m_128451_("EnergyStored");
		this.triggering = data.m_128471_("Powered");
		try {
			this.assembleResult = AssembleResult.valueOf(data.m_128461_("AssembleResult"));
		} catch (IllegalArgumentException e) {
			this.assembleResult = AssembleResult.SUCCESS;
		}
	}

	@Override
	public void m_183515_(final CompoundTag data) {
		data.m_128405_("EnergyStored", this.energyStored);
		data.m_128379_("Powered", this.triggering);
		this.saveShared(data);
	}

	public void saveShared(final CompoundTag data) {
		data.m_128359_("AssembleResult", this.assembleResult.toString());
	}

	@Override
	public CompoundTag m_5995_() {
		CompoundTag data = super.m_5995_();
		this.saveShared(data);
		return data;
	}

	@Override
	public ClientboundBlockEntityDataPacket m_58483_() {
		return ClientboundBlockEntityDataPacket.m_195640_(this);
	}

	public void neighborChanged(final Block neighbor, final BlockPos neighborPos, final boolean moving) {
		final Level level = this.m_58904_();
		final BlockPos pos = this.m_58899_();
		final boolean shouldTrigger = Direction.m_235666_()
			.filter(dir -> dir != this.m_58900_().m_61143_(DirectionalBlock.f_52588_))
			.anyMatch(dir -> level.m_277185_(pos.m_121945_(dir), dir) > 0);
		if (this.triggering == shouldTrigger) {
			return;
		}
		this.triggering = shouldTrigger;
		if (shouldTrigger) {
			this.startAssemble(null);
		}
	}

	Object createPeripheral() {
		final AmmoAssemblerPeripheral peripheral = new AmmoAssemblerPeripheral(this);
		this.assembleFinishCallback = peripheral::onAssembleFinish;
		return peripheral;
	}

	@Override
	public boolean startAssemble(final String slug) {
		if (this.isAssembling()) {
			return false;
		}
		if (this.energyStored < this.energyConsumption) {
			this.finishAssemble(AssembleResult.NO_ENERGY);
			return true;
		}
		return super.startAssemble(slug);
	}

	@Override
	protected void setAssembling(final boolean assembling) {
		super.setAssembling(assembling);
		if (assembling) {
			this.setAssembleResult(AssembleResult.WORKING);
		}
	}

	protected void finishAssemble(final AssembleResult result) {
		this.setAssembleResult(result);
		this.finishAssemble();
	}

	@Override
	protected void finishAssemble() {
		super.finishAssemble();
		if (this.assembleFinishCallback != null) {
			this.assembleFinishCallback.run();
		}
	}

	@Override
	protected void finishAssembleAsSuccess() {
		this.finishAssemble(AssembleResult.SUCCESS);
	}

	@Override
	protected void finishAssembleAsAssembleSelf() {
		this.finishAssemble(AssembleResult.ASSEMBLING_SELF);
	}

	@Override
	protected void finishAssembleAsTooManyBlocks() {
		this.finishAssemble(AssembleResult.TOO_MANY_BLOCKS);
	}

	@Override
	protected void finishAssembleAsNoBlockToAssemble() {
		this.finishAssemble(AssembleResult.NO_BLOCK);
	}

	@Override
	protected void finishAssembleAsConflicts() {
		this.finishAssemble(AssembleResult.OTHER_ASSEMBLING);
	}

	@Override
	protected void addAssemblingBlock(final BlockPos pos) {
		final Level level = this.m_58904_();
		if (!level.m_151577_(pos.m_123341_(), pos.m_123343_())) {
			this.finishAssemble(AssembleResult.CHUNK_UNLOADED);
			return;
		}
		final BlockState block = level.m_8055_(pos);
		if (block.m_60795_()) {
			return;
		}
		if (!this.canAssembleBlock(block)) {
			this.finishAssemble(AssembleResult.UNABLE_ASSEMBLE);
			return;
		}
		this.box.union(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		if (this.box.lengthX() > MAX_DIM || this.box.lengthY() > MAX_DIM || this.box.lengthZ() > MAX_DIM) {
			this.finishAssemble(AssembleResult.SIZE_OVERFLOW);
			return;
		}
		super.addAssemblingBlock(pos);
	}

	protected boolean canAssembleBlock(final BlockState state) {
		final Block block = state.m_60734_();
		if (block instanceof GameMasterBlock) {
			return false;
		}
		final ResourceLocation blockId = BuiltInRegistries.f_256975_.m_7981_(block);
		if (Config.ammoAssembleBlacklist.contains(blockId)) {
			return false;
		}
		return true;
	}

	@Override
	protected void onAssembleSuccess(final ServerShip ship) {
		if (ship.getSlug() == null) {
			ship.setSlug(AMMO_DEFAULT_SLUG_PREFIX + ship.getId());
		}
		final VsiServerShipWorld shipWorld = VSGameUtilsKt.getShipObjectWorld((ServerLevel) (this.m_58904_()));
		final LoadedServerShip loadedShip = shipWorld.getLoadedShips().getById(ship.getId());
		AmmoShipAttachment.create(loadedShip == null ? ship : loadedShip);
	}

	private static Stream<BlockPos> streamBlocksInAABB(AABB box) {
		final int
			minX = (int) (Math.round(box.f_82288_)), maxX = (int) (Math.round(box.f_82291_)),
			minY = (int) (Math.round(box.f_82289_)), maxY = (int) (Math.round(box.f_82292_)),
			minZ = (int) (Math.round(box.f_82290_)), maxZ = (int) (Math.round(box.f_82293_));
		final int widthX = maxX - minX, widthY = maxY - minY, widthZ = maxZ - minZ;
		return IntStream.range(0, widthX * widthY * widthZ).mapToObj((i) -> {
			final int x = i % widthX + minX;
			i /= widthX;
			final int z = i % widthZ + minZ;
			i /= widthZ;
			final int y = i + minY;
			return new BlockPos(x, y, z);
		});
	}
}
