package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;

import java.util.List;

public class AmmoAssemblerBlock extends DirectionalBlock implements EntityBlock {
	public static final EnumProperty<AssembleResult.AssembleLED> LED = EnumProperty.m_61587_("led", AssembleResult.AssembleLED.class);

	public AmmoAssemblerBlock(final Properties properties) {
		super(properties);
		this.m_49959_(
			this.m_49966_()
				.m_61124_(DirectionalBlock.f_52588_, Direction.UP)
				.m_61124_(LED, AssembleResult.AssembleLED.GREEN)
		);
	}

	@Override
	public void m_7926_(final StateDefinition.Builder<Block, BlockState> builder) {
		builder
			.m_61104_(DirectionalBlock.f_52588_)
			.m_61104_(LED);
	}

	@Override
	public BlockState m_5573_(final BlockPlaceContext ctx) {
		Direction dir = ctx.m_7820_().m_122424_();
		if (ctx.m_7078_()) {
			dir = dir.m_122424_();
		}
		return this.m_49966_()
			.m_61124_(DirectionalBlock.f_52588_, dir)
			.m_61124_(LED, AssembleResult.AssembleLED.GREEN);
	}

	@Override
	public void m_6861_(
		final BlockState state,
		final Level world,
		final BlockPos pos,
		final Block neighbor,
		final BlockPos neighborPos,
		final boolean moving
	) {
		super.m_6861_(state, world, pos, neighbor, neighborPos, moving);
		final AmmoAssemblerBlockEntity be = (AmmoAssemblerBlockEntity) world.m_7702_(pos);
		be.neighborChanged(neighbor, neighborPos, moving);
	}

	@Override
	public AmmoAssemblerBlockEntity m_142194_(final BlockPos pos, final BlockState state) {
		return new AmmoAssemblerBlockEntity(pos, state);
	}

	@Override
	public <U extends BlockEntity> BlockEntityTicker<U> m_142354_(final Level level, final BlockState state, final BlockEntityType<U> type) {
		if (type != VSCRegistry.BlockEntities.AMMO_ASSEMBLER.get()) {
			return null;
		}
		return level.f_46443_ ? null : (level2, pos, state2, entity) -> ((AmmoAssemblerBlockEntity) (entity)).serverTick();
	}
}
