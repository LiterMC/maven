package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.attachment.AmmoShipAttachment;
import com.github.litermc.vschunkloader.config.Config;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

import org.joml.primitives.AABBd;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

public final class AmmoManagerBlockEntity extends BlockEntity {
	private final AABBd manageArea;

	public AmmoManagerBlockEntity(final BlockPos pos, final BlockState state) {
		super(VSCRegistry.BlockEntities.AMMO_MANAGER.get(), pos, state);
		final double r = Config.ammoManagerAnchoringRange;
		this.manageArea = new AABBd(pos.m_123341_() - r, pos.m_123342_() - r, pos.m_123343_() - r, pos.m_123341_() + r + 1, pos.m_123342_() + r + 1, pos.m_123343_() + r + 1);
	}

	public AABBd getManageArea() {
		final ServerLevel level = (ServerLevel) (this.m_58904_());
		final ServerShip ship = VSGameUtilsKt.getShipManagingPos(level, this.m_58899_());
		if (ship == null) {
			return this.manageArea;
		}
		return this.manageArea.transform(ship.getShipToWorld(), new AABBd());
	}

	public void serverTick() {
		final ServerLevel level = (ServerLevel) (this.m_58904_());
		final ServerShipWorldCore world = VSGameUtilsKt.getShipObjectWorld(level);
		for (final LoadedServerShip ship : world.getLoadedShips().getIntersecting(this.getManageArea())) {
			final AmmoShipAttachment attachment = ship.getAttachment(AmmoShipAttachment.class);
			if (attachment != null) {
				attachment.managerTick();
			}
		}
	}
}
