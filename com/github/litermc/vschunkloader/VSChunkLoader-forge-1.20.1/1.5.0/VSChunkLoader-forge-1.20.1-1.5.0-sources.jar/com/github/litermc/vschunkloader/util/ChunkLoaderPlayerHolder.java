package com.github.litermc.vschunkloader.util;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.platform.PlatformHelper;

import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import org.valkyrienskies.core.apigame.world.IPlayer;
import org.valkyrienskies.mod.common.util.MinecraftPlayer;

import java.util.UUID;
import java.nio.charset.StandardCharsets;

public final class ChunkLoaderPlayerHolder {
	private static int count = 0;
	private final ServerLevel level;
	private final GameProfile fakeGameProfile;
	private Vec3 position;
	private IChunkLoaderFakePlayer fakePlayer;
	private IPlayer playerData;

	private ChunkLoaderPlayerHolder(final ServerLevel level, final Vec3 position, final String name) {
		this.level = level;
		this.position = position;
		final UUID uuid = UUID.nameUUIDFromBytes(name.getBytes(StandardCharsets.UTF_8));
		this.fakeGameProfile = new GameProfile(uuid, name);
		final ServerPlayer fakePlayer = PlatformHelper.get().createFakePlayer(this.level, this.fakeGameProfile);
		this.fakePlayer = ((IChunkLoaderFakePlayer)(fakePlayer));
		this.playerData = new MinecraftPlayer(fakePlayer);

		this.fakePlayer.bindPosition(this.position);
		fakePlayer.m_20219_(this.position);
		this.level.m_8834_(fakePlayer);
	}

	public static ChunkLoaderPlayerHolder createForBlock(final ServerLevel level, final BlockPos blockPos) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating at block: {}", blockPos);
		final String name = "ChunkLoader:" + level.m_46472_().m_135782_().toString() + "#" + blockPos.toString();
		return new ChunkLoaderPlayerHolder(level, blockPos.m_252807_(), name);
	}

	public static ChunkLoaderPlayerHolder createFixed(final ServerLevel level, final Vec3 position) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating fixed: {}", position);
		final int id = count++;
		final String name = "ChunkLoaderFixed:" + level.m_46472_().m_135782_().toString() + "#" + Integer.toString(id, 16);
		return new ChunkLoaderPlayerHolder(level, position, name);
	}

	public static ChunkLoaderPlayerHolder createForShip(final ServerLevel level, final long shipId, final Vec3 position) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating for ship: {} @ {}", shipId, position);
		final String name = "ChunkLoaderShip:" + level.m_46472_().m_135782_().toString() + "#" + shipId;
		return new ChunkLoaderPlayerHolder(level, position, name);
	}

	public IPlayer getPlayerData() {
		return this.playerData;
	}

	public void setDiscardCallback(final Runnable callback) {
		this.fakePlayer.setDiscardCallback(callback);
	}

	public void setPosition(final Vec3 position) {
		this.position = position;
		this.fakePlayer.bindPosition(position);
	}

	public void refresh() {
		this.fakePlayer.refreshCountDown();
	}

	public void discard() {
		this.fakePlayer.startDiscard();
	}

	public boolean isDiscarding() {
		return this.fakePlayer.isDiscarding();
	}
}
