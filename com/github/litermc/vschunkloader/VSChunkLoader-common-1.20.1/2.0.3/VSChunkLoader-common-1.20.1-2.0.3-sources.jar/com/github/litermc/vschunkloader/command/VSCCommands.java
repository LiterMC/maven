package com.github.litermc.vschunkloader.command;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.VSCApi;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.server.MinecraftServer;

import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.mod.common.command.arguments.ShipArgument;

import java.util.Set;

public final class VSCCommands {
	public static final String ROOT_LITERAL = "vschunkloader";
	public static final class_2960 FORCELOAD_TOKEN = new class_2960(Constants.MOD_ID, "command");

	private VSCCommands() {}

	public static void register(final CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247(ROOT_LITERAL)
			.requires((source) -> source.method_9259(2))
			.then(class_2170.method_9247("forceload")
				.then(class_2170.method_9244("ships", ShipArgument.ships())
					.executes(VSCCommands::forceLoad)
				)
			)
			.then(class_2170.method_9247("unforceload")
				.then(class_2170.method_9244("ships", ShipArgument.ships())
					.executes(VSCCommands::unforceLoad)
				)
			)
			.then(class_2170.method_9247("unforceload-all")
				.then(class_2170.method_9244("ships", ShipArgument.ships())
					.executes(VSCCommands::unforceLoadAll)
				)
			)
			.then(class_2170.method_9247("is-forceloaded")
				.then(class_2170.method_9244("ships", ShipArgument.ships())
					.executes(VSCCommands::isForceLoaded)
				)
			)
			.then(class_2170.method_9247("query-forceload-tokens")
				.then(class_2170.method_9244("ships", ShipArgument.ships())
					.executes(VSCCommands::queryForceLoadTokens)
				)
			)
		);
	}

	private static int forceLoad(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final Set<Ship> ships = ShipArgument.getShips(context, "ships");
		int successCount = 0;
		for (final Ship ship : ships) {
			if (VSCApi.forceLoad(server, ship.getId(), FORCELOAD_TOKEN, true)) {
				successCount++;
			}
		}
		final int finalSuccessCount = successCount;
		source.method_9226(() ->
			class_2561.method_43469("command." + Constants.MOD_ID + ".forceload", finalSuccessCount),
			true
		);
		return finalSuccessCount;
	}

	private static int unforceLoad(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final Set<Ship> ships = ShipArgument.getShips(context, "ships");
		int successCount = 0;
		for (final Ship ship : ships) {
			if (VSCApi.forceLoad(server, ship.getId(), FORCELOAD_TOKEN, false)) {
				successCount++;
			}
		}
		final int finalSuccessCount = successCount;
		source.method_9226(() ->
			class_2561.method_43469("command." + Constants.MOD_ID + ".unforceload", finalSuccessCount),
			true
		);
		return finalSuccessCount;
	}

	private static int unforceLoadAll(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final Set<Ship> ships = ShipArgument.getShips(context, "ships");
		int successCount = 0;
		for (final Ship ship : ships) {
			if (VSCApi.clearForceLoadTokens(server, ship.getId())) {
				successCount++;
			}
		}
		final int finalSuccessCount = successCount;
		source.method_9226(() ->
			class_2561.method_43469("command." + Constants.MOD_ID + ".unforceload", finalSuccessCount),
			true
		);
		return finalSuccessCount;
	}

	private static int isForceLoaded(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final Set<Ship> ships = ShipArgument.getShips(context, "ships");
		int loadedCount = 0;
		for (final Ship ship : ships) {
			if (VSCApi.isForceLoaded(server, ship.getId())) {
				loadedCount++;
			}
		}
		final int finalLoadedCount = loadedCount;
		source.method_9226(() ->
			finalLoadedCount == 0
				? class_2561.method_43471("command." + Constants.MOD_ID + ".is_forceloaded.none")
				: class_2561.method_43469("command." + Constants.MOD_ID + ".is_forceloaded", finalLoadedCount),
			false
		);
		return finalLoadedCount;
	}

	private static int queryForceLoadTokens(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final Set<Ship> ships = ShipArgument.getShips(context, "ships");
		if (ships.isEmpty()) {
			source.method_9213(class_2561.method_43471("argument.valkyrienskies.ship.no_found"));
			return 0;
		}
		if (ships.size() > 1) {
			source.method_9213(class_2561.method_43471("argument.valkyrienskies.ship.multiple_found"));
			return 0;
		}
		final Ship ship = ships.iterator().next();
		final Set<class_2960> tokens = VSCApi.getForceLoadTokens(server, ship.getId());
		if (tokens == null) {
			source.method_9213(class_2561.method_43471("argument.valkyrienskies.ship.no_found"));
			return 0;
		}
		final int count = tokens.size();
		if (count == 0) {
			source.method_9226(() -> class_2561.method_43471("command." + Constants.MOD_ID + ".query_forceload.none"), false);
			return 1;
		}
		source.method_9226(() -> {
			final class_5250 component = class_2561.method_43469("command." + Constants.MOD_ID + ".query_forceload.title", count);
			tokens.stream()
				.map(class_2960::toString)
				.sorted()
				.map((token) -> class_2561.method_43470("\n- ").method_27693(token))
				.forEach(component::method_10852);
			return component;
		}, false);
		return count + 1;
	}
}
