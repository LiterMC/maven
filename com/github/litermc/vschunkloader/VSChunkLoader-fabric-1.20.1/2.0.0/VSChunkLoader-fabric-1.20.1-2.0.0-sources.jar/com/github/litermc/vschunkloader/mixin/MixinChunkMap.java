package com.github.litermc.vschunkloader.mixin;

import com.github.litermc.vschunkloader.accessor.ChunkMapAccessor;
import com.github.litermc.vschunkloader.util.ChunkSensor;
import net.minecraft.class_3898;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;


@Mixin(class_3898.class)
public abstract class MixinChunkMap implements ChunkMapAccessor {
	@Unique
	private final ChunkSensor chunkSensor = new ChunkSensor();

	@Override
	public ChunkSensor vsc$getChunkSensor() {
		return this.chunkSensor;
	}
}
