package com.github.litermc.vschunkloader.mixin;

import com.github.litermc.vschunkloader.platform.PlatformHelper;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_3222;
import net.minecraft.class_5838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_5838.class)
public class MixinSleepStatus {
	@WrapOperation(
		method = "update",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;isSpectator()Z")
	)
	public boolean update$isSpectator(final class_3222 player, final Operation<Boolean> operation) {
		return operation.call(player) || PlatformHelper.get().isFakePlayer(player);
	}
}
