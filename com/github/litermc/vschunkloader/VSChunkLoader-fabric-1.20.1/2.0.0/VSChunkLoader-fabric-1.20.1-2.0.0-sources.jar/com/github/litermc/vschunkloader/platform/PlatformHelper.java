// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import com.github.litermc.vschunkloader.network.MessageType;
import com.github.litermc.vschunkloader.network.NetworkMessage;
import com.github.litermc.vschunkloader.network.client.ClientNetworkContext;
import com.github.litermc.vschunkloader.network.container.ContainerData;
import com.github.litermc.vschunkloader.platform.Services.LoadedService;
import com.github.litermc.vschunkloader.config.ConfigFile;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import java.util.function.BiFunction;
import java.util.function.Function;
import javax.annotation.Nullable;

public interface PlatformHelper {
	/**
	 * Get the current {@link PlatformHelper} instance.
	 *
	 * @return The current instance.
	 */
	public static PlatformHelper get() {
		var instance = Instance.INSTANCE;
		return instance == null ? Services.raise(PlatformHelper.class, Instance.ERROR) : instance;
	}

	/**
	 * Check if we're running in a development environment.
	 *
	 * @return If we're running in a development environment.
	 */
	boolean isDevelopmentEnvironment();

	/**
	 * Create a new config builder.
	 *
	 * @return The newly created config builder.
	 */
	ConfigFile.Builder createConfigBuilder();

	MinecraftServer getCurrentServer();

	boolean isModLoaded(String modid);

	/**
	 * Wrap a Minecraft registry in our own abstraction layer.
	 *
	 * @param registry The registry to wrap.
	 * @param <T>      The type of object stored in this registry.
	 * @return The wrapped registry.
	 */
	<T> RegistryWrappers.RegistryWrapper<T> wrap(class_5321<class_2378<T>> registry);

	/**
	 * Create a registration helper for a specific registry.
	 *
	 * @param registry The registry we'll add entries to.
	 * @param <T>      The type of object stored in the registry.
	 * @return The registration helper.
	 */
	<T> RegistrationHelper<T> createRegistrationHelper(class_5321<class_2378<T>> registry);

	/**
	 * A version of {@link #getRegistryObject(class_5321, class_2960)} which allows missing entries.
	 *
	 * @param registry The registry to look up this object in.
	 * @param id       The ID to look up.
	 * @param <T>      The type of object the registry stores.
	 * @return The registered object or {@code null}.
	 */
	@Nullable
	<T> T tryGetRegistryObject(class_5321<class_2378<T>> registry, class_2960 id);

	/**
	 * Get the unique ID for a registered object.
	 *
	 * @param registry The registry to look up this object in.
	 * @param object   The object to look up.
	 * @param <T>      The type of object the registry stores.
	 * @return The registered object's ID.
	 * @throws IllegalArgumentException If the registry or object are not registered.
	 */
	<T> class_2960 getRegistryKey(class_5321<class_2378<T>> registry, T object);

	/**
	 * Look up an ID in a registry, returning the registered object.
	 *
	 * @param registry The registry to look up this object in.
	 * @param id       The ID to look up.
	 * @param <T>      The type of object the registry stores.
	 * @return The resolved registry object.
	 * @throws IllegalArgumentException If the registry or object are not registered.
	 */
	<T> T getRegistryObject(class_5321<class_2378<T>> registry, class_2960 id);

	/**
	 * Create a new block entity type which serves a particular block.
	 *
	 * @param factory The method which creates a new block entity with this type, typically the constructor.
	 * @param block   The block this block entity exists on.
	 * @param <T>     The type of block entity we're creating.
	 * @return The new block entity type.
	 */
	<T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> factory, class_2248 block);

	/**
	 * Create a menu type which sends additional data when opened.
	 *
	 * @param reader  Parse the additional container data into a usable type.
	 * @param factory The factory to create the new menu.
	 * @param <C>     The menu/container than we open.
	 * @param <T>     The data that we send to the client.
	 * @return The menu type for this container.
	 */
	<C extends class_1703, T extends ContainerData> class_3917<C> createMenuType(Function<class_2540, T> reader, ContainerData.Factory<C, T> factory);

	/**
	 * Open a container using a specific {@link ContainerData}.
	 *
	 * @param player The player to open the menu for.
	 * @param title  The title for this menu.
	 * @param menu   The underlying menu constructor.
	 * @param data   The menu data.
	 */
	void openMenu(class_1657 player, class_2561 title, class_1270 menu, ContainerData data);

	/**
	 * Create a new {@link MessageType}.
	 *
	 * @param id      The descriminator for this message type.
	 * @param channel The channel name for this message type.
	 * @param klass   The type of this message.
	 * @param reader  The function which reads the packet from a buffer. Should be the inverse to {@link NetworkMessage#write(class_2540)}.
	 * @param <T>     The type of this message.
	 * @return The new {@link MessageType} instance.
	 */
	<T extends NetworkMessage<?>> MessageType<T> createMessageType(int id, class_2960 channel, Class<T> klass, class_2540.class_7461<T> reader);

	/**
	 * Convert a clientbound {@link NetworkMessage} to a Minecraft {@link class_2596}.
	 *
	 * @param message The messsge to convert.
	 * @return The converted message.
	 */
	class_2596<class_2602> createPacket(NetworkMessage<ClientNetworkContext> message);

	/**
	 * Create a builder for a new creative tab.
	 *
	 * @return The creative tab builder.
	 */
	class_1761.class_7913 newCreativeModeTab();

	/**
	* Create a new fake player.
	*
	* @param level   The level the player should be created in.
	* @param profile The user this player should mimic.
	* @return The newly constructed fake player.
	*/
	class_3222 createFakePlayer(class_3218 level, GameProfile profile);

	/**
	* Determine if a player is not a real player.
	*
	* @param player The player to check.
	* @return Whether this player is fake.
	*/
	default boolean isFakePlayer(class_3222 player) {
		// Any subclass of ServerPlayer (i.e. Forge's FakePlayer) is assumed to be a fake.
		return player.field_13987 == null || player.getClass() != class_3222.class;
	}

	final class Instance {
		static final @Nullable PlatformHelper INSTANCE;
		static final @Nullable Throwable ERROR;

		static {
			// We don't want class initialisation to fail here (as that results in confusing errors). Instead, capture
			// the error and rethrow it when accessing. This should be JITted away in the common case.
			var helper = Services.tryLoad(PlatformHelper.class);
			INSTANCE = helper.instance();
			ERROR = helper.error();
		}

		private Instance() {
		}
	}
}
