package com.github.litermc.vschunkloader.util;

import net.minecraft.class_243;

public interface IChunkLoaderFakePlayer {
	void bindPosition(class_243 position);

	void setDiscardCallback(Runnable callback);

	void refreshCountDown();

	void startDiscard();

	boolean isDiscarding();
}
