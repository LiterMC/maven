// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.config.ConfigFile;
import com.github.litermc.vschunkloader.network.MessageType;
import com.github.litermc.vschunkloader.network.NetworkMessage;
import com.github.litermc.vschunkloader.network.client.ClientNetworkContext;
import com.github.litermc.vschunkloader.network.container.ContainerData;

import com.google.auto.service.AutoService;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.ArgumentType;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiCache;
import net.fabricmc.fabric.api.lookup.v1.block.BlockApiLookup;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.fabricmc.fabric.api.resource.conditions.v1.DefaultResourceConditions;
import net.fabricmc.fabric.api.resource.conditions.v1.ResourceConditions;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1270;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.*;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

@AutoService(PlatformHelper.class)
public final class PlatformHelperImpl implements PlatformHelper {
	public static volatile MinecraftServer minecraftServer = null;

	@Override
	public boolean isDevelopmentEnvironment() {
		return FabricLoader.getInstance().isDevelopmentEnvironment();
	}

	@Override
	public ConfigFile.Builder createConfigBuilder() {
		return new FabricConfigFile.Builder();
	}

	@Override
	public MinecraftServer getCurrentServer() {
		return minecraftServer;
	}

	@Override
	public boolean isModLoaded(String modid) {
		return FabricLoader.getInstance().isModLoaded(modid);
	}

	@SuppressWarnings("unchecked")
	private static <T> class_2378<T> getRegistry(class_5321<class_2378<T>> id) {
		var registry = (class_2378<T>) class_7923.field_41167.method_10223(id.method_29177());
		if (registry == null) throw new IllegalArgumentException("Unknown registry " + id);
		return registry;
	}

	@Override
	public <T> class_2960 getRegistryKey(class_5321<class_2378<T>> registry, T object) {
		var key = getRegistry(registry).method_10221(object);
		if (key == null) throw new IllegalArgumentException(object + " was not registered in " + registry);
		return key;
	}

	@Override
	public <T> T getRegistryObject(class_5321<class_2378<T>> registry, class_2960 id) {
		var value = getRegistry(registry).method_10223(id);
		if (value == null) throw new IllegalArgumentException(id + " was not registered in " + registry);
		return value;
	}

	@Override
	public <T> RegistryWrappers.RegistryWrapper<T> wrap(class_5321<class_2378<T>> registry) {
		return new RegistryWrapperImpl<>(registry.method_29177(), getRegistry(registry));
	}

	@Override
	public <T> RegistrationHelper<T> createRegistrationHelper(class_5321<class_2378<T>> registry) {
		return new RegistrationHelperImpl<>(getRegistry(registry));
	}

	@Nullable
	@Override
	public <T> T tryGetRegistryObject(class_5321<class_2378<T>> registry, class_2960 id) {
		return getRegistry(registry).method_10223(id);
	}

	@Override
	public <T extends class_2586> class_2591<T> createBlockEntityType(BiFunction<class_2338, class_2680, T> factory, class_2248 block) {
		return FabricBlockEntityTypeBuilder.create(factory::apply).addBlock(block).build();
	}

	@Override
	public <C extends class_1703, T extends ContainerData> class_3917<C> createMenuType(Function<class_2540, T> reader, ContainerData.Factory<C, T> factory) {
		return new ExtendedScreenHandlerType<>((id, player, data) -> factory.create(id, player, reader.apply(data)));
	}

	@Override
	public void openMenu(class_1657 player, class_2561 title, class_1270 menu, ContainerData data) {
		player.method_17355(new WrappedMenuProvider(title, menu, data));
	}

	@Override
	public <T extends NetworkMessage<?>> MessageType<T> createMessageType(int id, class_2960 channel, Class<T> klass, class_2540.class_7461<T> reader) {
		return new FabricMessageType<>(channel, reader);
	}

	@Override
	public class_2596<class_2602> createPacket(NetworkMessage<ClientNetworkContext> message) {
		var buf = PacketByteBufs.create();
		message.write(buf);
		return ServerPlayNetworking.createS2CPacket(FabricMessageType.toFabricType(message.type()).getId(), buf);
	}

	@Override
	public class_1761.class_7913 newCreativeModeTab() {
		return FabricItemGroup.builder();
	}

	@Override
	public class_3222 createFakePlayer(class_3218 world, GameProfile name) {
		return FakePlayer.create(world, name);
	}

	private record RegistryWrapperImpl<T>(
		class_2960 name, class_2378<T> registry
	) implements RegistryWrappers.RegistryWrapper<T> {
		@Override
		public int method_10206(T object) {
			return registry.method_10206(object);
		}

		@Override
		public class_2960 getKey(T object) {
			var key = registry.method_10221(object);
			if (key == null) throw new IllegalArgumentException(object + " was not registered in " + name);
			return key;
		}

		@Override
		public T get(class_2960 location) {
			var object = registry.method_10223(location);
			if (object == null) throw new IllegalArgumentException(location + " was not registered in " + name);
			return object;
		}

		@Nullable
		@Override
		public T tryGet(class_2960 location) {
			return registry.method_10223(location);
		}

		@Override
		public @Nullable T method_10200(int id) {
			return registry.method_10200(id);
		}

		@Override
		public int method_10204() {
			return registry.method_10204();
		}

		@Override
		public Iterator<T> iterator() {
			return registry.iterator();
		}
	}

	private static final class RegistrationHelperImpl<T> implements RegistrationHelper<T> {
		private final class_2378<T> registry;
		private final List<RegistryEntryImpl<? extends T>> entries = new ArrayList<>();

		private RegistrationHelperImpl(class_2378<T> registry) {
			this.registry = registry;
		}

		@Override
		public <U extends T> RegistryEntry<U> register(String name, Supplier<U> create) {
			var entry = new RegistryEntryImpl<>(new class_2960(Constants.MOD_ID, name), create);
			entries.add(entry);
			return entry;
		}

		@Override
		public void register() {
			for (var entry : entries) entry.register(registry);
		}
	}

	private static final class RegistryEntryImpl<T> implements RegistryEntry<T> {
		private final class_2960 id;
		private final Supplier<T> supplier;
		private @Nullable T instance;

		RegistryEntryImpl(class_2960 id, Supplier<T> supplier) {
			this.id = id;
			this.supplier = supplier;
		}

		void register(class_2378<? super T> registry) {
			class_2378.method_10230(registry, id, instance = supplier.get());
		}

		@Override
		public class_2960 id() {
			return id;
		}

		@Override
		public T get() {
			if (instance == null) throw new IllegalStateException(id + " has not been constructed yet");
			return instance;
		}
	}

	private record WrappedMenuProvider(
		class_2561 title, class_1270 menu, ContainerData data
	) implements ExtendedScreenHandlerFactory {
		@Nullable
		@Override
		public class_1703 createMenu(int id, class_1661 inventory, class_1657 player) {
			return menu.createMenu(id, inventory, player);
		}

		@Override
		public class_2561 getDisplayName() {
			return title;
		}

		@Override
		public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
			data.toBytes(buf);
		}
	}
}
