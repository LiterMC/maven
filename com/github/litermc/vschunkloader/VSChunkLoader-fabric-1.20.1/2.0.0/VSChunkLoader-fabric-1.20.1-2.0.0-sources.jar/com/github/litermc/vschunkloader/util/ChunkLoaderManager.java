package com.github.litermc.vschunkloader.util;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.block.ChunkLoaderBlockEntity;
import org.joml.Vector3dc;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_18;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

public final class ChunkLoaderManager extends class_18 {
	private static final String DATA_NAME = Constants.MOD_ID + "_ChunkLoaders";
	private static final String POSITIONS_KEY = "Positions";

	private final class_3218 level;
	private final Map<class_2338, ChunkLoaderPlayerHolder> chunkLoaders = new ConcurrentHashMap<>();
	private final Map<Long, ChunkLoaderPlayerHolder> forcedShips = new ConcurrentHashMap<>();
	private final Map<class_1923, ChunkLoaderPlayerHolder> pingingRegions = new ConcurrentHashMap<>();

	private ChunkLoaderManager(final class_3218 level) {
		this.level = level;
	}

	public static ChunkLoaderManager get(final class_3218 level) {
		return level.method_17983().method_17924((data) -> ChunkLoaderManager.load(level, data), () -> new ChunkLoaderManager(level), DATA_NAME);
	}

	private static ChunkLoaderManager load(final class_3218 level, final class_2487 data) {
		final ChunkLoaderManager manager = new ChunkLoaderManager(level);
		for (final long posLong : data.method_10565(POSITIONS_KEY)) {
			final class_2338 pos = class_2338.method_10092(posLong);
			manager.chunkLoaders.put(pos, manager.createChunkLoaderHolder(pos));
		}
		return manager;
	}

	@Override
	public class_2487 method_75(final class_2487 data) {
		data.method_10564(POSITIONS_KEY, this.chunkLoaders.keySet().stream()
			.filter((pos) -> this.level.method_8321(pos) instanceof ChunkLoaderBlockEntity chunkLoader && chunkLoader.isRunning())
			.mapToLong(class_2338::method_10063)
			.toArray());
		return data;
	}

	public Stream<ChunkLoaderPlayerHolder> streamChunkLoaders() {
		return Stream.of(
			this.chunkLoaders.values().stream(),
			this.forcedShips.values().stream(),
			this.pingingRegions.values().stream()
		)
			.flatMap(Function.identity());
	}

	public void refreshChunkLoader(final class_2338 pos) {
		final ChunkLoaderPlayerHolder holder = this.chunkLoaders.compute(pos, (p, oldHolder) -> {
			final boolean noOld = oldHolder == null;
			if (noOld || oldHolder.isDiscarding()) {
				if (noOld) {
					this.method_80();
				} else {
					oldHolder.setDiscardCallback(null);
				}
				oldHolder = this.createChunkLoaderHolder(p);
			}
			return oldHolder;
		});
		holder.refresh();
	}

	public void deactivateChunkLoader(final class_2338 pos) {
		final ChunkLoaderPlayerHolder holder = this.chunkLoaders.get(pos);
		if (holder != null) {
			holder.discard();
		}
	}

	private ChunkLoaderPlayerHolder createChunkLoaderHolder(final class_2338 pos) {
		final ChunkLoaderPlayerHolder holder = ChunkLoaderPlayerHolder.createForBlock(this.level, pos);
		holder.setDiscardCallback(() -> {
			if (this.chunkLoaders.remove(pos, holder)) {
				this.method_80();
			}
		});
		return holder;
	}

	public void refreshForcedShip(final ServerShip ship) {
		final AABBic box = ship.getShipAABB();
		if (box == null) {
			return;
		}

		final class_243 position = new class_243((box.maxX() + box.minX()) / 2, (box.maxY() + box.minY()) / 2, (box.maxZ() + box.minZ()) / 2);
		final ChunkLoaderPlayerHolder holder = this.forcedShips.compute(ship.getId(), (id, oldHolder) -> {
			if (oldHolder != null) {
				if (!oldHolder.isDiscarding()) {
					oldHolder.setPosition(position);
					return oldHolder;
				}
				oldHolder.setDiscardCallback(null);
			}
			final ChunkLoaderPlayerHolder newHolder = ChunkLoaderPlayerHolder.createForShip(this.level, id, position);
			newHolder.setDiscardCallback(() -> this.forcedShips.remove(id, newHolder));
			return newHolder;
		});
		holder.refresh();
	}

	public void pingChunks(final int minX, final int maxX, final int minZ, final int maxZ) {
		final int
			minRX = this.chunkToRegionPos(minX), maxRX = this.chunkToRegionPos(maxX),
			minRZ = this.chunkToRegionPos(minZ), maxRZ = this.chunkToRegionPos(maxZ);
		for (int x = minRX; x <= maxRX; x++) {
			for (int z = minRZ; z <= maxRZ; z++) {
				this.pingRegion(x, z);
			}
		}
	}

	private int getRegionSize() {
		return this.level.method_8503().method_3760().method_38651() * 2 - 1;
	}

	private int chunkToRegionPos(final int n) {
		return Math.floorDiv(n, this.getRegionSize());
	}

	private int regionToChunkPos(final int n) {
		final int size = this.getRegionSize();
		return n * size + size / 2;
	}

	private void pingRegion(final int x, final int z) {
		final class_1923 pos0 = new class_1923(regionToChunkPos(x), regionToChunkPos(z));
		final ChunkLoaderPlayerHolder holder = this.pingingRegions.compute(pos0, (pos, oldHolder) -> {
			if (oldHolder != null) {
				if (!oldHolder.isDiscarding()) {
					return oldHolder;
				}
				oldHolder.setDiscardCallback(null);
			}
			final ChunkLoaderPlayerHolder newHolder = ChunkLoaderPlayerHolder.createFixed(this.level, new class_243(pos.method_33940(), 0, pos.method_33942()));
			newHolder.setDiscardCallback(() -> this.pingingRegions.remove(pos, newHolder));
			return newHolder;
		});
		holder.refresh();
	}
}
