// SPDX-FileCopyrightText: 2019 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader;

import com.github.litermc.vschunkloader.block.ChunkLoaderBlock;
import com.github.litermc.vschunkloader.block.ChunkLoaderBlockEntity;
import com.github.litermc.vschunkloader.block.ChunkLoaderWeakBlock;
import com.github.litermc.vschunkloader.block.ChunkLoaderWeakBlockEntity;
import com.github.litermc.vschunkloader.block.ammo.AmmoAssemblerBlock;
import com.github.litermc.vschunkloader.block.ammo.AmmoAssemblerBlockEntity;
import com.github.litermc.vschunkloader.block.ammo.AmmoManagerBlock;
import com.github.litermc.vschunkloader.block.ammo.AmmoManagerBlockEntity;
import com.github.litermc.vschunkloader.platform.PlatformHelper;
import com.github.litermc.vschunkloader.platform.RegistrationHelper;
import com.github.litermc.vschunkloader.platform.RegistryEntry;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_7924;

public final class VSCRegistry {
	private VSCRegistry() {}

	public static void register() {
		Blocks.REGISTRY.register();
		BlockEntities.REGISTRY.register();
		Items.REGISTRY.register();
		CreativeTabs.REGISTRY.register();
	}

	public static final class Blocks {
		private static final RegistrationHelper<class_2248> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41254);

		public static final RegistryEntry<AmmoAssemblerBlock> AMMO_ASSEMBLER =
			REGISTRY.register("ammo_assembler", () -> new AmmoAssemblerBlock(
				class_4970.class_2251.method_9637()
					.method_9632(5f)
					.method_9626(class_2498.field_11531)
					.method_50012(class_3619.field_15975)
					.method_26236((state, level, pos) -> false)
					.method_29292()));

		public static final RegistryEntry<AmmoManagerBlock> AMMO_MANAGER =
			REGISTRY.register("ammo_manager", () -> new AmmoManagerBlock(
				class_4970.class_2251.method_9637()
					.method_9632(10f)
					.method_9626(class_2498.field_27204)
					.method_50012(class_3619.field_15975)
					.method_26236((state, level, pos) -> false)
					.method_29292()));

		public static final RegistryEntry<ChunkLoaderBlock> CHUNK_LOADER =
			REGISTRY.register("chunk_loader", () -> new ChunkLoaderBlock(
				class_4970.class_2251.method_9637()
					.method_9632(5f)
					.method_9626(class_2498.field_11533)
					.method_50012(class_3619.field_15975)
					.method_22488()
					.method_26236((state, level, pos) -> false)
					.method_29292()));

		public static final RegistryEntry<ChunkLoaderWeakBlock> CHUNK_LOADER_WEAK =
			REGISTRY.register("chunk_loader_weak", () -> new ChunkLoaderWeakBlock(
				class_4970.class_2251.method_9637()
					.method_9632(3f)
					.method_9626(class_2498.field_11544)
					.method_50012(class_3619.field_15975)
					.method_22488()
					.method_26236((state, level, pos) -> false)
					.method_29292()));

		private Blocks() {}
	}

	public static final class BlockEntities {
		private static final RegistrationHelper<class_2591<?>> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41255);

		private static <T extends class_2586> RegistryEntry<class_2591<T>> ofBlock(final RegistryEntry<? extends class_2248> block, final BiFunction<class_2338, class_2680, T> factory) {
			return REGISTRY.register(block.id().method_12832(), () -> PlatformHelper.get().createBlockEntityType(factory, block.get()));
		}

		public static final RegistryEntry<class_2591<AmmoAssemblerBlockEntity>> AMMO_ASSEMBLER =
			ofBlock(Blocks.AMMO_ASSEMBLER, AmmoAssemblerBlockEntity::new);

		public static final RegistryEntry<class_2591<AmmoManagerBlockEntity>> AMMO_MANAGER =
			ofBlock(Blocks.AMMO_MANAGER, AmmoManagerBlockEntity::new);

		public static final RegistryEntry<class_2591<ChunkLoaderBlockEntity>> CHUNK_LOADER =
			ofBlock(Blocks.CHUNK_LOADER, ChunkLoaderBlockEntity::new);

		public static final RegistryEntry<class_2591<ChunkLoaderWeakBlockEntity>> CHUNK_LOADER_WEAK =
			ofBlock(Blocks.CHUNK_LOADER_WEAK, ChunkLoaderWeakBlockEntity::new);

		private BlockEntities() {}
	}

	public static final class Items {
		private static final RegistrationHelper<class_1792> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_41197);
		private static final List<RegistryEntry<? extends class_1792>> TAB_ITEMS = new ArrayList<>();

		private static class_1792.class_1793 properties() {
			return new class_1792.class_1793();
		}

		private static <B extends class_2248, I extends class_1792> RegistryEntry<I> ofBlock(RegistryEntry<B> block, BiFunction<B, class_1792.class_1793, I> supplier) {
			final RegistryEntry<I> entry = REGISTRY.register(block.id().method_12832(), () -> supplier.apply(block.get(), properties()));
			TAB_ITEMS.add(entry);
			return entry;
		}

		public static final RegistryEntry<class_1747> AMMO_ASSEMBLER = ofBlock(
			Blocks.AMMO_ASSEMBLER,
			(block, props) -> new class_1747(block, props.method_7894(class_1814.field_8907).method_7889(64))
		);

		public static final RegistryEntry<class_1747> AMMO_MANAGER = ofBlock(
			Blocks.AMMO_MANAGER,
			(block, props) -> new class_1747(block, props.method_7894(class_1814.field_8903).method_7889(1))
		);

		public static final RegistryEntry<class_1747> CHUNK_LOADER = ofBlock(
			Blocks.CHUNK_LOADER,
			(block, props) -> new class_1747(block, props.method_7894(class_1814.field_8904).method_7889(1))
		);

		public static final RegistryEntry<class_1747> CHUNK_LOADER_WEAK = ofBlock(
			Blocks.CHUNK_LOADER_WEAK,
			(block, props) -> new class_1747(block, props.method_7894(class_1814.field_8907).method_7889(16))
		);

		private Items() {}
	}

	static class CreativeTabs {
		static final RegistrationHelper<class_1761> REGISTRY = PlatformHelper.get().createRegistrationHelper(class_7924.field_44688);

		private static final RegistryEntry<class_1761> TAB = REGISTRY.register(
			"tab",
			() -> PlatformHelper.get().newCreativeModeTab()
				.method_47320(() -> new class_1799(Items.CHUNK_LOADER.get()))
				.method_47321(class_2561.method_43471("itemGroup.vschunkloader"))
				.method_47317((context, out) -> {
					Items.TAB_ITEMS.stream().map(RegistryEntry::get).forEach(out::method_45421);
				})
				.method_47324()
		);
	}
}
