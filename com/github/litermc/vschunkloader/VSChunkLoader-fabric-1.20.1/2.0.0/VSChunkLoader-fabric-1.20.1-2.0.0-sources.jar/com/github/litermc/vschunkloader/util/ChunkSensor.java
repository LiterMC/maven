package com.github.litermc.vschunkloader.util;

import com.github.litermc.vschunkloader.accessor.ServerLevelAccessor;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_3218;

public final class ChunkSensor {
	private final Set<class_1923> loadedChunks = ConcurrentHashMap.newKeySet();

	/**
	 * module-private
	 * DO NOT use. Use {@link get} instead.
	 */
	public ChunkSensor() {}

	public static ChunkSensor get(final class_3218 level) {
		return ((ServerLevelAccessor) (level)).vsc$getChunkSensor();
	}

	public boolean isChunkLoaded(final class_1923 pos) {
		return this.loadedChunks.contains(pos);
	}

	public boolean isChunkLoaded(final int x, final int z) {
		return this.isChunkLoaded(new class_1923(x, z));
	}

	/**
	 * module-private
	 * @param pos
	 */
	public void onChunkLoaded(final class_1923 pos) {
		this.loadedChunks.add(pos);
	}

	/**
	 * module-private
	 * @param pos
	 */
	public void onChunkUnload(final class_1923 pos) {
		this.loadedChunks.remove(pos);
	}
}
