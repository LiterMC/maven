package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import java.util.List;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_5558;

public class AmmoAssemblerBlock extends class_2318 implements class_2343 {
	public static final class_2754<AssembleResult.AssembleLED> LED = class_2754.method_11850("led", AssembleResult.AssembleLED.class);

	public AmmoAssemblerBlock(final class_2251 properties) {
		super(properties);
		this.method_9590(
			this.method_9564()
				.method_11657(class_2318.field_10927, class_2350.field_11036)
				.method_11657(LED, AssembleResult.AssembleLED.GREEN)
		);
	}

	@Override
	public void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder
			.method_11667(class_2318.field_10927)
			.method_11667(LED);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		class_2350 dir = ctx.method_7715().method_10153();
		if (ctx.method_8046()) {
			dir = dir.method_10153();
		}
		return this.method_9564()
			.method_11657(class_2318.field_10927, dir)
			.method_11657(LED, AssembleResult.AssembleLED.GREEN);
	}

	@Override
	public void method_9612(
		final class_2680 state,
		final class_1937 world,
		final class_2338 pos,
		final class_2248 neighbor,
		final class_2338 neighborPos,
		final boolean moving
	) {
		super.method_9612(state, world, pos, neighbor, neighborPos, moving);
		final AmmoAssemblerBlockEntity be = (AmmoAssemblerBlockEntity) world.method_8321(pos);
		be.neighborChanged(neighbor, neighborPos, moving);
	}

	@Override
	public AmmoAssemblerBlockEntity method_10123(final class_2338 pos, final class_2680 state) {
		return new AmmoAssemblerBlockEntity(pos, state);
	}

	@Override
	public <U extends class_2586> class_5558<U> method_31645(final class_1937 level, final class_2680 state, final class_2591<U> type) {
		if (type != VSCRegistry.BlockEntities.AMMO_ASSEMBLER.get()) {
			return null;
		}
		return level.field_9236 ? null : (level2, pos, state2, entity) -> ((AmmoAssemblerBlockEntity) (entity)).serverTick();
	}
}
