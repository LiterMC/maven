package com.github.litermc.vschunkloader.block;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.config.Config;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;

public final class ChunkLoaderWeakBlockEntity extends ChunkLoaderBlockEntity {
	private int secondsUsed = 0;

	public ChunkLoaderWeakBlockEntity(final class_2338 pos, final class_2680 state) {
		super(VSCRegistry.BlockEntities.CHUNK_LOADER_WEAK.get(), pos, state);
	}

	@Override
	public boolean isRunning() {
		return super.isRunning() && !this.isOutOfTime();
	}

	@Override
	public int getEnergyConsumeRate() {
		return Config.weakChunkLoaderEnergyConsumeRate;
	}

	public boolean isOutOfTime() {
		return this.secondsUsed >= this.getMaxActiveSeconds();
	}

	public int getMaxActiveSeconds() {
		return Config.weakChunkLoaderMaxActivateSeconds;
	}

	@Override
	public void method_11014(final class_2487 data) {
		super.method_11014(data);
		this.secondsUsed = data.method_10550("SecondsUsed");
	}

	@Override
	protected void method_11007(final class_2487 data) {
		super.method_11007(data);
		data.method_10569("SecondsUsed", this.secondsUsed);
	}

	@Override
	public void serverTick() {
		super.serverTick();
		if (this.method_11015()) {
			return;
		}
		if (this.isOutOfTime()) {
			this.method_10997().method_22352(this.method_11016(), false);
			this.method_11012();
		}
	}

	@Override
	public void onRefresh() {
		super.onRefresh();
		if (!this.isOutOfTime()) {
			this.secondsUsed++;
			this.method_5431();
		}
	}
}
