package com.github.litermc.vschunkloader.block;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.config.Config;
import com.github.litermc.vschunkloader.util.ChunkLoaderManager;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class ChunkLoaderBlockEntity extends class_2586 {
	private int activating = 0;
	private boolean wasActivated = true;
	private int energyStored = 0;

	Object energyStorage = null;

	protected ChunkLoaderBlockEntity(final class_2591<? extends ChunkLoaderBlockEntity> type, final class_2338 pos, final class_2680 state) {
		super(type, pos, state);
	}

	public ChunkLoaderBlockEntity(final class_2338 pos, final class_2680 state) {
		this(VSCRegistry.BlockEntities.CHUNK_LOADER.get(), pos, state);
	}

	public boolean isRunning() {
		return this.activating > 0;
	}

	public int receiveEnergy(final int maxReceive, final boolean simulate) {
		final int avaliable = this.getMaxEnergyStored() - this.energyStored;
		if (avaliable <= 0) {
			return 0;
		}
		final int received = Math.min(avaliable, maxReceive);
		if (!simulate) {
			this.energyStored += received;
		}
		return received;
	}

	public int getEnergyStored() {
		return this.energyStored;
	}

	/**
	 * @return energy usage in FE/s
	 */
	public int getEnergyConsumeRate() {
		return Config.chunkLoaderEnergyConsumeRate;
	}

	public int getMaxEnergyStored() {
		return this.getEnergyConsumeRate() * 4;
	}

	@Override
	public void method_11014(final class_2487 data) {
		super.method_11014(data);
		this.activating = data.method_10550("Activating");
		this.energyStored = data.method_10550("EnergyStored");
	}

	@Override
	protected void method_11007(final class_2487 data) {
		super.method_11007(data);
		data.method_10569("Activating", this.activating);
		data.method_10569("EnergyStored", this.energyStored);
	}

	public void serverTick() {
		final class_3218 level = (class_3218)(this.method_10997());
		if (level.method_8321(this.method_11016()) != this) {
			this.method_11012();
			return;
		}
		if (this.activating <= 1) {
			final int newEnergy = this.energyStored - this.getEnergyConsumeRate();
			if (newEnergy >= 0) {
				this.activating += 20;
				this.energyStored = newEnergy;
				this.method_5431();
				this.wasActivated = true;
				this.onRefresh();
			}
		}
		if (!this.isRunning()) {
			if (this.wasActivated) {
				this.wasActivated = false;
				this.onDeactivate();
				this.method_5431();
			}
			return;
		}
		this.activating--;
		this.method_5431();
	}

	public void onRefresh() {
		final class_3218 level = (class_3218)(this.method_10997());
		ChunkLoaderManager.get(level).refreshChunkLoader(this.method_11016());
	}

	public void onDeactivate() {
		final class_3218 level = (class_3218)(this.method_10997());
		ChunkLoaderManager.get(level).deactivateChunkLoader(this.method_11016());
	}
}
