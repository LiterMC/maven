// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import javax.annotation.Nullable;
import net.minecraft.class_1792;
import net.minecraft.class_1865;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2359;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_7924;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Mimics {@link class_2378} but using {@link PlatformHelper}'s recipe abstractions.
 */
public final class RegistryWrappers {
	public static final RegistryWrapper<class_1792> ITEMS = PlatformHelper.get().wrap(class_7924.field_41197);
	public static final RegistryWrapper<class_2248> BLOCKS = PlatformHelper.get().wrap(class_7924.field_41254);
	public static final RegistryWrapper<class_2591<?>> BLOCK_ENTITY_TYPES = PlatformHelper.get().wrap(class_7924.field_41255);
	public static final RegistryWrapper<class_3611> FLUIDS = PlatformHelper.get().wrap(class_7924.field_41270);
	public static final RegistryWrapper<class_1887> ENCHANTMENTS = PlatformHelper.get().wrap(class_7924.field_41265);
	public static final RegistryWrapper<class_1865<?>> RECIPE_SERIALIZERS = PlatformHelper.get().wrap(class_7924.field_41216);
	public static final RegistryWrapper<class_3917<?>> MENU = PlatformHelper.get().wrap(class_7924.field_41207);

	public interface RegistryWrapper<T> extends class_2359<T> {
		class_2960 getKey(T object);

		T get(class_2960 location);

		@Nullable
		T tryGet(class_2960 location);

		default Stream<T> stream() {
			return StreamSupport.stream(spliterator(), false);
		}
	}

	private RegistryWrappers() {}

	public static <K> void writeKey(class_2540 buf, RegistryWrapper<K> registry, K object) {
		buf.method_10812(registry.getKey(object));
	}

	public static <K> K readKey(class_2540 buf, RegistryWrapper<K> registry) {
		var id = buf.method_10810();
		return registry.get(id);
	}
}
