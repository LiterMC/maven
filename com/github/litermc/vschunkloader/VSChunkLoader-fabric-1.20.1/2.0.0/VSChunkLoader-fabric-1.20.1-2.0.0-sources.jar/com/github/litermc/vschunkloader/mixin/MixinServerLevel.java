package com.github.litermc.vschunkloader.mixin;

import com.github.litermc.vschunkloader.accessor.ChunkMapAccessor;
import com.github.litermc.vschunkloader.accessor.ServerLevelAccessor;
import com.github.litermc.vschunkloader.util.ChunkSensor;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_3218.class)
public abstract class MixinServerLevel implements ServerLevelAccessor {
	@Shadow
	public abstract class_3215 getChunkSource();

	@Override
	public ChunkSensor vsc$getChunkSensor() {
		return ((ChunkMapAccessor) (this.getChunkSource().field_17254)).vsc$getChunkSensor();
	}
}
