package com.github.litermc.vschunkloader.client;

import com.github.litermc.vschunkloader.VSCRegistry;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;

public class VSChunkLoaderClientMod implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		BlockRenderLayerMap.INSTANCE.putBlock(VSCRegistry.Blocks.CHUNK_LOADER.get(), class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(VSCRegistry.Blocks.CHUNK_LOADER_WEAK.get(), class_1921.method_23581());
	}
}
