// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

/**
 * A reference to an entry in a {@link class_2378}.
 *
 * @param <U> The type of the object registered.
 * @see RegistrationHelper
 */
public interface RegistryEntry<U> extends Supplier<U> {
	/**
	 * Get the ID of this registered item.
	 *
	 * @return This registered item.
	 */
	class_2960 id();
}
