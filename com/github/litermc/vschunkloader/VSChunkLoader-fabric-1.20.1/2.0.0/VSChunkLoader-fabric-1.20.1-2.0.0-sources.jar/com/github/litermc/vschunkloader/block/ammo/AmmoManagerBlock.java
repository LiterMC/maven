package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_5558;

public final class AmmoManagerBlock extends class_2248 implements class_2343 {
	public AmmoManagerBlock(final class_4970.class_2251 props) {
		super(props);
	}

	@Override
	public AmmoManagerBlockEntity method_10123(final class_2338 pos, final class_2680 state) {
		return new AmmoManagerBlockEntity(pos, state);
	}

	@Override
	public <T extends class_2586> class_5558<T> method_31645(final class_1937 level, final class_2680 state, final class_2591<T> type) {
		if (type != VSCRegistry.BlockEntities.AMMO_MANAGER.get()) {
			return null;
		}
		return level.field_9236 ? null : (level2, pos, state2, entity) -> ((AmmoManagerBlockEntity) (entity)).serverTick();
	}
}
