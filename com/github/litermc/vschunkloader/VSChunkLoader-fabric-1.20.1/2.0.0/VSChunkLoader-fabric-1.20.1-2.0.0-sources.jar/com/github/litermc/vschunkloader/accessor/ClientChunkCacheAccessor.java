package com.github.litermc.vschunkloader.accessor;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import net.minecraft.class_2818;

public interface ClientChunkCacheAccessor {
	Long2ObjectMap<class_2818> vsc$getShipChunks();
}
