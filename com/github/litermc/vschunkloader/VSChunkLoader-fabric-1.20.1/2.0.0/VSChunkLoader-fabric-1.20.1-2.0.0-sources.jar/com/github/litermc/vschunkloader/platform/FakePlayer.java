// SPDX-FileCopyrightText: 2022 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vschunkloader.platform;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.util.IChunkLoaderFakePlayer;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4048;
import net.minecraft.class_4050;

public final class FakePlayer extends net.fabricmc.fabric.api.entity.FakePlayer implements IChunkLoaderFakePlayer {
	private static final int COUNTDOWN = 21;
	private static final int DISCARD_TIMEOUT = 30;
	private static final class_4048 DIMENSIONS = class_4048.method_18385(0, 0);

	private class_243 position;
	private int countDown = COUNTDOWN;
	private int discarding = 0;
	private Runnable discardCallback = null;

	private FakePlayer(class_3218 serverLevel, GameProfile gameProfile) {
		super(serverLevel, gameProfile);
		this.setInvulnerable(true);
		this.refreshDimensions();
	}

	static FakePlayer create(class_3218 serverLevel, GameProfile profile) {
		return new FakePlayer(serverLevel, profile);
	}

	@Override
	protected int getPermissionLevel() {
		return 0;
	}

	@Override
	public boolean broadcastToPlayer(class_3222 player) {
		return false;
	}

	@Override
	public boolean isAttackable() {
		return false;
	}

	@Override
	public boolean isInvulnerable() {
		return true;
	}

	@Override
	public boolean canBeSeenAsEnemy() {
		return false;
	}

	@Override
	public boolean canBeSeenByAnyone() {
		return false;
	}

	@Override
	public boolean isPickable() {
		return false;
	}

	@Override
	public boolean isPushable() {
		return false;
	}

	@Override
	public boolean isInvisible() {
		return false;
	}

	@Override
	public boolean isAffectedByPotions() {
		return false;
	}

	@Override
	public boolean attackable() {
		return false;
	}

	@Override
	public boolean canTakeItem(final class_1799 stack) {
		return false;
	}

	@Override
	public class_4048 getDimensions(final class_4050 pose) {
		return DIMENSIONS;
	}

	@Override
	public float getEyeHeight(final class_4050 pose) {
		return 0;
	}

	@Override
	public float getStandingEyeHeight(final class_4050 pose, final class_4048 dims) {
		return 0;
	}

	@Override
	public void bindPosition(final class_243 position) {
		this.position = position;
	}

	@Override
	public void setDiscardCallback(final Runnable callback) {
		this.discardCallback = callback;
	}

	@Override
	public void refreshCountDown() {
		this.countDown = COUNTDOWN;
	}

	@Override
	public void startDiscard() {
		this.discarding = 1;
	}

	@Override
	public boolean isDiscarding() {
		return this.discarding > 0;
	}

	@Override
	public void tick() {
		if (this.discarding > 0) {
			this.discarding++;
			if (this.discarding > DISCARD_TIMEOUT) {
				this.discard();
				Constants.LOG.debug("FakePlayer: Discarded: {} {}", this, this.position);
				if (this.discardCallback != null) {
					this.discardCallback.run();
				}
			}
			return;
		}
		if (this.countDown <= 0) {
			Constants.LOG.debug("FakePlayer: Discarding due to out of time: {} {}", this, this.position);
			this.startDiscard();
			return;
		}
		Constants.LOG.debug("FakePlayer: ticking cd={} {} {}", this.countDown, this, this.position);
		this.setOldPosAndRot();
		this.setPos(this.position);
		this.countDown--;
		this.serverLevel().getChunkSource().move(this);
	}
}
