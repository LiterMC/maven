package com.github.litermc.vschunkloader.mixin;

import com.github.litermc.vschunkloader.platform.PlatformHelper;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_3442;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.File;

@Mixin(class_3324.class)
public class MixinPlayerList {
	@Shadow
	@Final
	private MinecraftServer server;

	@Inject(method = "getPlayerStats", at = @At("HEAD"), cancellable = true)
	public void getPlayerStats(final class_1657 player, final CallbackInfoReturnable<class_3442> cir) {
		if (!(player instanceof final class_3222 serverPlayer)) {
			return;
		}
		if (!PlatformHelper.get().isSpecialFakePlayer(serverPlayer)) {
			return;
		}
		cir.setReturnValue(new class_3442(
			this.server,
			new File(
				this.server.method_27050(class_5218.field_24181).toFile(),
				player.method_5667() + ".json"
			)
		));
	}
}
