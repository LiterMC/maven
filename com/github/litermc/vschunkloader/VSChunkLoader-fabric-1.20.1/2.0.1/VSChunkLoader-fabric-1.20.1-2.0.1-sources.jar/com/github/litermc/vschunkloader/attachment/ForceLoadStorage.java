package com.github.litermc.vschunkloader.attachment;

import com.github.litermc.vschunkloader.platform.PlatformHelper;
import com.github.litermc.vtil.api.storage.IShipAdditionalData;
import com.github.litermc.vtil.api.storage.ShipDataStorage;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.impl.game.ships.ShipData;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2960;

public final class ForceLoadStorage implements IShipAdditionalData {
	private Set<class_2960> forceLoadTokens = new HashSet<>();

	public ForceLoadStorage() {}

	public static ForceLoadStorage get(final ServerShip ship) {
		return ShipDataStorage.get(ship).getOrCreate(ForceLoadStorage.class);
	}

	@Override
	public void load(final class_2487 data) {
		data.method_10554("forceLoadTokens", class_2520.field_33258)
			.forEach((tag) -> this.forceLoadTokens.add(new class_2960(tag.method_10714())));
	}

	@Override
	public void save(final class_2487 data) {
		final class_2499 forceLoadTokens = new class_2499();
		for (final class_2960 token : this.forceLoadTokens) {
			forceLoadTokens.add(class_2519.method_23256(token.toString()));
		}
		data.method_10566("forceLoadTokens", forceLoadTokens);
	}

	public boolean isForceLoaded() {
		final PlatformHelper platform = PlatformHelper.get();
		for (final class_2960 id : this.forceLoadTokens) {
			if (platform.isModLoaded(id.method_12836())) {
				return true;
			}
		}
		return false;
	}

	public boolean isForceLoadedBy(final class_2960 token) {
		return this.forceLoadTokens.contains(token);
	}

	public void addForceLoad(final class_2960 token) {
		this.forceLoadTokens.add(token);
	}

	public void removeForceLoad(final class_2960 token) {
		this.forceLoadTokens.remove(token);
	}

	public void removeAllForceLoadTokens() {
		this.forceLoadTokens.clear();
	}

	public Set<class_2960> getAllForceLoadTokens() {
		return Collections.unmodifiableSet(this.forceLoadTokens);
	}
}
