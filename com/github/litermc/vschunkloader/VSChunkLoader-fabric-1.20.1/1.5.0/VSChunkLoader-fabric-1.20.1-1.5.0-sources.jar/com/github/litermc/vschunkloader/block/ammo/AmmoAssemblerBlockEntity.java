package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.attachment.AmmoShipAttachment;
import com.github.litermc.vschunkloader.compat.CompatMods;
import com.github.litermc.vschunkloader.config.Config;
import com.github.litermc.vtil.block.AbstractAssemblerBlockEntity;
import org.joml.Quaterniond;
import org.joml.RoundingMode;
import org.joml.Vector3d;
import org.joml.Vector3i;
import org.joml.primitives.AABBi;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5552;
import net.minecraft.class_7923;

public class AmmoAssemblerBlockEntity extends AbstractAssemblerBlockEntity {
	private static final int MAX_DIM = 8 * 16;
	private static final String AMMO_DEFAULT_SLUG_PREFIX = "+assembled+ammo+";

	private boolean triggering = false;
	private volatile AssembleResult assembleResult = AssembleResult.SUCCESS;
	private int energyStored = 0;
	private int energyConsumption = Config.ammoAssembleEnergy; // TODO
	private final AABBi box = new AABBi();

	private Runnable assembleFinishCallback = null;
	Object energyStorage = null;
	Object peripheral = null;

	public AmmoAssemblerBlockEntity(class_2338 pos, class_2680 state) {
		super(VSCRegistry.BlockEntities.AMMO_ASSEMBLER.get(), pos, state);
	}

	public boolean isAssembling() {
		return this.assembleResult.isWorking();
	}

	public boolean isAssembleSuccessed() {
		return this.assembleResult.isSuccess();
	}

	public int getEnergyConsumption() {
		return this.energyConsumption;
	}

	public AssembleResult getAssembleResult() {
		return this.assembleResult;
	}

	private void setAssembleResult(final AssembleResult result) {
		if (this.assembleResult == result) {
			return;
		}
		this.assembleResult = result;
		this.method_5431();
		this.method_10997().method_8652(this.method_11016(), this.method_11010().method_11657(AmmoAssemblerBlock.LED, result.getLED()), class_2248.field_31036);
	}

	public int receiveEnergy(final int maxReceive, final boolean simulate) {
		final int avaliable = this.getMaxEnergyStored() - this.energyStored;
		if (avaliable <= 0) {
			return 0;
		}
		final int received = Math.min(Math.min(avaliable, maxReceive), (this.getMaxEnergyStored() + 99) / 100);
		if (!simulate) {
			this.energyStored += received;
		}
		return received;
	}

	public int getEnergyStored() {
		return this.energyStored;
	}

	public int getMaxEnergyStored() {
		return this.getEnergyConsumption();
	}

	@Override
	public void method_11014(final class_2487 data) {
		this.energyStored = data.method_10550("EnergyStored");
		this.triggering = data.method_10577("Powered");
		try {
			this.assembleResult = AssembleResult.valueOf(data.method_10558("AssembleResult"));
		} catch (IllegalArgumentException e) {
			this.assembleResult = AssembleResult.SUCCESS;
		}
	}

	@Override
	public void method_11007(final class_2487 data) {
		data.method_10569("EnergyStored", this.energyStored);
		data.method_10556("Powered", this.triggering);
		this.saveShared(data);
	}

	public void saveShared(final class_2487 data) {
		data.method_10582("AssembleResult", this.assembleResult.toString());
	}

	@Override
	public class_2487 method_16887() {
		class_2487 data = super.method_16887();
		this.saveShared(data);
		return data;
	}

	@Override
	public class_2622 method_38235() {
		return class_2622.method_38585(this);
	}

	public void neighborChanged(final class_2248 neighbor, final class_2338 neighborPos, final boolean moving) {
		final class_1937 level = this.method_10997();
		final class_2338 pos = this.method_11016();
		final boolean shouldTrigger = class_2350.method_42013()
			.filter(dir -> dir != this.method_11010().method_11654(class_2318.field_10927))
			.anyMatch(dir -> level.method_49808(pos.method_10093(dir), dir) > 0);
		if (this.triggering == shouldTrigger) {
			return;
		}
		this.triggering = shouldTrigger;
		if (shouldTrigger) {
			this.startAssemble(null);
		}
	}

	Object createPeripheral() {
		final AmmoAssemblerPeripheral peripheral = new AmmoAssemblerPeripheral(this);
		this.assembleFinishCallback = peripheral::onAssembleFinish;
		return peripheral;
	}

	@Override
	public boolean startAssemble(final String slug) {
		if (this.isAssembling()) {
			return false;
		}
		if (this.energyStored < this.energyConsumption) {
			this.finishAssemble(AssembleResult.NO_ENERGY);
			return true;
		}
		return super.startAssemble(slug);
	}

	@Override
	protected void setAssembling(final boolean assembling) {
		super.setAssembling(assembling);
		if (assembling) {
			this.setAssembleResult(AssembleResult.WORKING);
		}
	}

	protected void finishAssemble(final AssembleResult result) {
		this.setAssembleResult(result);
		this.finishAssemble();
	}

	@Override
	protected void finishAssemble() {
		super.finishAssemble();
		if (this.assembleFinishCallback != null) {
			this.assembleFinishCallback.run();
		}
	}

	@Override
	protected void finishAssembleAsSuccess() {
		this.finishAssemble(AssembleResult.SUCCESS);
	}

	@Override
	protected void finishAssembleAsAssembleSelf() {
		this.finishAssemble(AssembleResult.ASSEMBLING_SELF);
	}

	@Override
	protected void finishAssembleAsTooManyBlocks() {
		this.finishAssemble(AssembleResult.TOO_MANY_BLOCKS);
	}

	@Override
	protected void finishAssembleAsNoBlockToAssemble() {
		this.finishAssemble(AssembleResult.NO_BLOCK);
	}

	@Override
	protected void finishAssembleAsConflicts() {
		this.finishAssemble(AssembleResult.OTHER_ASSEMBLING);
	}

	@Override
	protected void addAssemblingBlock(final class_2338 pos) {
		final class_1937 level = this.method_10997();
		if (!level.method_33598(pos.method_10263(), pos.method_10260())) {
			this.finishAssemble(AssembleResult.CHUNK_UNLOADED);
			return;
		}
		final class_2680 block = level.method_8320(pos);
		if (block.method_26215()) {
			return;
		}
		if (!this.canAssembleBlock(block)) {
			this.finishAssemble(AssembleResult.UNABLE_ASSEMBLE);
			return;
		}
		this.box.union(pos.method_10263(), pos.method_10264(), pos.method_10260());
		if (this.box.lengthX() > MAX_DIM || this.box.lengthY() > MAX_DIM || this.box.lengthZ() > MAX_DIM) {
			this.finishAssemble(AssembleResult.SIZE_OVERFLOW);
			return;
		}
		super.addAssemblingBlock(pos);
	}

	protected boolean canAssembleBlock(final class_2680 state) {
		final class_2248 block = state.method_26204();
		if (block instanceof class_5552) {
			return false;
		}
		final class_2960 blockId = class_7923.field_41175.method_10221(block);
		if (Config.ammoAssembleBlacklist.contains(blockId)) {
			return false;
		}
		return true;
	}

	@Override
	protected void onAssembleSuccess(final ServerShip ship) {
		if (ship.getSlug() == null) {
			ship.setSlug(AMMO_DEFAULT_SLUG_PREFIX + ship.getId());
		}
		AmmoShipAttachment.create(ship);
	}

	private static Stream<class_2338> streamBlocksInAABB(class_238 box) {
		final int
			minX = (int) (Math.round(box.field_1323)), maxX = (int) (Math.round(box.field_1320)),
			minY = (int) (Math.round(box.field_1322)), maxY = (int) (Math.round(box.field_1325)),
			minZ = (int) (Math.round(box.field_1321)), maxZ = (int) (Math.round(box.field_1324));
		final int widthX = maxX - minX, widthY = maxY - minY, widthZ = maxZ - minZ;
		return IntStream.range(0, widthX * widthY * widthZ).mapToObj((i) -> {
			final int x = i % widthX + minX;
			i /= widthX;
			final int z = i % widthZ + minZ;
			i /= widthZ;
			final int y = i + minY;
			return new class_2338(x, y, z);
		});
	}
}
