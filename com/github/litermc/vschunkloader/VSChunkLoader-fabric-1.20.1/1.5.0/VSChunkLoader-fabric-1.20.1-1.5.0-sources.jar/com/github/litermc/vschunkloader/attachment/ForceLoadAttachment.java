package com.github.litermc.vschunkloader.attachment;

import com.github.litermc.vschunkloader.platform.PlatformHelper;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import org.valkyrienskies.core.api.ships.ServerShip;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2960;

@JsonAutoDetect(
	fieldVisibility = JsonAutoDetect.Visibility.NONE,
	isGetterVisibility = JsonAutoDetect.Visibility.NONE,
	getterVisibility = JsonAutoDetect.Visibility.NONE,
	setterVisibility = JsonAutoDetect.Visibility.NONE
)
public final class ForceLoadAttachment {
	private Set<class_2960> forceLoadTokens = new HashSet<>();

	public ForceLoadAttachment() {}

	public static ForceLoadAttachment get(final ServerShip ship) {
		ForceLoadAttachment attachment = ship.getAttachment(ForceLoadAttachment.class);
		if (attachment == null) {
			attachment = new ForceLoadAttachment();
			ship.saveAttachment(ForceLoadAttachment.class, attachment);
		}
		return attachment;
	}

	@JsonGetter("forceLoadTokens")
	private Collection<String> getForceLoadTokens() {
		return this.forceLoadTokens.stream().map(class_2960::toString).toList();
	}

	@JsonSetter("forceLoadTokens")
	private void setForceLoadTokens(final Collection<String> tokens) {
		this.forceLoadTokens.clear();
		tokens.stream().map(class_2960::new).forEach(this.forceLoadTokens::add);
	}

	public boolean isForceLoaded() {
		final PlatformHelper platform = PlatformHelper.get();
		for (final class_2960 id : this.forceLoadTokens) {
			if (platform.isModLoaded(id.method_12836())) {
				return true;
			}
		}
		return false;
	}

	public boolean isForceLoadedBy(final class_2960 token) {
		return this.forceLoadTokens.contains(token);
	}

	public void addForceLoad(final class_2960 token) {
		this.forceLoadTokens.add(token);
	}

	public void removeForceLoad(final class_2960 token) {
		this.forceLoadTokens.remove(token);
	}

	public void removeAllForceLoadTokens() {
		this.forceLoadTokens.clear();
	}

	public Set<class_2960> getAllForceLoadTokens() {
		return Collections.unmodifiableSet(this.forceLoadTokens);
	}
}
