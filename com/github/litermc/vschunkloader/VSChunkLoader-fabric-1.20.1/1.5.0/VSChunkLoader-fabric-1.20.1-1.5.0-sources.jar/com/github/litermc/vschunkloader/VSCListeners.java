package com.github.litermc.vschunkloader;

import com.github.litermc.vschunkloader.attachment.ChunkSensorAttachment;
import com.github.litermc.vschunkloader.config.Config;
import com.github.litermc.vschunkloader.util.ChunkLoaderManager;
import com.github.litermc.vschunkloader.util.ChunkSensor;
import com.github.litermc.vschunkloader.util.TaskUtil;
import com.github.litermc.vtil.util.LevelUtil;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.world.ServerShipWorld;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

public final class VSCListeners {
	private VSCListeners() {}

	public static void onServerLevelLoad(final class_3218 level) {
		ChunkLoaderManager.get(level);
	}

	public static void onServerLevelUnload(final class_3218 level) {
	}

	public static void preServerTick(final MinecraftServer server) {
		TaskUtil.preServerTick();
		final ServerShipWorld shipWorld = VSGameUtilsKt.getShipObjectWorld(server);
		for (final ServerShip ship : shipWorld.getAllShips()) {
			if (Config.forceLoadAllShips) {
				final String slug = ship.getSlug();
				if (slug != null && slug.startsWith(VSCApi.REUSABLE_SHIP_SLUG_PREFIX)) {
					continue;
				}
			} else if (!VSCApi.isForceLoaded(server, ship.getId())) {
				continue;
			}
			final class_3218 level = LevelUtil.getLevel(ship.getChunkClaimDimension());
			if (level == null) {
				continue;
			}
			ChunkLoaderManager.get(level).refreshForcedShip(ship);
		}

		for (final LoadedServerShip ship : shipWorld.getLoadedShips()) {
			ChunkSensorAttachment.get(ship).serverTick(ship);
		}
	}

	public static void postServerTick(final MinecraftServer server) {
		TaskUtil.postServerTick();
	}

	public static void onServerChunkLoad(final class_3218 level, final class_2818 chunk) {
		// final ChunkPos pos = chunk.getPos();
		// if (!VSGameUtilsKt.isChunkInShipyard(level, pos.x, pos.z)) {
		// 	ChunkSensor.get(level).onChunkLoaded(pos);
		// }
	}

	public static void onServerChunkUnload(final class_3218 level, final class_2818 chunk) {
		// final ChunkPos pos = chunk.getPos();
		// if (!VSGameUtilsKt.isChunkInShipyard(level, pos.x, pos.z)) {
		// 	ChunkSensor.get(level).onChunkUnload(pos);
		// }
	}
}
