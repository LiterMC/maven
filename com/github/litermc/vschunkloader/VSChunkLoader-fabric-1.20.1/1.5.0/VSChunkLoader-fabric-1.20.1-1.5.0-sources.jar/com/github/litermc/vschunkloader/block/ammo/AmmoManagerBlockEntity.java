package com.github.litermc.vschunkloader.block.ammo;

import com.github.litermc.vschunkloader.VSCRegistry;
import com.github.litermc.vschunkloader.attachment.AmmoShipAttachment;
import com.github.litermc.vschunkloader.config.Config;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.joml.primitives.AABBd;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

public final class AmmoManagerBlockEntity extends class_2586 {
	private final AABBd manageArea;

	public AmmoManagerBlockEntity(final class_2338 pos, final class_2680 state) {
		super(VSCRegistry.BlockEntities.AMMO_MANAGER.get(), pos, state);
		final double r = Config.ammoManagerAnchoringRange;
		this.manageArea = new AABBd(pos.method_10263() - r, pos.method_10264() - r, pos.method_10260() - r, pos.method_10263() + r + 1, pos.method_10264() + r + 1, pos.method_10260() + r + 1);
	}

	public AABBd getManageArea() {
		final class_3218 level = (class_3218) (this.method_10997());
		final ServerShip ship = VSGameUtilsKt.getShipManagingPos(level, this.method_11016());
		if (ship == null) {
			return this.manageArea;
		}
		return this.manageArea.transform(ship.getShipToWorld(), new AABBd());
	}

	public void serverTick() {
		final class_3218 level = (class_3218) (this.method_10997());
		final ServerShipWorldCore world = VSGameUtilsKt.getShipObjectWorld(level);
		for (final LoadedServerShip ship : world.getLoadedShips().getIntersecting(this.getManageArea())) {
			final AmmoShipAttachment attachment = ship.getAttachment(AmmoShipAttachment.class);
			if (attachment != null) {
				attachment.managerTick();
			}
		}
	}
}
