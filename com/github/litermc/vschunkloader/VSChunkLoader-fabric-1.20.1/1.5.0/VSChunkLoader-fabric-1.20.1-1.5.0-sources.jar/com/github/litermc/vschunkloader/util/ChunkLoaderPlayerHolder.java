package com.github.litermc.vschunkloader.util;

import com.github.litermc.vschunkloader.Constants;
import com.github.litermc.vschunkloader.platform.PlatformHelper;

import com.mojang.authlib.GameProfile;
import org.valkyrienskies.core.apigame.world.IPlayer;
import org.valkyrienskies.mod.common.util.MinecraftPlayer;

import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.nio.charset.StandardCharsets;

public final class ChunkLoaderPlayerHolder {
	private static int count = 0;
	private final class_3218 level;
	private final GameProfile fakeGameProfile;
	private class_243 position;
	private IChunkLoaderFakePlayer fakePlayer;
	private IPlayer playerData;

	private ChunkLoaderPlayerHolder(final class_3218 level, final class_243 position, final String name) {
		this.level = level;
		this.position = position;
		final UUID uuid = UUID.nameUUIDFromBytes(name.getBytes(StandardCharsets.UTF_8));
		this.fakeGameProfile = new GameProfile(uuid, name);
		final class_3222 fakePlayer = PlatformHelper.get().createFakePlayer(this.level, this.fakeGameProfile);
		this.fakePlayer = ((IChunkLoaderFakePlayer)(fakePlayer));
		this.playerData = new MinecraftPlayer(fakePlayer);

		this.fakePlayer.bindPosition(this.position);
		fakePlayer.method_29495(this.position);
		this.level.method_18213(fakePlayer);
	}

	public static ChunkLoaderPlayerHolder createForBlock(final class_3218 level, final class_2338 blockPos) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating at block: {}", blockPos);
		final String name = "ChunkLoader:" + level.method_27983().method_29177().toString() + "#" + blockPos.toString();
		return new ChunkLoaderPlayerHolder(level, blockPos.method_46558(), name);
	}

	public static ChunkLoaderPlayerHolder createFixed(final class_3218 level, final class_243 position) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating fixed: {}", position);
		final int id = count++;
		final String name = "ChunkLoaderFixed:" + level.method_27983().method_29177().toString() + "#" + Integer.toString(id, 16);
		return new ChunkLoaderPlayerHolder(level, position, name);
	}

	public static ChunkLoaderPlayerHolder createForShip(final class_3218 level, final long shipId, final class_243 position) {
		Constants.LOG.debug("ChunkLoaderPlayerHolder: creating for ship: {} @ {}", shipId, position);
		final String name = "ChunkLoaderShip:" + level.method_27983().method_29177().toString() + "#" + shipId;
		return new ChunkLoaderPlayerHolder(level, position, name);
	}

	public IPlayer getPlayerData() {
		return this.playerData;
	}

	public void setDiscardCallback(final Runnable callback) {
		this.fakePlayer.setDiscardCallback(callback);
	}

	public void setPosition(final class_243 position) {
		this.position = position;
		this.fakePlayer.bindPosition(position);
	}

	public void refresh() {
		this.fakePlayer.refreshCountDown();
	}

	public void discard() {
		this.fakePlayer.startDiscard();
	}

	public boolean isDiscarding() {
		return this.fakePlayer.isDiscarding();
	}
}
