/**
 * Copyright (C) 2025  the authors of ValkyrienSkies mod
 * Modified by zyxkad  2025
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.github.litermc.vschunkloader.mixin.client;

import com.github.litermc.vschunkloader.accessor.ClientChunkCacheAccessor;

import io.netty.util.collection.LongObjectHashMap;
import io.netty.util.collection.LongObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMaps;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.valkyrienskies.core.api.ships.ClientShip;
import org.valkyrienskies.core.api.ships.properties.ChunkClaim;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.compat.SodiumCompat;
import org.valkyrienskies.mod.compat.VSRenderer;
import org.valkyrienskies.mod.mixin.ValkyrienCommonMixinConfigPlugin;
import org.valkyrienskies.mod.mixin.accessors.client.multiplayer.ClientLevelAccessor;
import org.valkyrienskies.mod.mixin.accessors.client.render.LevelRendererAccessor;
import org.valkyrienskies.mod.mixinducks.client.render.IVSViewAreaMethods;
import org.valkyrienskies.mod.mixinducks.client.world.ClientChunkCacheDuck;
import org.valkyrienskies.mod.mixinducks.mod_compat.vanilla_renderer.LevelRendererDuck;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Consumer;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_631;
import net.minecraft.class_638;
import net.minecraft.class_6603.class_6605;

/**
 * The purpose of this mixin is to allow {@link class_631} to store ship chunks.
 */
@Mixin(value = class_631.class, priority = 100) // lower priority (than 1000) for inject to runs first
public abstract class MixinClientChunkCache implements ClientChunkCacheAccessor, ClientChunkCacheDuck {
	@Unique
	private static final LongObjectMap<class_2818> EMPTY_NETTY_MAP = new LongObjectHashMap<>();

	@Shadow
	@Final
	class_638 level;

	@Unique
	private final Long2ObjectMap<class_2818> shipChunks = Long2ObjectMaps.synchronize(new Long2ObjectOpenHashMap<>());

	@Override
	public LongObjectMap<class_2818> vs$getShipChunks() {
		return EMPTY_NETTY_MAP;
	}

	@Override
	public Long2ObjectMap<class_2818> vsc$getShipChunks() {
		return this.shipChunks;
	}

	@Inject(method = "replaceWithPacketData", at = @At("HEAD"), cancellable = true)
	private void preReplaceWithPacketData(
		final int x,
		final int z,
		final class_2540 buf,
		final class_2487 tag,
		final Consumer<class_6605> consumer, 
		final CallbackInfoReturnable<class_2818> cir
	) {
		System.out.println("packet with: " + x + ", " + z);
		if (!VSGameUtilsKt.isChunkInShipyard(this.level, x, z)) {
			return;
		}
		if (class_310.method_1551().field_1769 instanceof final LevelRendererDuck levelRenderer) {
			levelRenderer.vs$setNeedsFrustumUpdate();
		}
		final class_1923 pos = new class_1923(x, z);
		final long chunkPosLong = pos.method_8324();
		final class_2818 oldChunk = this.shipChunks.get(chunkPosLong);
		final class_2818 worldChunk;
		if (oldChunk != null) {
			worldChunk = oldChunk;
			worldChunk.method_12224(buf, tag, consumer);
		} else {
			worldChunk = new class_2818(this.level, pos);
			worldChunk.method_12224(buf, tag, consumer);
			this.shipChunks.put(chunkPosLong, worldChunk);
		}

		this.level.method_23782(pos);
		SodiumCompat.onChunkAdded(this.level, x, z);
		cir.setReturnValue(worldChunk);
	}

	@Override
	public void vs$removeShip(final ClientShip ship) {
		final ChunkClaim chunks = ship.getChunkClaim();
		for (int x = chunks.getXStart(); x <= chunks.getXEnd(); x++) {
			for (int z = chunks.getZStart(); z <= chunks.getZEnd(); z++) {
				this.removeShipChunk(x, z);
			}
		}
	}

	@Unique
	private void removeShipChunk(final int chunkX, final int chunkZ) {
		final class_2818 chunk = this.shipChunks.remove(class_1923.method_8331(chunkX, chunkZ));
		if (chunk == null) {
			return;
		}
		this.level.method_18110(chunk);
		if (ValkyrienCommonMixinConfigPlugin.getVSRenderer() != VSRenderer.SODIUM) {
			((IVSViewAreaMethods) ((LevelRendererAccessor) ((ClientLevelAccessor) this.level).getLevelRenderer()).getViewArea())
				.unloadChunk(chunkX, chunkZ);
		}
		SodiumCompat.onChunkRemoved(this.level, chunkX, chunkZ);
	}

	@Inject(
		method = "getChunk(IILnet/minecraft/world/level/chunk/ChunkStatus;Z)Lnet/minecraft/world/level/chunk/LevelChunk;",
		at = @At("HEAD"),
		cancellable = true
	)
	public void preGetChunk(
		final int chunkX,
		final int chunkZ,
		final class_2806 chunkStatus,
		final boolean bl,
		final CallbackInfoReturnable<class_2818> cir
	) {
		final class_2818 shipChunk = this.shipChunks.get(class_1923.method_8331(chunkX, chunkZ));
		if (shipChunk != null) {
			cir.setReturnValue(shipChunk);
		}
	}
}
