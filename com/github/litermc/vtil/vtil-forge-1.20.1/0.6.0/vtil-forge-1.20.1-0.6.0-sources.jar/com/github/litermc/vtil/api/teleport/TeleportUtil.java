package com.github.litermc.vtil.api.teleport;

import com.github.litermc.vtil.api.entity.ISpecialTeleportLogicEntity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import org.joml.Quaterniondc;
import org.joml.Vector3dc;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.internal.ShipTeleportData;
import org.valkyrienskies.core.internal.world.VsiServerShipWorld;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.ValkyrienSkiesMod;

import java.util.List;

public class TeleportUtil {
	/**
	 * Teleport a ship with velocity and omega.
	 *
	 * @param ship Teleporting ship
	 * @param data Teleport data
	 */
	public static void teleportShip(final ServerShip ship, final TeleportData data) {
		final ServerLevel level = data.level();
		final String dimension = VSGameUtilsKt.getDimensionId(level);
		final VsiServerShipWorld world = VSGameUtilsKt.getShipObjectWorld(level);

		final long id = ship.getId();

		final Vector3dc newPos = data.newPos();
		final Quaterniondc rotation = data.rotation();
		final Vector3dc velocity = data.velocity();
		final Vector3dc omega = data.omega();
		final double scale = ship.getTransform().getShipToWorldScaling().y();

		final ShipTeleportData teleportData = ValkyrienSkiesMod.getVsCore().newShipTeleportData(
			newPos,
			rotation,
			velocity,
			omega,
			dimension,
			scale,
			ship.getTransform().getPositionInShip()
		);
		world.teleportShip(ship, teleportData);
		if (velocity.lengthSquared() != 0 || omega.lengthSquared() != 0) {
			final ServerShipTransformProvider oldProvider = ship.getTransformProvider();
			ship.setTransformProvider(new ServerShipTransformProvider() {
				@Override
				public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform prevTransform, final ShipTransform transform) {
					final LoadedServerShip ship2 = world.getLoadedShips().getById(id);
					if (!prevTransform.getPositionInWorld().equals(transform.getPositionInWorld()) || !prevTransform.getShipToWorldRotation().equals(transform.getShipToWorldRotation())) {
						ship2.setTransformProvider(oldProvider);
						return null;
					}
					if (ship2.getVelocity().lengthSquared() == 0 && ship2.getOmega().lengthSquared() == 0) {
						return new NextTransformAndVelocityData(transform, velocity, omega);
					}
					return null;
				}
			});
		}
	}

	/**
	 * Teleport an entity to another dimension with its passengers
	 *
	 * @param <T>      The entity's type
	 * @param entity   The entity going to teleport
	 * @param newLevel Target level
	 * @param newPos   Target position
	 * @return Teleported entity, or {@code null} if teleportation failed.
	 */
	public static <T extends Entity> T teleportEntity(final T entity, final ServerLevel newLevel, final Vec3 newPos) {
		return teleportEntity(entity, newLevel, newPos, false);
	}

	public static <T extends Entity> T teleportEntity(final T entity, final ServerLevel newLevel, final Vec3 newPos, final boolean inner) {
		final Vec3 oldPos = entity.m_20182_();

		if (!inner && entity instanceof final ISpecialTeleportLogicEntity specialEntity) {
			specialEntity.beforeDimentionalTeleport();
		}

		final List<Entity> passengers = List.copyOf(entity.m_20197_());
		for (final Entity p : passengers) {
			if (p instanceof final ISpecialTeleportLogicEntity specialEntity) {
				specialEntity.beforeDimentionalTeleport();
			}
		}

		final T newEntity;
		if (entity instanceof final ServerPlayer player) {
			player.m_8999_(newLevel, newPos.f_82479_, newPos.f_82480_, newPos.f_82481_, player.m_146908_(), player.m_146909_());
			newEntity = entity;
		} else {
			newEntity = (T) entity.m_6095_().m_20615_(newLevel);
			if (newEntity == null) {
				if (entity instanceof final ISpecialTeleportLogicEntity specialEntity) {
					specialEntity.afterDimentionalTeleport(null);
				}
				return null;
			}
			entity.m_20153_();
			newEntity.m_20361_(entity);
			newEntity.m_7678_(newPos.f_82479_, newPos.f_82480_, newPos.f_82481_, newEntity.m_146908_(), newEntity.m_146909_());
			newEntity.m_5616_(entity.m_6080_());
			newEntity.m_5618_(entity.m_213816_());
			newLevel.m_143334_(newEntity);
			entity.m_142467_(Entity.RemovalReason.CHANGED_DIMENSION);
		}

		for (final Entity p : passengers) {
			final Entity newPassenger = teleportEntity(p, newLevel, p.m_20182_().m_82546_(oldPos).m_82549_(newPos), true);
			if (newPassenger != null) {
				newPassenger.m_7998_(newEntity, true);
			}
		}
		if (newEntity instanceof final ISpecialTeleportLogicEntity specialEntity) {
			specialEntity.afterDimentionalTeleport((ISpecialTeleportLogicEntity) (entity));
		}
		return newEntity;
	}

	public record TeleportData(ServerLevel level, Vector3dc newPos, Quaterniondc rotation, Vector3dc velocity, Vector3dc omega) {}
}
