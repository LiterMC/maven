package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseCoralWallFanBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.WallBannerBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;

@Mixin({
	BaseCoralWallFanBlock.class,
	WallBannerBlock.class,
	WallTorchBlock.class
})
public abstract class MixinOnlyWallSupportedBlocks extends Block implements IBlockAnchor {
	protected MixinOnlyWallSupportedBlocks() {
		super(null);
	}

	@Unique
	private static BlockPos getWallPos(final BlockPos pos, final BlockState state) {
		return pos.m_121945_(state.m_61143_(HorizontalDirectionalBlock.f_54117_).m_122424_());
	}

	@Override
	public void getConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		result.add(getWallPos(pos, state));
	}

	@Override
	public boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		return getWallPos(pos, state).equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.m_60734_().getClass() != this.getClass()) {
			return true;
		}
		return oldState.m_61143_(HorizontalDirectionalBlock.f_54117_) != state.m_61143_(HorizontalDirectionalBlock.f_54117_);
	}
}
