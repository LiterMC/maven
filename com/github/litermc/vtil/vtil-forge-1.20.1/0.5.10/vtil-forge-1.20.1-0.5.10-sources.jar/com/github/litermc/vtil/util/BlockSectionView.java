package com.github.litermc.vtil.util;

import net.minecraft.core.BlockPos;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;

public final class BlockSectionView extends AbstractSet<BlockPos> {
	private final BlockPos min;
	private final BlockPos max;
	private final int count;
	private final Iterable<BlockPos> iterable;

	public BlockSectionView(final BlockPos pos1, final BlockPos pos2) {
		final int minX = Math.min(pos1.m_123341_(), pos2.m_123341_());
		final int minY = Math.min(pos1.m_123342_(), pos2.m_123342_());
		final int minZ = Math.min(pos1.m_123343_(), pos2.m_123343_());
		final int maxX = Math.max(pos1.m_123341_(), pos2.m_123341_());
		final int maxY = Math.max(pos1.m_123342_(), pos2.m_123342_());
		final int maxZ = Math.max(pos1.m_123343_(), pos2.m_123343_());
		this.min = new BlockPos(
			Math.min(pos1.m_123341_(), pos2.m_123341_()),
			Math.min(pos1.m_123342_(), pos2.m_123342_()),
			Math.min(pos1.m_123343_(), pos2.m_123343_())
		);
		this.max = new BlockPos(
			Math.max(pos1.m_123341_(), pos2.m_123341_()),
			Math.max(pos1.m_123342_(), pos2.m_123342_()),
			Math.max(pos1.m_123343_(), pos2.m_123343_())
		);
		this.count = (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
		this.iterable = BlockPos.m_121976_(minX, minY, minZ, maxX, maxY, maxZ);
	}

	@Override
	public int size() {
		return this.count;
	}

	@Override
	public Iterator<BlockPos> iterator() {
		return this.iterable.iterator();
	}

	@Override
	public boolean contains(Object obj) {
		if (!(obj instanceof final BlockPos pos)) {
			return false;
		}
		return
			this.min.m_123341_() <= pos.m_123341_() && pos.m_123341_() <= this.max.m_123341_() &&
			this.min.m_123342_() <= pos.m_123342_() && pos.m_123342_() <= this.max.m_123342_() &&
			this.min.m_123343_() <= pos.m_123343_() && pos.m_123343_() <= this.max.m_123343_();
	}

	@Override
	public boolean containsAll(final Collection<?> collections) {
		if (!(collections instanceof final BlockSectionView view)) {
			return super.containsAll(collections);
		}
		return
			this.min.m_123341_() <= view.min.m_123341_() && this.min.m_123342_() <= view.min.m_123342_() && this.min.m_123343_() <= view.min.m_123343_() &&
			this.max.m_123341_() >= view.max.m_123341_() && this.max.m_123342_() >= view.max.m_123342_() && this.max.m_123343_() >= view.max.m_123343_();
	}
}
