package com.github.litermc.vtil.api.connectivity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.material.FluidState;

import java.util.Collection;

public final class BlockConnectivityApi {
	private BlockConnectivityApi() {}

	/**
	 * Returns if the block is not possible to have any connection.
	 * E.g. air, flowing liquid.
	 *
	 * @param state The block state
	 * @return {@code true} if the block is not possible to have connection, {@code false} otherwise.
	 */
	public static final boolean isAir(final BlockState state) {
		if (state.m_60795_()) {
			return true;
		}
		if (state.m_60734_() instanceof LiquidBlock) {
			final FluidState fluidState = state.m_60819_();
			if (fluidState.m_76178_() || !fluidState.m_76170_()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if a block contains a fluid source (e.g. water logged).
	 * If so, then the block may be connected from all direction.
	 *
	 * @param state The block state
	 * @return if a block contains a fluid source.
	 */
	public static final boolean isFluidLogged(final BlockState state) {
		return state.m_61138_(BlockStateProperties.f_61362_) && state.m_61143_(BlockStateProperties.f_61362_);
	}

	/**
	 * Get any possible connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getPossibleConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		if (isFluidLogged(state)) {
			// TODO: what if getConnectableBlocks provides more than direct neighbors?
			for (final Direction dir : Direction.values()) {
				result.add(pos.m_121945_(dir));
			}
			return;
		}
		final IBlockAnchor anchor = (IBlockAnchor) (state.m_60734_());
		anchor.getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(final LevelAccessor level, final BlockPos pos, final Collection<BlockPos> result) {
		final BlockState state = level.m_8055_(pos);
		if (isAir(state)) {
			return;
		}
		getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		getPossibleConnectableBlocks(level, pos, state, result);
		result.removeIf((p) -> {
			final BlockState s = level.m_8055_(p);
			return isAir(s) || !isBlockConnectable0(level, p, s, pos, state);
		});
	}

	/**
	 * Check if two blocks are connectable.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockPos targetPos
	) {
		final BlockState state = level.m_8055_(pos);
		if (isAir(state)) {
			return false;
		}
		final BlockState targetState = level.m_8055_(targetPos);
		if (isAir(targetState)) {
			return false;
		}
		return isBlockConnectable(level, pos, state, targetPos, targetState);
	}

	/**
	 * Check if two blocks are connectable.
	 * Should not be invoked if either block is air.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		return
			isBlockConnectable0(level, pos, state, targetPos, targetState) &&
			isBlockConnectable0(level, targetPos, targetState, pos, state);
	}

	private static final boolean isBlockConnectable0(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		return
			isFluidLogged(state) ||
			((IBlockAnchor) (state.m_60734_())).isBlockConnectable(level, pos, state, targetPos, targetState);
	}

	/**
	 * Check if connectable blocks will change.
	 *
	 * @param level    World the block is in.
	 * @param pos      Position of the block.
	 * @param oldState Previous block state.
	 * @param newState Current block state.
	 */
	public static boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState newState
	) {
		if (oldState == newState) {
			return false;
		}
		if (isFluidLogged(oldState) && isFluidLogged(newState)) {
			return false;
		}
		final boolean wasAir = isAir(oldState);
		if (wasAir != isAir(newState)) {
			return true;
		}
		if (wasAir) {
			return false;
		}
		final IBlockAnchor anchor = (IBlockAnchor) (newState.m_60734_());
		return anchor.willConnectivityChange(level, pos, oldState, newState);
	}

}
