package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;

@Mixin(SlabBlock.class)
public abstract class MixinSlabBlock extends Block implements IBlockAnchor {
	protected MixinSlabBlock() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		switch (state.m_61143_(SlabBlock.f_56353_)) {
			case TOP -> {
				for (final Direction dir : Direction.values()) {
					if (dir != Direction.DOWN) {
						result.add(pos.m_121945_(dir));
					}
				}
			}
			case BOTTOM -> {
				for (final Direction dir : Direction.values()) {
					if (dir != Direction.UP) {
						result.add(pos.m_121945_(dir));
					}
				}
			}
			case DOUBLE -> {
				for (final Direction dir : Direction.values()) {
					result.add(pos.m_121945_(dir));
				}
			}
		}
	}

	@Override
	public boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		final int xDiff = targetPos.m_123341_() - pos.m_123341_();
		final int yDiff = targetPos.m_123342_() - pos.m_123342_();
		final int zDiff = targetPos.m_123343_() - pos.m_123343_();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final Direction dir = Direction.m_122378_(xDiff, yDiff, zDiff);
		return switch (state.m_61143_(SlabBlock.f_56353_)) {
			case TOP -> dir != Direction.DOWN;
			case BOTTOM -> dir != Direction.UP;
			case DOUBLE -> true;
		};
	}

	@Override
	public boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.m_60734_().getClass() != this.getClass()) {
			return true;
		}
		return oldState.m_61143_(SlabBlock.f_56353_) != state.m_61143_(SlabBlock.f_56353_);
	}
}
