package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.BasicNeighbourBlockAnchor;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;

import org.spongepowered.asm.mixin.Mixin;

@Mixin(DoorBlock.class)
public abstract class MixinDoorBlock extends Block implements BasicNeighbourBlockAnchor {
	protected MixinDoorBlock() {
		super(null);
	}

	@Override
	public boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		final int xDiff = targetPos.m_123341_() - pos.m_123341_();
		final int yDiff = targetPos.m_123342_() - pos.m_123342_();
		final int zDiff = targetPos.m_123343_() - pos.m_123343_();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final Direction dir = Direction.m_122378_(xDiff, yDiff, zDiff);
		final Direction facing = state.m_61143_(DoorBlock.f_52726_);
		return switch (dir) {
			case UP, DOWN -> true;
			default -> facing == dir ||
				(switch (state.m_61143_(DoorBlock.f_52728_)) {
					case LEFT -> facing.m_122427_();
					case RIGHT -> facing.m_122428_();
				}) == dir;
		};
	}

	@Override
	public boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState state
	) {
		if (oldState == state) {
			return false;
		}
		return oldState.m_60734_().getClass() != this.getClass();
	}
}
