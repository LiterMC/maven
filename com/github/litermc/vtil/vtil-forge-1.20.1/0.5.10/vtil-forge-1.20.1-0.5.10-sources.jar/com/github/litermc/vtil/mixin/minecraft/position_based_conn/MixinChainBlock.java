package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChainBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;

@Mixin(ChainBlock.class)
public abstract class MixinChainBlock extends Block implements IBlockAnchor {
	protected MixinChainBlock() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		switch (state.m_61143_(BlockStateProperties.f_61365_)) {
			case X -> {
				result.add(pos.m_121945_(Direction.WEST));
				result.add(pos.m_121945_(Direction.EAST));
			}
			case Y -> {
				result.add(pos.m_121945_(Direction.DOWN));
				result.add(pos.m_121945_(Direction.UP));
			}
			case Z -> {
				result.add(pos.m_121945_(Direction.NORTH));
				result.add(pos.m_121945_(Direction.SOUTH));
			}
		}
	}

	@Override
	public boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		final int xDiff = targetPos.m_123341_() - pos.m_123341_();
		final int yDiff = targetPos.m_123342_() - pos.m_123342_();
		final int zDiff = targetPos.m_123343_() - pos.m_123343_();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final Direction dir = Direction.m_122378_(xDiff, yDiff, zDiff);
		return dir.m_122434_() == state.m_61143_(BlockStateProperties.f_61365_);
	}

	@Override
	public boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.m_60734_().getClass() != this.getClass()) {
			return true;
		}
		return oldState.m_61143_(BlockStateProperties.f_61365_) != state.m_61143_(BlockStateProperties.f_61365_);
	}
}
