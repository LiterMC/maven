package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;

@Mixin(DoublePlantBlock.class)
public abstract class MixinDoublePlantBlock extends Block implements IBlockAnchor {
	protected MixinDoublePlantBlock() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final Collection<BlockPos> result
	) {
		result.add(pos.m_7495_());
		if (state.m_61143_(DoublePlantBlock.f_52858_) == DoubleBlockHalf.LOWER) {
			result.add(pos.m_7494_());
		}
	}

	@Override
	public boolean isBlockConnectable(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState state,
		final BlockPos targetPos,
		final BlockState targetState
	) {
		return
			pos.m_7495_().equals(targetPos) ||
			state.m_61143_(DoublePlantBlock.f_52858_) == DoubleBlockHalf.LOWER && pos.m_7494_().equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final LevelAccessor level,
		final BlockPos pos,
		final BlockState oldState,
		final BlockState state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.m_60734_().getClass() != this.getClass()) {
			return true;
		}
		return oldState.m_61143_(DoublePlantBlock.f_52858_) != state.m_61143_(DoublePlantBlock.f_52858_);
	}
}

