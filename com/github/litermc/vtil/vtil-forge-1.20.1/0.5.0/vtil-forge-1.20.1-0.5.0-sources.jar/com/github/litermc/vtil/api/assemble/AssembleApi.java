package com.github.litermc.vtil.api.assemble;

import com.github.litermc.vtil.compat.CompatMods;
import com.github.litermc.vtil.util.TaskUtil;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.SectionPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ChunkLevel;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.Clearable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.joml.Quaterniond;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3i;
import org.joml.primitives.AABBd;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.bodies.properties.BodyTransform;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.impl.bodies.properties.BodyTransformImpl;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.core.internal.world.VsiServerShipWorld;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

// TODO[bug]: reused ship may shift a distance / has a random inital momentum
public final class AssembleApi {
	private static final Quaterniondc ZERO_QUATD = new Quaterniond();
	private static final Vector3dc ZERO_VEC3D = new Vector3d();

	private AssembleApi() {}

	/**
	 * Assemble a ship with given blockset.
	 * If target block set is on a ship, the rotation, velocity, scale, etc. will be extended.
	 *
	 * @param level    World the blocks are in.
	 * @param blocks   Block set to assemble, must contains at least one non-air block,
	 *                 and must all in the world or on the same ship.
	 * @return The instance for created ship.
	 */
	public static ServerShip createShip(
		final ServerLevel level,
		final Set<BlockPos> blocks
	) {
		final ShipAllocator allocator = ShipAllocator.get(level.m_7654_());
		final VsiServerShipWorld shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);
		final ServerShip rootShip;

		final AABBd blocksBox = new AABBd();
		{
			final BlockPos pos = blocks.iterator().next();
			final ServerShip rootShipLoaded = VSGameUtilsKt.getShipObjectManagingPos(level, pos);
			rootShip = rootShipLoaded != null ? rootShipLoaded : VSGameUtilsKt.getShipManagingPos(level, pos);
			blocksBox.setMin(pos.m_123341_(), pos.m_123342_(), pos.m_123343_()).setMax(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		for (final BlockPos pos : blocks) {
			blocksBox.union(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3d worldCenterD = blocksBox.center(new Vector3d());
		final Vector3i worldCenter = new Vector3i(Mth.m_14107_(worldCenterD.x()), Mth.m_14107_(worldCenterD.y()), Mth.m_14107_(worldCenterD.z()));
		final ShipAllocator.ServerShipHolder shipHolder = allocator.allocShip();
		final Vector3i shipCenter = shipHolder.getShipData().getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final ServerShip ship = shipHolder.consume(new ShipTeleportDataImpl(worldCenterD, ZERO_QUATD, ZERO_VEC3D, ZERO_VEC3D, levelId, 1.0, new Vector3d(shipCenter).add(0.5, 0.5, 0.5)));
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());
		final Map<BlockPos, BlockState> blockStates = new HashMap<>(blocks.size());
		final List<Entity> attachableEntities = new ArrayList<>();

		// get attachable entities
		for (final Entity entity : level.m_45933_(null, new AABB(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
			if (entity instanceof final HangingEntity he) {
				final BlockPos hanging = he.m_31748_().m_121945_(he.m_6350_().m_122424_());
				if (blocks.contains(hanging)) {
					attachableEntities.add(entity);
				}
			} else if (CompatMods.CREATE.isLoaded()) {
				if (entity instanceof final SeatEntity seat) {
					if (blocks.contains(seat.m_20183_())) {
						attachableEntities.add(entity);
					}
				} else if (entity instanceof final SuperGlueEntity glue) {
					final AABB bb = glue.m_20191_();
					if (BlockPos.m_121921_(bb).anyMatch(blocks::contains)) {
						attachableEntities.add(entity);
					}
				}
			}
		}

		moveBlocks(level, blocks, offset, blockStates);

		if (blockStates.isEmpty()) {
			// No block present
			allocator.putShip(ship);
			return null;
		}

		// move attachable entities
		for (final Entity entity : attachableEntities) {
			final Vec3 pos = entity.m_20182_();
			entity.m_6034_(pos.f_82479_ + offset.x, pos.f_82480_ + offset.y, pos.f_82481_ + offset.z);
		}

		sendBlockUpdates(level, offset, blockStates);
		// fixShipStatus(shipWorld, ship, new Vector3d(shipCenter), new Vector3d(worldCenter), rootShip);
		return ship;
	}

	/**
	 * Assemble a ship with given blockset.
	 * Async version will create ship across multiple ticks, but still do all operations on main thread.
	 * This method still need be invoked from main thread.
	 *
	 * @param level    World the blocks are in.
	 * @param blocks   Block set to assemble, must contains at least one non-air block,
	 *                 and must all in the world or on the same ship.
	 * @param maxDelay The max ticks to delay the ship assembly. When reached the timeout,
	 *                 ship chunks will forcibly be waited in the main server thread.
	 * @return A CompletableFuture that provides the instance for created ship.
	 */
	public static CompletableFuture<ServerShip> createShipAsync(
		final ServerLevel level,
		final Set<BlockPos> blocks,
		final int maxDelay
	) {
		final BlockState AIR = Blocks.f_50016_.m_49966_();
		final ShipAllocator allocator = ShipAllocator.get(level.m_7654_());
		final VsiServerShipWorld shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);
		final int chunkLevel = ChunkLevel.m_287141_(ChunkStatus.f_62314_);
		final ServerChunkCache chunkCache = level.m_7726_();
		final ServerShip rootShip;

		final AABBd blocksBox = new AABBd();
		{
			final BlockPos pos = blocks.iterator().next();
			final ServerShip rootShipLoaded = VSGameUtilsKt.getShipObjectManagingPos(level, pos);
			rootShip = rootShipLoaded != null ? rootShipLoaded : VSGameUtilsKt.getShipManagingPos(level, pos);
			blocksBox.setMin(pos.m_123341_(), pos.m_123342_(), pos.m_123343_()).setMax(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		for (final BlockPos pos : blocks) {
			blocksBox.union(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3d worldCenterD = blocksBox.center(new Vector3d());
		final Vector3i worldCenter = new Vector3i(Mth.m_14107_(worldCenterD.x()), Mth.m_14107_(worldCenterD.y()), Mth.m_14107_(worldCenterD.z()));
		final ShipAllocator.ServerShipHolder shipHolder = allocator.allocShip();
		final Vector3i shipCenter = shipHolder.getShipData().getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());

		final ChunkPos
			minChunk = new ChunkPos(
				SectionPos.m_175552_(shipCenter.x - blocksBox.lengthX() / 2),
				SectionPos.m_175552_(shipCenter.z - blocksBox.lengthZ() / 2)
			),
			maxChunk = new ChunkPos(
				SectionPos.m_175552_(shipCenter.x + blocksBox.lengthX() / 2),
				SectionPos.m_175552_(shipCenter.z + blocksBox.lengthZ() / 2)
			);
		final List<ChunkPos> neededChunks = ChunkPos.m_45599_(minChunk, maxChunk).toList();
		// TODO: this may cause newly created ship missing collision
		for (final ChunkPos chunkPos : neededChunks) {
			chunkCache.m_6692_(chunkPos, true);
		}

		final CompletableFuture future = new CompletableFuture();

		final Runnable callback = new Runnable() {
			private int timeout = maxDelay;

			@Override
			public void run() {
				boolean allLoaded = true;
				for (final ChunkPos chunkPos : neededChunks) {
					if (chunkCache.m_7131_(chunkPos.f_45578_, chunkPos.f_45579_) == null) {
						allLoaded = false;
						break;
					}
				}
				if (!allLoaded && this.timeout > 0) {
					this.timeout--;
					TaskUtil.queueTickEnd(this);
					return;
				}
				final ServerShip ship = shipHolder.consume(new ShipTeleportDataImpl(worldCenterD, ZERO_QUATD, ZERO_VEC3D, ZERO_VEC3D, levelId, 1.0, new Vector3d(shipCenter).add(0.5, 0.5, 0.5)));

				final Map<BlockPos, BlockState> blockStates = new HashMap<>(blocks.size());
				final List<Entity> attachableEntities = new ArrayList<>();

				// get attachable entities
				for (final Entity entity : level.m_45933_(null, new AABB(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
					if (entity instanceof final HangingEntity he) {
						final BlockPos hanging = he.m_31748_().m_121945_(he.m_6350_().m_122424_());
						if (blocks.contains(hanging)) {
							attachableEntities.add(entity);
						}
					} else if (CompatMods.CREATE.isLoaded()) {
						if (entity instanceof final SeatEntity seat) {
							if (blocks.contains(seat.m_20183_())) {
								attachableEntities.add(entity);
							}
						} else if (entity instanceof final SuperGlueEntity glue) {
							final AABB bb = glue.m_20191_();
							if (BlockPos.m_121921_(bb).anyMatch(blocks::contains)) {
								attachableEntities.add(entity);
							}
						}
					}
				}

				moveBlocks(level, blocks, offset, blockStates);

				if (blockStates.isEmpty()) {
					// No block present
					future.complete(null);
					return;
				}

				// move attachable entities
				for (final Entity entity : attachableEntities) {
					final Vec3 pos = entity.m_20182_();
					entity.m_6034_(pos.f_82479_ + offset.x, pos.f_82480_ + offset.y, pos.f_82481_ + offset.z);
				}

				sendBlockUpdates(level, offset, blockStates);
				// fixShipStatus(shipWorld, ship, new Vector3d(shipCenter), new Vector3d(worldCenter), rootShip);
				future.complete(ship);
			}
		};
		TaskUtil.queueTickEnd(callback);
		return future;
	}

	private static void moveBlocks(final ServerLevel level, final Set<BlockPos> blocks, final Vector3i offset, final Map<BlockPos, BlockState> blockStates) {
		final BlockState AIR = Blocks.f_50016_.m_49966_();
		for (final BlockPos pos : blocks) {
			final BlockPos target = pos.m_7918_(offset.x, offset.y, offset.z);
			final BlockState oldState = level.m_8055_(pos);
			final boolean wasAir = oldState.m_60795_();

			final BlockEntity be = level.m_7702_(pos);
			IMoveable<?> moveableOld = MoveApi.getMover(be);
			if (moveableOld == null) {
				moveableOld = MoveApi.getMover(oldState.m_60734_());
			}
			if (moveableOld != null) {
				moveableOld.beforeSaveForMove(level, pos, target);
			}

			final BlockState state = level.m_8055_(pos);
			if (wasAir && moveableOld == null && state == oldState) {
				continue;
			}

			blockStates.put(pos.m_7949_(), state);
			final CompoundTag nbt = level.m_46745_(pos).m_8051_(pos);
			if (nbt != null) {
				final BlockPos targetPos = pos.m_7918_(offset.x, offset.y, offset.z);
				nbt.m_128405_("x", targetPos.m_123341_());
				nbt.m_128405_("y", targetPos.m_123342_());
				nbt.m_128405_("z", targetPos.m_123343_());
				level.m_46745_(targetPos).m_5604_(nbt);
			}

			final Object moveData = moveableOld != null ? moveableOld.beforeMove(level, pos, target) : null;

			level.m_46747_(pos);

			// Note: Block.UPDATE_SUPPRESS_DROPS only works for Level.destroyBlock which drop the block's item form,
			// and it does not prevent contents from dropping.
			level.m_7731_(pos, AIR, Block.f_152394_ | Block.f_152397_ | Block.f_152399_);

			level.m_7731_(target, state, Block.f_152394_ | Block.f_152397_ | Block.f_152399_);
			IMoveable<?> moveableNew = MoveApi.getMover(level.m_7702_(target));
			if (moveableNew == null) {
				moveableNew = MoveApi.getMover(state.m_60734_());
			}
			if (moveableNew != null) {
				((IMoveable) (moveableNew)).afterMove(level, pos, target, moveData);
			}
		}
	}

	private static void sendBlockUpdates(final ServerLevel level, final Vector3i offset, final Map<BlockPos, BlockState> blockStates) {
		final int MAX_BLOCK_UPDATE = 512 - 1;
		final int BLOCK_UPDATE_FLAGS = Block.f_152393_ | Block.f_152399_;
		final BlockState AIR = Blocks.f_50016_.m_49966_();

		final DenseBlockPosSet tickedAirs = new DenseBlockPosSet();
		final BlockPos.MutableBlockPos airPos = new BlockPos.MutableBlockPos();
		for (final Map.Entry<BlockPos, BlockState> entry : blockStates.entrySet()) {
			final BlockPos pos = entry.getKey();
			final BlockState state = entry.getValue();
			final Block block = state.m_60734_();
			final BlockPos targetPos = pos.m_7918_(offset.x, offset.y, offset.z);
			level.m_6289_(pos, block);
			state.m_60762_(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			AIR.m_60705_(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.m_6559_(pos, state, AIR);

			level.m_6289_(targetPos, block);
			state.m_60705_(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			state.m_60762_(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.m_6559_(targetPos, AIR, state);

			for (final Direction dir : Direction.values()) {
				airPos.m_122159_(targetPos, dir);
				if (blockStates.containsKey(airPos) || !tickedAirs.add(airPos.m_123341_(), airPos.m_123342_(), airPos.m_123343_())) {
					continue;
				}
				AIR.m_60705_(level, airPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			}
		}
	}

	// private static void fixShipStatus(
	// 	final VsiServerShipWorld shipWorld,
	// 	final ServerShip ship,
	// 	final Vector3dc shipAnchor,
	// 	final Vector3dc targetAnchor,
	// 	final ServerShip rootShip
	// ) {
	// 	// fix new ship's velocity and omega
	// 	final String dimension = ship.getChunkClaimDimension();
	// 	final Vector3d position = new Vector3d(targetAnchor);
	// 	final Quaterniond rotation = new Quaterniond();
	// 	final Vector3d velocity = new Vector3d();
	// 	final Vector3d omega = new Vector3d();
	// 	final Vector3d scaling = new Vector3d(1);

	// 	if (rootShip != null) {
	// 		final ShipTransform selfTransform = rootShip.getTransform();
	// 		selfTransform.getShipToWorld().transformPosition(position);
	// 		rotation.set(selfTransform.getShipToWorldRotation());
	// 		velocity.set(rootShip.getVelocity());
	// 		omega.set(rootShip.getOmega());
	// 		scaling.set(selfTransform.getShipToWorldScaling());
	// 	}

	// 	// TODO: for some reason the reposition can only be correct after 3 physics ticks. Investigate why and find a solution.
	// 	// shipWorld.teleportShip(ship, new ShipTeleportDataImpl(position, rotation, velocity, omega, dimension, scale));

	// 	final ServerShipTransformProvider oldProvider = ship.getTransformProvider();
	// 	ship.setTransformProvider(new ServerShipTransformProvider() {
	// 		private int count = 0;

	// 		@Override
	// 		public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform transform, final ShipTransform nextTransform) {
	// 			this.count++;
	// 			if (this.count <= 3) {
	// 				return null;
	// 			}
	// 			ship.setTransformProvider(oldProvider);
	// 			position.set(targetAnchor);
	// 			if (rootShip != null) {
	// 				final ShipTransform selfTransform2 = rootShip.getTransform();
	// 				selfTransform2.getShipToWorld().transformPosition(position);
	// 				rotation.set(selfTransform2.getShipToWorldRotation());
	// 				velocity.set(rootShip.getVelocity());
	// 				omega.set(rootShip.getOmega());
	// 				scaling.set(selfTransform2.getShipToWorldScaling());
	// 			}
	// 			final BodyTransform newTransform = new BodyTransformImpl(new Vector3d(position), new Quaterniond(rotation), new Vector3d(scaling), shipAnchor);
	// 			return new NextTransformAndVelocityData(newTransform, velocity, omega);
	// 		}
	// 	});
	// }
}
