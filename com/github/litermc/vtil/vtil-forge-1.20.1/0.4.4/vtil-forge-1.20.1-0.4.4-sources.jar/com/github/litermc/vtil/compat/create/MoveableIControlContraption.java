package com.github.litermc.vtil.compat.create;

import com.github.litermc.vtil.accessor.ContraptionHolder;
import com.github.litermc.vtil.accessor.ControlledContraptionEntityAccessor;
import com.github.litermc.vtil.api.assemble.IMoveable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;

import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;

import java.util.List;

public class MoveableIControlContraption implements IMoveable<List<AbstractContraptionEntity>> {
	public static final MoveableIControlContraption INSTANCE = new MoveableIControlContraption();

	private MoveableIControlContraption() {}

	@Override
	public List<AbstractContraptionEntity> beforeMove(final ServerLevel level, final BlockPos origin, final BlockPos target) {
		final BlockEntity be = level.m_7702_(origin);
		if (be instanceof final ContraptionHolder holder) {
			return holder.vtil$clearContraptions();
		}
		return null;
	}

	@Override
	public void afterMove(final ServerLevel level, final BlockPos origin, final BlockPos target, List<AbstractContraptionEntity> data) {
		if (data == null) {
			return;
		}
		final BlockEntity be = level.m_7702_(target);
		final Vec3i offset = target.m_121996_(origin);
		data = data.stream().map((entity) -> moveContraptionEntity(level, entity, offset)).toList();
		if (be instanceof final ContraptionHolder holder) {
			holder.vtil$restoreContraptions(data);
		}
	}

	public static AbstractContraptionEntity moveContraptionEntity(final ServerLevel level, final AbstractContraptionEntity entity, final Vec3i offset) {
		if (entity == null) {
			return null;
		}
		final Contraption contraption = entity.getContraption();
		contraption.anchor = contraption.anchor.m_121955_(offset);
		entity.m_146884_(entity.m_20182_().m_82520_(offset.m_123341_(), offset.m_123342_(), offset.m_123343_()));
		if (entity instanceof ControlledContraptionEntityAccessor ccea) {
			ccea.vtil$setControllerPos(ccea.vtil$getControllerPos().m_121955_(offset));
		}
		final AbstractContraptionEntity newEntity = (AbstractContraptionEntity) (entity.m_6095_().m_20615_(level));
		newEntity.m_20361_(entity);
		entity.m_20197_().forEach((passenger) -> {
			final Integer seat = contraption.getSeatMapping().get(passenger.m_20148_());
			if (seat != null) {
				newEntity.addSittingPassenger(passenger, seat);
			}
		});
		entity.m_142687_(Entity.RemovalReason.UNLOADED_TO_CHUNK);
		level.m_7967_(newEntity);
		return newEntity;
	}
}
