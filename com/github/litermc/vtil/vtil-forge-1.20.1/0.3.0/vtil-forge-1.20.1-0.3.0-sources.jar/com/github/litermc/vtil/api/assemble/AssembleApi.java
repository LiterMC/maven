package com.github.litermc.vtil.api.assemble;

import com.github.litermc.vtil.compat.CompatMods;
import com.github.litermc.vtil.util.Pair;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Clearable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.joml.Quaterniond;
import org.joml.RoundingMode;
import org.joml.Vector3d;
import org.joml.Vector3i;
import org.joml.primitives.AABBd;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;

import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public final class AssembleApi {
	private AssembleApi() {}

	/**
	 * Assemble a ship with given blockset.
	 *
	 * @param level    World the blocks are in.
	 * @param slug     Slug for the assembling ship.
	 * @param blocks   Block set to assemble, must contains at least one non-air block.
	 * @param rootShip Root ship for the assembling ship, or {@code null}. Rotation, velocity, scale, etc. will be extended.
	 * @return The instance for created ship.
	 */
	public static ServerShip createShip(
		final ServerLevel level,
		final Set<BlockPos> blocks,
		final ServerShip rootShip
	) {
		final BlockState AIR = Blocks.f_50016_.m_49966_();
		final ServerShipWorldCore shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);

		final AABBd blocksBox = new AABBd();
		{
			final BlockPos pos = blocks.iterator().next();
			blocksBox.setMin(pos.m_123341_(), pos.m_123342_(), pos.m_123343_()).setMax(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		for (final BlockPos pos : blocks) {
			blocksBox.union(pos.m_123341_(), pos.m_123342_(), pos.m_123343_());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3i worldCenter = new Vector3i(blocksBox.center(new Vector3d()), RoundingMode.TRUNCATE);
		final ServerShip ship = shipWorld.createNewShipAtBlock(worldCenter, false, 1.0, levelId);
		final Vector3i shipCenter = ship.getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());
		final List<Pair<BlockPos, BlockState>> blockStates = new ArrayList<>(blocks.size());
		final List<Entity> entities = new ArrayList<>();

		// get attachable entities
		for (final Entity entity : level.m_45933_(null, new AABB(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
			if (entity instanceof final HangingEntity he) {
				final BlockPos hanging = he.m_31748_().m_121945_(he.m_6350_().m_122424_());
				if (blocks.contains(hanging)) {
					entities.add(entity);
				}
			} else if (CompatMods.CREATE.isLoaded()) {
				if (entity instanceof final SeatEntity seat) {
					if (blocks.contains(seat.m_20183_())) {
						entities.add(entity);
					}
				} else if (entity instanceof final SuperGlueEntity glue) {
					final AABB bb = glue.m_20191_();
					if (streamBlocksInAABB(bb).anyMatch(blocks::contains)) {
						entities.add(entity);
					}
				}
			}
		}

		// move blocks
		for (final BlockPos pos : blocks) {
			final BlockPos target = pos.m_7918_(offset.x, offset.y, offset.z);
			final BlockState oldState = level.m_8055_(pos);
			final boolean wasAir = oldState.m_60795_();

			final BlockEntity be = level.m_7702_(pos);
			IMoveable<?> moveableOld = MoveApi.getMover(be);
			if (moveableOld == null) {
				moveableOld = MoveApi.getMover(oldState.m_60734_());
			}
			if (moveableOld != null) {
				moveableOld.beforeSaveForMove(level, pos, target);
			}

			final BlockState state = level.m_8055_(pos);
			if (wasAir && moveableOld == null && state == oldState) {
				continue;
			}

			blockStates.add(new Pair<>(pos.m_7949_(), state));
			final CompoundTag nbt = level.m_46745_(pos).m_8051_(pos);
			if (nbt != null) {
				final BlockPos targetPos = pos.m_7918_(offset.x, offset.y, offset.z);
				nbt.m_128405_("x", targetPos.m_123341_());
				nbt.m_128405_("y", targetPos.m_123342_());
				nbt.m_128405_("z", targetPos.m_123343_());
				level.m_46745_(targetPos).m_5604_(nbt);
			}

			Clearable.m_18908_(be);

			final Object moveData = moveableOld != null ? moveableOld.beforeMove(level, pos, target) : null;
			level.m_7731_(target, state, Block.f_152394_ | Block.f_152397_ | Block.f_152399_);
			// Note: Block.UPDATE_SUPPRESS_DROPS only works for Level.destroyBlock which drop the block's item form,
			// and it does not prevent contents from dropping.
			level.m_7731_(pos, AIR, Block.f_152394_ | Block.f_152397_ | Block.f_152399_);
			IMoveable<?> moveableNew = MoveApi.getMover(level.m_7702_(target));
			if (moveableNew == null) {
				moveableNew = MoveApi.getMover(state.m_60734_());
			}
			if (moveableNew != null) {
				((IMoveable) (moveableNew)).afterMove(level, pos, target, moveData);
			}
		}

		if (blockStates.isEmpty()) {
			// No block present
			shipWorld.deleteShip(ship);
			return null;
		}

		// move entities
		for (final Entity entity : entities) {
			final Vec3 pos = entity.m_20182_();
			entity.m_6034_(pos.f_82479_ + offset.x, pos.f_82480_ + offset.y, pos.f_82481_ + offset.z);
		}

		final int MAX_BLOCK_UPDATE = 512 - 1;
		final int BLOCK_UPDATE_FLAGS = Block.f_152393_ | Block.f_152399_;

		// update blocks
		for (final Pair<BlockPos, BlockState> value : blockStates) {
			final BlockPos pos = value.left();
			final BlockState state = value.right();
			final Block block = state.m_60734_();
			final BlockPos targetPos = pos.m_7918_(offset.x, offset.y, offset.z);
			level.m_6289_(pos, block);
			level.m_6289_(targetPos, block);
			state.m_60762_(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			AIR.m_60705_(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			state.m_60705_(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			state.m_60762_(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.m_6559_(pos, state, AIR);
			level.m_6559_(targetPos, AIR, state);
		}

		final AABBic box = ship.getShipAABB();
		final Vector3d absPosition = ship.getTransform().getPositionInWorld().add(ship.getInertiaData().getCenterOfMassInShip(), new Vector3d()).sub(shipCenter.x, shipCenter.y, shipCenter.z);
		final Vector3d position = new Vector3d(absPosition);
		final Quaterniond rotation = new Quaterniond();
		final Vector3d velocity = new Vector3d();
		final Vector3d omega = new Vector3d();
		final Vector3d scaling = new Vector3d(1);
		double scale = 1.0;

		if (rootShip != null) {
			final ShipTransform selfTransform = rootShip.getTransform();
			selfTransform.getShipToWorld().transformPosition(position);
			rotation.set(selfTransform.getShipToWorldRotation());
			velocity.set(rootShip.getVelocity());
			omega.set(rootShip.getOmega());
			scaling.set(selfTransform.getShipToWorldScaling());
			scale = Math.sqrt(scaling.lengthSquared() / 3);
		}
		shipWorld.teleportShip(ship, new ShipTeleportDataImpl(position, rotation, velocity, omega, levelId, scale));

		// fix new ship's velocity and omega
		if (velocity.lengthSquared() != 0 || omega.lengthSquared() != 0) {
			ship.setTransformProvider(new ServerShipTransformProvider() {
				@Override
				public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform transform, final ShipTransform nextTransform) {
					if (!transform.getPositionInWorld().equals(nextTransform.getPositionInWorld()) || !transform.getShipToWorldRotation().equals(nextTransform.getShipToWorldRotation())) {
						ship.setTransformProvider(null);
						return null;
					}
					if (ship.getVelocity().lengthSquared() == 0 && ship.getOmega().lengthSquared() == 0) {
						if (rootShip != null) {
							final ShipTransform selfTransform2 = rootShip.getTransform();
							selfTransform2.getShipToWorld().transformPosition(absPosition, position);
							rotation.set(selfTransform2.getShipToWorldRotation());
							velocity.set(rootShip.getVelocity());
							omega.set(rootShip.getOmega());
							scaling.set(selfTransform2.getShipToWorldScaling());
						}
						return new NextTransformAndVelocityData(new ShipTransformImpl(position, nextTransform.getPositionInShip(), rotation, scaling), velocity, omega);
					}
					return null;
				}
			});
		}
		return ship;
	}

	private static Stream<BlockPos> streamBlocksInAABB(AABB box) {
		final int
			minX = (int) (Math.round(box.f_82288_)), maxX = (int) (Math.round(box.f_82291_)),
			minY = (int) (Math.round(box.f_82289_)), maxY = (int) (Math.round(box.f_82292_)),
			minZ = (int) (Math.round(box.f_82290_)), maxZ = (int) (Math.round(box.f_82293_));
		final int widthX = maxX - minX, widthY = maxY - minY, widthZ = maxZ - minZ;
		return IntStream.range(0, widthX * widthY * widthZ).mapToObj((i) -> {
			final int x = i % widthX + minX;
			i /= widthX;
			final int z = i % widthZ + minZ;
			i /= widthZ;
			final int y = i + minY;
			return new BlockPos(x, y, z);
		});
	}
}
