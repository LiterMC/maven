package com.github.litermc.vtil.mixin.valkyrienskies;

import com.github.litermc.vtil.api.assemble.ShipAllocator;
import org.valkyrienskies.core.api.ships.QueryableShipData;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.mod.common.util.EntityDragger;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityDragger.class)
public class MixinEntityDragger {
	@WrapOperation(
		method = "dragEntitiesWithShips",
		at = @At(
			value = "INVOKE",
			target = "Lorg/valkyrienskies/core/api/ships/QueryableShipData;getById(J)Lorg/valkyrienskies/core/api/ships/Ship;"
		),
		remap = false
	)
	public Ship dragEntitiesWithShips$getById(
		final QueryableShipData query,
		final long id,
		final Operation<Ship> operation,
		final @Local class_1297 entity
	) {
		final class_1937 level = entity.method_37908();
		if (level instanceof final class_3218 serverLevel) {
			final ShipAllocator allocator = ShipAllocator.get(serverLevel.method_8503());
			if (allocator != null && allocator.contains(id)) {
				return null;
			}
			return operation.call(query, id);
		}
		final Ship ship = operation.call(query, id);
		if (ship == null) {
			return null;
		}
		final String slug = ship.getSlug();
		if (slug != null && slug.startsWith(ShipAllocator.REUSABLE_SHIP_SLUG_PREFIX)) {
			return null;
		}
		return ship;
	}
}
