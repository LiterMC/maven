package com.github.litermc.vtil.api.connectivity;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

public final class BlockConnectivityApi {
	private BlockConnectivityApi() {}

	/**
	 * Returns if the block is not possible to have any connection.
	 * E.g. air, flowing liquid.
	 * @return {@code true} if the block is not possible to have connection, {@code false} otherwise.
	 */
	public static final boolean isAir(final class_2680 state) {
		if (state.method_26215()) {
			return true;
		}
		if (state.method_26204() instanceof class_2404) {
			final class_3610 fluidState = state.method_26227();
			if (fluidState.method_15769() || !fluidState.method_15771()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Get any possible connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getPossibleConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		final IBlockAnchor anchor = (IBlockAnchor) (state.method_26204());
		anchor.getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(final class_1936 level, final class_2338 pos, final Collection<class_2338> result) {
		final class_2680 state = level.method_8320(pos);
		if (isAir(state)) {
			return;
		}
		getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		getPossibleConnectableBlocks(level, pos, state, result);
		result.removeIf((p) -> {
			final class_2680 s = level.method_8320(p);
			return isAir(s) || ((IBlockAnchor) (s.method_26204())).isBlockConnectable(level, p, s, pos, state);
		});
	}

	/**
	 * Check if two blocks are connectable.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2338 targetPos
	) {
		final class_2680 state = level.method_8320(pos);
		if (isAir(state)) {
			return false;
		}
		final class_2680 targetState = level.method_8320(targetPos);
		if (isAir(targetState)) {
			return false;
		}
		return isBlockConnectable(level, pos, state, targetPos, targetState);
	}

	/**
	 * Check if two blocks are connectable.
	 * Should not be invoked if either block is air.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return
			((IBlockAnchor) (state.method_26204())).isBlockConnectable(level, pos, state, targetPos, targetState) &&
			((IBlockAnchor) (targetState.method_26204())).isBlockConnectable(level, targetPos, targetState, pos, state);
	}

	/**
	 * Check if connectable blocks will change.
	 *
	 * @param level    World the block is in.
	 * @param pos      Position of the block.
	 * @param oldState Previous block state.
	 * @param newState Current block state.
	 */
	public static boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 newState
	) {
		if (oldState == newState) {
			return true;
		}
		final boolean wasAir = isAir(oldState);
		if (wasAir != isAir(newState)) {
			return true;
		}
		if (!wasAir) {
			return true;
		}
		final IBlockAnchor anchor = (IBlockAnchor) (newState.method_26204());
		return anchor.willConnectivityChange(level, pos, oldState, newState);
	}

}
