package com.github.litermc.vtil.block;

import com.github.litermc.vtil.api.assemble.AssembleApi;
import com.github.litermc.vtil.api.connectivity.BlockConnectivityApi;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public abstract class AbstractAssemblerBlockEntity extends class_2586 {
	private final class_2350 facing;
	private volatile boolean assembling = false;
	protected final Set<class_2338> blocks = new HashSet<>();
	protected final DenseBlockPosSet checked = new DenseBlockPosSet();
	protected final Queue<class_2338> queueing = new ArrayDeque<>();
	private String shipSlug = null;

	protected AbstractAssemblerBlockEntity(
		final class_2591<? extends AbstractAssemblerBlockEntity> type,
		final class_2338 pos,
		final class_2680 state
	) {
		super(type, pos, state);
		this.facing = this.method_11010().method_11654(class_2318.field_10927);
	}

	public boolean isAssembling() {
		return this.assembling;
	}

	protected void setAssembling(final boolean assembling) {
		this.assembling = assembling;
	}

	/**
	 * The maximum dimension can be assembled by the assembler
	 * @return maximum dimension can be assembled by the assembler
	 */
	public int getMaxAssembleDimension() {
		return 16 * 64;
	}

	/**
	 * The maximum blocks can be assembled by the assembler
	 * @return maximum blocks can be assembled by the assembler
	 */
	public int getMaxAssembleBlocks() {
		return 16 * 16 * 16 * 32 * 25;
	}

	/**
	 * The maximum blocks can be processed per tick.
	 * @return maximum blocks can be processed per tick.
	 */
	public int getBlockChecksPerTick() {
		return 16 * 16 * 16 * 16;
	}

	/**
	 * startAssemble should only be called from main thread.
	 */
	public boolean startAssemble(final String slug) {
		if (this.isAssembling()) {
			return false;
		}
		this.setAssembling(true);
		this.shipSlug = slug;
		this.blocks.clear();
		this.checked.clear();
		this.queueing.clear();
		final class_2338 facingBlockPos = this.method_11016().method_10093(this.facing);
		this.checked.add(facingBlockPos.method_10263(), facingBlockPos.method_10264(), facingBlockPos.method_10260());
		this.queueing.add(facingBlockPos);
		return true;
	}

	protected void finishAssemble() {
		this.setAssembling(false);
		this.shipSlug = null;
		this.queueing.clear();
		this.blocks.clear();
		this.checked.clear();
	}

	protected void finishAssembleAsSuccess() {
		this.finishAssemble();
	}

	protected void finishAssembleAsAssembleSelf() {
		this.finishAssemble();
	}

	protected void finishAssembleAsTooManyBlocks() {
		this.finishAssemble();
	}

	protected void finishAssembleAsNoBlockToAssemble() {
		this.finishAssemble();
	}

	protected void finishAssembleAsConflicts() {
		this.finishAssemble();
	}

	public void serverTick() {
		if (this.isAssembling()) {
			this.assembleTick((class_3218) (this.method_10997()));
		}
	}

	private void assembleTick(final class_3218 level) {
		final int maxAssembleBlocks = this.getMaxAssembleBlocks();
		final int blockChecksPerTick = this.getBlockChecksPerTick();
		final class_2338 selfPos = this.method_11016();
		int ticked = 0;
		while (true) {
			final class_2338 pos = this.queueing.poll();
			if (pos == null) {
				this.checked.clear();
				if (ticked > 0) {
					return;
				}
				break;
			}
			if (this.blocks.size() > maxAssembleBlocks) {
				this.finishAssembleAsTooManyBlocks();
				return;
			}
			if (pos.equals(selfPos)) {
				this.finishAssembleAsAssembleSelf();
				return;
			}
			this.addAssemblingBlock(pos);
			if (!this.isAssembling()) {
				return;
			}
			ticked++;
			if (ticked > blockChecksPerTick) {
				return;
			}
		}
		if (this.blocks.isEmpty()) {
			this.finishAssembleAsNoBlockToAssemble();
			return;
		}

		final ServerShip ship = this.createShip(level, this.blocks);
		if (ship == null) {
			return;
		}
		this.onAssembleSuccess(ship);
	}

	protected void addAssemblingBlock(final class_2338 pos) {
		if (BlockConnectivityApi.isAir(this.method_10997().method_8320(pos))) {
			return;
		}
		this.blocks.add(pos);
		for (final class_2338 p : this.queryNextBlocks(pos)) {
			final class_2680 targetState = field_11863.method_8320(p);
			if (field_11863.method_8321(p) instanceof final AbstractAssemblerBlockEntity otherAssembler) {
				if (this != otherAssembler && otherAssembler.isAssembling()) {
					this.finishAssembleAsConflicts();
					return;
				}
				continue;
			}
			if (this.checked.add(p.method_10263(), p.method_10264(), p.method_10260())) {
				this.queueing.add(p.method_10062());
			}
		}
	}

	protected Iterable<class_2338> queryNextBlocks(final class_2338 pos) {
		final Set<class_2338> result = new HashSet<>(6);
		BlockConnectivityApi.getConnectableBlocks(this.method_10997(), pos, result);
		return result;
	}

	protected ServerShip createShip(final class_3218 level, final Set<class_2338> blocks) {
		final ServerShip ship = AssembleApi.createShip(level, blocks, VSGameUtilsKt.getShipManagingPos(level, this.method_11016()));
		if (ship == null) {
			this.finishAssembleAsNoBlockToAssemble();
			return null;
		}
		ship.setSlug(this.shipSlug);
		this.finishAssembleAsSuccess();
		return ship;
	}

	protected void onAssembleSuccess(final ServerShip ship) {}
}
