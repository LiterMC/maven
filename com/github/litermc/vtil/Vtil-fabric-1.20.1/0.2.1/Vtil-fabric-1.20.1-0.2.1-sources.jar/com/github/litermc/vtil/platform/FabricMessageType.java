// SPDX-FileCopyrightText: 2023 The CC: Tweaked Developers
//
// SPDX-License-Identifier: MPL-2.0

package com.github.litermc.vtil.platform;

import com.github.litermc.vtil.network.MessageType;
import com.github.litermc.vtil.network.NetworkMessage;
import net.fabricmc.fabric.api.networking.v1.FabricPacket;
import net.fabricmc.fabric.api.networking.v1.PacketType;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import java.util.function.Function;

/**
 * An implementation of {@link MessageType} for Fabric.
 * <p>
 * This provides conversions between the {@link FabricPacket}/{@link PacketType} and {@link NetworkMessage}/{@link MessageType}
 * interfaces, allowing us to interop between the two.
 *
 * @param type The underlying {@link PacketType}
 * @param <T>  The type of the message.
 */
public record FabricMessageType<T extends NetworkMessage<?>>(
    PacketType<PacketWrapper<T>> type
) implements MessageType<T> {
    public FabricMessageType(class_2960 id, Function<class_2540, T> reader) {
        this(PacketType.create(id, b -> new PacketWrapper<>(reader.apply(b))));
    }

    public static <T extends NetworkMessage<?>> PacketType<PacketWrapper<T>> toFabricType(MessageType<T> type) {
        return ((FabricMessageType<T>) type).type();
    }

    public static FabricPacket toFabricPacket(NetworkMessage<?> message) {
        return new PacketWrapper<>(message);
    }

    public record PacketWrapper<T extends NetworkMessage<?>>(T payload) implements FabricPacket {
        @Override
        public void write(class_2540 buf) {
            payload().write(buf);
        }

        @Override
        public PacketType<?> getType() {
            return FabricMessageType.toFabricType(payload().type());
        }
    }
}
