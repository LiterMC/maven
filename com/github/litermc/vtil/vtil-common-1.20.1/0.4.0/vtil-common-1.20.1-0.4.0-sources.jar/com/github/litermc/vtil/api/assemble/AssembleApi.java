package com.github.litermc.vtil.api.assemble;

import com.github.litermc.vtil.compat.CompatMods;
import com.github.litermc.vtil.util.TaskUtil;
import org.joml.Quaterniond;
import org.joml.Quaterniondc;
import org.joml.Vector3d;
import org.joml.Vector3dc;
import org.joml.Vector3i;
import org.joml.primitives.AABBd;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1297;
import net.minecraft.class_1530;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2806;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3829;
import net.minecraft.class_4076;
import net.minecraft.class_8563;

public final class AssembleApi {
	private static final Quaterniondc ZERO_QUATD = new Quaterniond();
	private static final Vector3dc ZERO_VEC3D = new Vector3d();

	private AssembleApi() {}

	/**
	 * Assemble a ship with given blockset.
	 * If target block set is on a ship, the rotation, velocity, scale, etc. will be extended.
	 *
	 * @param level    World the blocks are in.
	 * @param blocks   Block set to assemble, must contains at least one non-air block,
	 *                 and must all in the world or on the same ship.
	 * @return The instance for created ship.
	 */
	public static ServerShip createShip(
		final class_3218 level,
		final Set<class_2338> blocks
	) {
		final ShipAllocator allocator = ShipAllocator.get(level.method_8503());
		final ServerShipWorldCore shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);
		final ServerShip rootShip;

		final AABBd blocksBox = new AABBd();
		{
			final class_2338 pos = blocks.iterator().next();
			final ServerShip rootShipLoaded = VSGameUtilsKt.getShipObjectManagingPos(level, pos);
			rootShip = rootShipLoaded != null ? rootShipLoaded : VSGameUtilsKt.getShipManagingPos(level, pos);
			blocksBox.setMin(pos.method_10263(), pos.method_10264(), pos.method_10260()).setMax(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		for (final class_2338 pos : blocks) {
			blocksBox.union(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3d worldCenterD = blocksBox.center(new Vector3d());
		final Vector3i worldCenter = new Vector3i(class_3532.method_15357(worldCenterD.x()), class_3532.method_15357(worldCenterD.y()), class_3532.method_15357(worldCenterD.z()));
		final ServerShip ship = allocator.allocShip()
			.consume(new ShipTeleportDataImpl(worldCenterD, ZERO_QUATD, ZERO_VEC3D, ZERO_VEC3D, levelId, 1.0));
		final Vector3i shipCenter = ship.getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());
		final Map<class_2338, class_2680> blockStates = new HashMap<>(blocks.size());
		final List<class_1297> attachableEntities = new ArrayList<>();

		// get attachable entities
		for (final class_1297 entity : level.method_8335(null, new class_238(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
			if (entity instanceof final class_1530 he) {
				final class_2338 hanging = he.method_6896().method_10093(he.method_5735().method_10153());
				if (blocks.contains(hanging)) {
					attachableEntities.add(entity);
				}
			} else if (CompatMods.CREATE.isLoaded()) {
				if (entity instanceof final SeatEntity seat) {
					if (blocks.contains(seat.method_24515())) {
						attachableEntities.add(entity);
					}
				} else if (entity instanceof final SuperGlueEntity glue) {
					final class_238 bb = glue.method_5829();
					if (class_2338.method_29715(bb).anyMatch(blocks::contains)) {
						attachableEntities.add(entity);
					}
				}
			}
		}

		moveBlocks(level, blocks, offset, blockStates);

		if (blockStates.isEmpty()) {
			// No block present
			allocator.putShip(ship);
			return null;
		}

		// move attachable entities
		for (final class_1297 entity : attachableEntities) {
			final class_243 pos = entity.method_19538();
			entity.method_5814(pos.field_1352 + offset.x, pos.field_1351 + offset.y, pos.field_1350 + offset.z);
		}

		sendBlockUpdates(level, offset, blockStates);
		fixShipStatus(shipWorld, ship, new Vector3d(shipCenter), new Vector3d(worldCenter), rootShip);
		return ship;
	}

	/**
	 * Assemble a ship with given blockset.
	 * Async version will create ship across multiple ticks, but still do all operations on main thread.
	 * This method still need be invoked from main thread.
	 *
	 * @param level    World the blocks are in.
	 * @param blocks   Block set to assemble, must contains at least one non-air block,
	 *                 and must all in the world or on the same ship.
	 * @param maxDelay The max ticks to delay the ship assembly. When reached the timeout,
	 *                 ship chunks will forcibly be waited in the main server thread.
	 * @return A CompletableFuture that provides the instance for created ship.
	 */
	public static CompletableFuture<ServerShip> createShipAsync(
		final class_3218 level,
		final Set<class_2338> blocks,
		final int maxDelay
	) {
		final class_2680 AIR = class_2246.field_10124.method_9564();
		final ShipAllocator allocator = ShipAllocator.get(level.method_8503());
		final ServerShipWorldCore shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);
		final int chunkLevel = class_8563.method_51829(class_2806.field_12798);
		final class_3215 chunkCache = level.method_14178();
		final ServerShip rootShip;

		final AABBd blocksBox = new AABBd();
		{
			final class_2338 pos = blocks.iterator().next();
			final ServerShip rootShipLoaded = VSGameUtilsKt.getShipObjectManagingPos(level, pos);
			rootShip = rootShipLoaded != null ? rootShipLoaded : VSGameUtilsKt.getShipManagingPos(level, pos);
			blocksBox.setMin(pos.method_10263(), pos.method_10264(), pos.method_10260()).setMax(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		for (final class_2338 pos : blocks) {
			blocksBox.union(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3d worldCenterD = blocksBox.center(new Vector3d());
		final Vector3i worldCenter = new Vector3i(class_3532.method_15357(worldCenterD.x()), class_3532.method_15357(worldCenterD.y()), class_3532.method_15357(worldCenterD.z()));
		final ShipAllocator.ServerShipHolder shipHolder = allocator.allocShip();
		final Vector3i shipCenter = shipHolder.getShipData().getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());

		final class_1923
			minChunk = new class_1923(
				class_4076.method_32204(shipCenter.x - blocksBox.lengthX() / 2),
				class_4076.method_32204(shipCenter.z - blocksBox.lengthZ() / 2)
			),
			maxChunk = new class_1923(
				class_4076.method_32204(shipCenter.x + blocksBox.lengthX() / 2),
				class_4076.method_32204(shipCenter.z + blocksBox.lengthZ() / 2)
			);
		final List<class_1923> neededChunks = class_1923.method_19281(minChunk, maxChunk).toList();
		// TODO: this may cause newly created ship missing collision
		for (final class_1923 chunkPos : neededChunks) {
			chunkCache.method_12124(chunkPos, true);
		}

		final CompletableFuture future = new CompletableFuture();

		final Runnable callback = new Runnable() {
			private int timeout = maxDelay;

			@Override
			public void run() {
				boolean allLoaded = true;
				for (final class_1923 chunkPos : neededChunks) {
					if (chunkCache.method_21730(chunkPos.field_9181, chunkPos.field_9180) == null) {
						allLoaded = false;
						break;
					}
				}
				if (!allLoaded && this.timeout > 0) {
					this.timeout--;
					TaskUtil.queueTickEnd(this);
					return;
				}
				final ServerShip ship = shipHolder.consume(new ShipTeleportDataImpl(worldCenterD, ZERO_QUATD, ZERO_VEC3D, ZERO_VEC3D, levelId, 1.0));

				final Map<class_2338, class_2680> blockStates = new HashMap<>(blocks.size());
				final List<class_1297> attachableEntities = new ArrayList<>();

				// get attachable entities
				for (final class_1297 entity : level.method_8335(null, new class_238(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
					if (entity instanceof final class_1530 he) {
						final class_2338 hanging = he.method_6896().method_10093(he.method_5735().method_10153());
						if (blocks.contains(hanging)) {
							attachableEntities.add(entity);
						}
					} else if (CompatMods.CREATE.isLoaded()) {
						if (entity instanceof final SeatEntity seat) {
							if (blocks.contains(seat.method_24515())) {
								attachableEntities.add(entity);
							}
						} else if (entity instanceof final SuperGlueEntity glue) {
							final class_238 bb = glue.method_5829();
							if (class_2338.method_29715(bb).anyMatch(blocks::contains)) {
								attachableEntities.add(entity);
							}
						}
					}
				}

				moveBlocks(level, blocks, offset, blockStates);

				if (blockStates.isEmpty()) {
					// No block present
					future.complete(null);
					return;
				}

				// move attachable entities
				for (final class_1297 entity : attachableEntities) {
					final class_243 pos = entity.method_19538();
					entity.method_5814(pos.field_1352 + offset.x, pos.field_1351 + offset.y, pos.field_1350 + offset.z);
				}

				sendBlockUpdates(level, offset, blockStates);
				fixShipStatus(shipWorld, ship, new Vector3d(shipCenter), new Vector3d(worldCenter), rootShip);
				future.complete(ship);
			}
		};
		TaskUtil.queueTickEnd(callback);
		return future;
	}

	private static void moveBlocks(final class_3218 level, final Set<class_2338> blocks, final Vector3i offset, final Map<class_2338, class_2680> blockStates) {
		final class_2680 AIR = class_2246.field_10124.method_9564();
		for (final class_2338 pos : blocks) {
			final class_2338 target = pos.method_10069(offset.x, offset.y, offset.z);
			final class_2680 oldState = level.method_8320(pos);
			final boolean wasAir = oldState.method_26215();

			final class_2586 be = level.method_8321(pos);
			IMoveable<?> moveableOld = MoveApi.getMover(be);
			if (moveableOld == null) {
				moveableOld = MoveApi.getMover(oldState.method_26204());
			}
			if (moveableOld != null) {
				moveableOld.beforeSaveForMove(level, pos, target);
			}

			final class_2680 state = level.method_8320(pos);
			if (wasAir && moveableOld == null && state == oldState) {
				continue;
			}

			blockStates.put(pos.method_10062(), state);
			final class_2487 nbt = level.method_8500(pos).method_20598(pos);
			if (nbt != null) {
				final class_2338 targetPos = pos.method_10069(offset.x, offset.y, offset.z);
				nbt.method_10569("x", targetPos.method_10263());
				nbt.method_10569("y", targetPos.method_10264());
				nbt.method_10569("z", targetPos.method_10260());
				level.method_8500(targetPos).method_12042(nbt);
			}

			class_3829.method_16825(be);

			final Object moveData = moveableOld != null ? moveableOld.beforeMove(level, pos, target) : null;

			// Note: Block.UPDATE_SUPPRESS_DROPS only works for Level.destroyBlock which drop the block's item form,
			// and it does not prevent contents from dropping.
			level.method_8652(pos, AIR, class_2248.field_31028 | class_2248.field_31031 | class_2248.field_31033);

			level.method_8652(target, state, class_2248.field_31028 | class_2248.field_31031 | class_2248.field_31033);
			IMoveable<?> moveableNew = MoveApi.getMover(level.method_8321(target));
			if (moveableNew == null) {
				moveableNew = MoveApi.getMover(state.method_26204());
			}
			if (moveableNew != null) {
				((IMoveable) (moveableNew)).afterMove(level, pos, target, moveData);
			}
		}
	}

	private static void sendBlockUpdates(final class_3218 level, final Vector3i offset, final Map<class_2338, class_2680> blockStates) {
		final int MAX_BLOCK_UPDATE = 512 - 1;
		final int BLOCK_UPDATE_FLAGS = class_2248.field_31027 | class_2248.field_31033;
		final class_2680 AIR = class_2246.field_10124.method_9564();

		final DenseBlockPosSet tickedAirs = new DenseBlockPosSet();
		final class_2338.class_2339 airPos = new class_2338.class_2339();
		for (final Map.Entry<class_2338, class_2680> entry : blockStates.entrySet()) {
			final class_2338 pos = entry.getKey();
			final class_2680 state = entry.getValue();
			final class_2248 block = state.method_26204();
			final class_2338 targetPos = pos.method_10069(offset.x, offset.y, offset.z);
			level.method_8408(pos, block);
			state.method_26198(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			AIR.method_26183(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.method_19282(pos, state, AIR);

			level.method_8408(targetPos, block);
			state.method_26183(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			state.method_26198(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.method_19282(targetPos, AIR, state);

			for (final class_2350 dir : class_2350.values()) {
				airPos.method_25505(targetPos, dir);
				if (blockStates.containsKey(airPos) || !tickedAirs.add(airPos.method_10263(), airPos.method_10264(), airPos.method_10260())) {
					continue;
				}
				AIR.method_26183(level, airPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			}
		}
	}

	private static void fixShipStatus(
		final ServerShipWorldCore shipWorld,
		final ServerShip ship,
		final Vector3dc shipAnchor,
		final Vector3dc targetAnchor,
		final ServerShip rootShip
	) {
		final String dimension = ship.getChunkClaimDimension();
		final Vector3d absPosition = ship.getTransform().getPositionInShip().sub(shipAnchor, new Vector3d()).add(targetAnchor);
		final Vector3d position = new Vector3d(absPosition);
		final Quaterniond rotation = new Quaterniond();
		final Vector3d velocity = new Vector3d();
		final Vector3d omega = new Vector3d();
		final Vector3d scaling = new Vector3d(1);
		double scale = 1.0;

		if (rootShip != null) {
			final ShipTransform selfTransform = rootShip.getTransform();
			selfTransform.getShipToWorld().transformPosition(position);
			rotation.set(selfTransform.getShipToWorldRotation());
			velocity.set(rootShip.getVelocity());
			omega.set(rootShip.getOmega());
			scaling.set(selfTransform.getShipToWorldScaling());
			scale = Math.sqrt(scaling.lengthSquared() / 3);
		}
		shipWorld.teleportShip(ship, new ShipTeleportDataImpl(position, rotation, velocity, omega, dimension, scale));

		// fix new ship's velocity and omega
		if (velocity.lengthSquared() != 0 || omega.lengthSquared() != 0) {
			final ServerShipTransformProvider oldProvider = ship.getTransformProvider();
			ship.setTransformProvider(new ServerShipTransformProvider() {
				@Override
				public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform transform, final ShipTransform nextTransform) {
					if (!transform.getPositionInWorld().equals(nextTransform.getPositionInWorld()) || !transform.getShipToWorldRotation().equals(nextTransform.getShipToWorldRotation())) {
						ship.setTransformProvider(oldProvider);
						return null;
					}
					if (rootShip != null) {
						final ShipTransform selfTransform2 = rootShip.getTransform();
						selfTransform2.getShipToWorld().transformPosition(absPosition, position);
						rotation.set(selfTransform2.getShipToWorldRotation());
						velocity.set(rootShip.getVelocity());
						omega.set(rootShip.getOmega());
						scaling.set(selfTransform2.getShipToWorldScaling());
					}
					return new NextTransformAndVelocityData(new ShipTransformImpl(position, nextTransform.getPositionInShip(), rotation, scaling), velocity, omega);
				}
			});
		}
	}
}
