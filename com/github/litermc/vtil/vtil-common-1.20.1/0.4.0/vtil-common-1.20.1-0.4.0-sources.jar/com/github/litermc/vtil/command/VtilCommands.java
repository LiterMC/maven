package com.github.litermc.vtil.command;

import com.github.litermc.vtil.Constants;
import com.github.litermc.vtil.api.assemble.AssembleApi;
import com.github.litermc.vtil.api.assemble.ShipAllocator;
import com.github.litermc.vtil.util.BlockSectionView;
import com.github.litermc.vtil.util.LevelUtil;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.Ship;
import org.valkyrienskies.mod.common.command.ShipArgument;
import org.valkyrienskies.mod.mixinducks.feature.command.VSCommandSource;

import java.util.Set;

public final class VtilCommands {
	public static final String ROOT_LITERAL = Constants.MOD_ID;

	private VtilCommands() {}

	public static void register(final CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247(ROOT_LITERAL)
			.requires((source) -> source.method_9259(2))
			.then(class_2170.method_9247("assemble")
				.then(class_2170.method_9244("from", class_2262.method_9698())
					.then(class_2170.method_9244("to", class_2262.method_9698())
						.then(class_2170.method_9244("slug", StringArgumentType.word())
							.executes((ctx) -> assemble(ctx, true))
						)
						.executes((ctx) -> assemble(ctx, false))
					)
				)
			)
			.then(class_2170.method_9247("assemble-async")
				.then(class_2170.method_9244("from", class_2262.method_9698())
					.then(class_2170.method_9244("to", class_2262.method_9698())
						.then(class_2170.method_9244("slug", StringArgumentType.word())
							.executes((ctx) -> assembleAsync(ctx, true))
						)
						.executes((ctx) -> assembleAsync(ctx, false))
					)
				)
			)
			.then(class_2170.method_9247("delete")
				.then(class_2170.method_9244("ships", ShipArgument.Companion.ships())
					.executes(VtilCommands::delete)
				)
			)
		);
	}

	private static int assemble(final CommandContext<class_2168> context, final boolean hasSlug) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final class_3218 level = source.method_9225();
		final class_2338 from = class_2262.method_9696(context, "from");
		final class_2338 to = class_2262.method_9696(context, "to");
		final BlockSectionView blocks = new BlockSectionView(from, to);

		final ServerShip ship = AssembleApi.createShip(level, blocks);

		if (ship == null) {
			source.method_9213(class_2561.method_43471("vtil.command.assemble.empty"));
			return 0;
		}

		final String slug = hasSlug ? StringArgumentType.getString(context, "slug") : "+assemble+" + ship.getId();
		ship.setSlug(slug);
		source.method_9226(() -> class_2561.method_43469("vtil.command.assemble.success", slug), true);
		return (int) (ship.getId());
	}

	private static int assembleAsync(final CommandContext<class_2168> context, final boolean hasSlug) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final class_3218 level = source.method_9225();
		final class_2338 from = class_2262.method_9696(context, "from");
		final class_2338 to = class_2262.method_9696(context, "to");
		final BlockSectionView blocks = new BlockSectionView(from, to);

		AssembleApi.createShipAsync(level, blocks, Integer.MAX_VALUE)
			.thenAccept((ship) -> {
				if (ship == null) {
					source.method_9213(class_2561.method_43471("vtil.command.assemble.empty"));
					return;
				}

				final String slug = hasSlug ? StringArgumentType.getString(context, "slug") : "+assemble+" + ship.getId();
				ship.setSlug(slug);
				source.method_9226(() -> class_2561.method_43469("vtil.command.assemble.success", slug), true);
			});
		return 1;
	}

	private static int delete(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_2168 source = context.getSource();
		final MinecraftServer server = source.method_9211();
		final ShipAllocator allocator = ShipAllocator.get(server);
		final Set<Ship> ships = ShipArgument.Companion.getShips((CommandContext<VSCommandSource>) ((CommandContext<?>) (context)), "ships");
		int successCount = 0;
		for (final Ship ship : ships) {
			if (!(ship instanceof ServerShip serverShip)) {
				continue;
			}
			final class_3218 level = LevelUtil.getLevel(serverShip.getChunkClaimDimension());
			if (level == null) {
				continue;
			}
			allocator.putShip(serverShip);
			successCount++;
		}
		final int finalSuccessCount = successCount;
		source.method_9226(() ->
			class_2561.method_43469("command.valkyrienskies.delete.success", finalSuccessCount),
			true
		);
		return finalSuccessCount;
	}
}
