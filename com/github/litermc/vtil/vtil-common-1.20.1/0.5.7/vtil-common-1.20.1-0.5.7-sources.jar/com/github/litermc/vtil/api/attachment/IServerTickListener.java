package com.github.litermc.vtil.api.attachment;

import net.minecraft.class_3218;
import org.valkyrienskies.core.api.ships.LoadedServerShip;

public interface IServerTickListener {
	void onServerTick(class_3218 level, LoadedServerShip ship);
}
