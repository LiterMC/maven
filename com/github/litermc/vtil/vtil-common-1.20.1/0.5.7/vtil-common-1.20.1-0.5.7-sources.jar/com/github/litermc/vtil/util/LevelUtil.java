package com.github.litermc.vtil.util;

import org.valkyrienskies.mod.common.VSGameUtilsKt;

import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_3218;

public final class LevelUtil {
	private LevelUtil() {}

	private static final ConcurrentHashMap<String, class_3218> ID_TO_LEVEL_CACHE = new ConcurrentHashMap<>();

	public static void onServerLevelLoad(final class_3218 level) {
		ID_TO_LEVEL_CACHE.put(VSGameUtilsKt.getDimensionId(level), level);
	}

	public static void onServerLevelUnload(final class_3218 level) {
		ID_TO_LEVEL_CACHE.remove(VSGameUtilsKt.getDimensionId(level), level);
	}

	public static class_3218 getLevel(final String dimId) {
		final class_3218 level = ID_TO_LEVEL_CACHE.get(dimId);
		if (level == null) {
			throw new IllegalStateException("Level " + dimId + " is not loaded.");
		}
		return level;
	}
}
