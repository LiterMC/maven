package com.github.litermc.vtil.api.teleport;

import com.github.litermc.vtil.api.entity.ISpecialTeleportLogicEntity;
import org.joml.Quaterniondc;
import org.joml.Vector3dc;
import org.valkyrienskies.core.api.ships.LoadedServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.internal.ShipTeleportData;
import org.valkyrienskies.core.internal.world.VsiServerShipWorld;
import org.valkyrienskies.mod.common.VSGameUtilsKt;
import org.valkyrienskies.mod.common.ValkyrienSkiesMod;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class TeleportUtil {
	/**
	 * Teleport a ship with velocity and omega.
	 *
	 * @param ship Teleporting ship
	 * @param data Teleport data
	 */
	public static void teleportShip(final LoadedServerShip ship, final TeleportData data) {
		final class_3218 level = data.level();
		final String dimension = VSGameUtilsKt.getDimensionId(level);
		final VsiServerShipWorld world = VSGameUtilsKt.getShipObjectWorld(level);

		final long id = ship.getId();

		final Vector3dc newPos = data.newPos();
		final Quaterniondc rotation = data.rotation();
		final Vector3dc velocity = data.velocity();
		final Vector3dc omega = data.omega();

		final ShipTeleportData teleportData = ValkyrienSkiesMod.getVsCore().newShipTeleportData(newPos, rotation, velocity, omega, dimension, null, ship.getTransform().getPositionInShip());
		world.teleportShip(ship, teleportData);
		if (velocity.lengthSquared() != 0 || omega.lengthSquared() != 0) {
			final ServerShipTransformProvider oldProvider = ship.getTransformProvider();
			ship.setTransformProvider(new ServerShipTransformProvider() {
				@Override
				public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform prevTransform, final ShipTransform transform) {
					final LoadedServerShip ship2 = world.getLoadedShips().getById(id);
					if (!prevTransform.getPositionInWorld().equals(transform.getPositionInWorld()) || !prevTransform.getShipToWorldRotation().equals(transform.getShipToWorldRotation())) {
						ship2.setTransformProvider(oldProvider);
						return null;
					}
					if (ship2.getVelocity().lengthSquared() == 0 && ship2.getOmega().lengthSquared() == 0) {
						return new NextTransformAndVelocityData(transform, velocity, omega);
					}
					return null;
				}
			});
		}
	}

	/**
	 * Teleport an entity to another dimension with its passengers
	 *
	 * @param <T>      The entity's type
	 * @param entity   The entity going to teleport
	 * @param newLevel Target level
	 * @param newPos   Target position
	 * @return Teleported entity, or {@code null} if teleportation failed.
	 */
	public static <T extends class_1297> T teleportEntity(final T entity, final class_3218 newLevel, final class_243 newPos) {
		return teleportEntity(entity, newLevel, newPos, false);
	}

	public static <T extends class_1297> T teleportEntity(final T entity, final class_3218 newLevel, final class_243 newPos, final boolean inner) {
		final class_243 oldPos = entity.method_19538();

		if (!inner && entity instanceof final ISpecialTeleportLogicEntity specialEntity) {
			specialEntity.beforeDimentionalTeleport();
		}

		final List<class_1297> passengers = List.copyOf(entity.method_5685());
		for (final class_1297 p : passengers) {
			if (p instanceof final ISpecialTeleportLogicEntity specialEntity) {
				specialEntity.beforeDimentionalTeleport();
			}
		}

		final T newEntity;
		if (entity instanceof final class_3222 player) {
			player.method_14251(newLevel, newPos.field_1352, newPos.field_1351, newPos.field_1350, player.method_36454(), player.method_36455());
			newEntity = entity;
		} else {
			newEntity = (T) entity.method_5864().method_5883(newLevel);
			if (newEntity == null) {
				if (entity instanceof final ISpecialTeleportLogicEntity specialEntity) {
					specialEntity.afterDimentionalTeleport(null);
				}
				return null;
			}
			entity.method_5772();
			newEntity.method_5878(entity);
			newEntity.method_5808(newPos.field_1352, newPos.field_1351, newPos.field_1350, newEntity.method_36454(), newEntity.method_36455());
			newEntity.method_5847(entity.method_5791());
			newEntity.method_5636(entity.method_43078());
			newLevel.method_18769(newEntity);
			entity.method_31745(class_1297.class_5529.field_27002);
		}

		for (final class_1297 p : passengers) {
			final class_1297 newPassenger = teleportEntity(p, newLevel, p.method_19538().method_1020(oldPos).method_1019(newPos), true);
			if (newPassenger != null) {
				newPassenger.method_5873(newEntity, true);
			}
		}
		if (newEntity instanceof final ISpecialTeleportLogicEntity specialEntity) {
			specialEntity.afterDimentionalTeleport((ISpecialTeleportLogicEntity) (entity));
		}
		return newEntity;
	}

	public record TeleportData(class_3218 level, Vector3dc newPos, Quaterniondc rotation, Vector3dc velocity, Vector3dc omega) {}
}
