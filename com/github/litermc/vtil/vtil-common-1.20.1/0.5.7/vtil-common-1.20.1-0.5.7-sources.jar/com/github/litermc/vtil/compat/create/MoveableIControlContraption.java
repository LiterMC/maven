package com.github.litermc.vtil.compat.create;

import com.github.litermc.vtil.accessor.ContraptionHolder;
import com.github.litermc.vtil.accessor.ControlledContraptionEntityAccessor;
import com.github.litermc.vtil.api.assemble.IMoveable;
import com.github.litermc.vtil.util.Pair;
import com.simibubi.create.content.contraptions.AbstractContraptionEntity;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_3218;

public class MoveableIControlContraption implements IMoveable<List<AbstractContraptionEntity>> {
	public static final MoveableIControlContraption INSTANCE = new MoveableIControlContraption();

	private MoveableIControlContraption() {}

	@Override
	public List<AbstractContraptionEntity> beforeMove(final class_3218 level, final class_2338 origin, final class_2338 target) {
		final class_2586 be = level.method_8321(origin);
		if (be instanceof final ContraptionHolder holder) {
			return holder.vtil$clearContraptions();
		}
		return null;
	}

	@Override
	public void afterMove(final class_3218 level, final class_2338 origin, final class_2338 target, List<AbstractContraptionEntity> data) {
		if (data == null) {
			return;
		}
		final class_2586 be = level.method_8321(target);
		final class_2382 offset = target.method_10059(origin);
		data = data.stream().map((entity) -> moveContraptionEntity(level, entity, offset)).toList();
		if (be instanceof final ContraptionHolder holder) {
			holder.vtil$restoreContraptions(data);
		}
	}

	public static AbstractContraptionEntity moveContraptionEntity(final class_3218 level, final AbstractContraptionEntity entity, final class_2382 offset) {
		if (entity == null) {
			return null;
		}
		final Contraption contraption = entity.getContraption();

		final List<Pair<class_1297, Integer>> passengers;
		if (contraption == null) {
			passengers = null;
		} else {
			passengers = new ArrayList<>(entity.method_5685().size());
			entity.method_5685().forEach((passenger) -> {
				final Integer seat = contraption.getSeatMapping().get(passenger.method_5667());
				if (seat != null) {
					passengers.add(new Pair<>(passenger, seat));
				}
			});
			entity.method_5772();

			contraption.anchor = contraption.anchor.method_10081(offset);
		}

		entity.method_33574(entity.method_19538().method_1031(offset.method_10263(), offset.method_10264(), offset.method_10260()));
		if (entity instanceof final ControlledContraptionEntityAccessor ccea) {
			ccea.vtil$setControllerPos(ccea.vtil$getControllerPos().method_10081(offset));
		}

		final AbstractContraptionEntity newEntity = (AbstractContraptionEntity) (entity.method_5864().method_5883(level));
		newEntity.method_5878(entity);

		if (contraption != null) {
			passengers.forEach((passenger) -> newEntity.addSittingPassenger(passenger.left(), passenger.right()));
		}

		entity.method_5650(class_1297.class_5529.field_27000);
		level.method_8649(newEntity);
		return newEntity;
	}
}
