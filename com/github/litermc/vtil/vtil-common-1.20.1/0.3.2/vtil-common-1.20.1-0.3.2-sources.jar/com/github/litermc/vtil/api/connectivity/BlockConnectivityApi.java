package com.github.litermc.vtil.api.connectivity;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3610;

public final class BlockConnectivityApi {
	private BlockConnectivityApi() {}

	/**
	 * Returns if the block is not possible to have any connection.
	 * E.g. air, flowing liquid.
	 *
	 * @param state The block state
	 * @return {@code true} if the block is not possible to have connection, {@code false} otherwise.
	 */
	public static final boolean isAir(final class_2680 state) {
		if (state.method_26215()) {
			return true;
		}
		if (state.method_26204() instanceof class_2404) {
			final class_3610 fluidState = state.method_26227();
			if (fluidState.method_15769() || !fluidState.method_15771()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if a block contains a fluid source (e.g. water logged).
	 * If so, then the block may be connected from all direction.
	 *
	 * @param state The block state
	 * @return if a block contains a fluid source.
	 */
	public static final boolean isFluidLogged(final class_2680 state) {
		return state.method_28498(class_2741.field_12508) && state.method_11654(class_2741.field_12508);
	}

	/**
	 * Get any possible connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getPossibleConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		if (isFluidLogged(state)) {
			// TODO: what if getConnectableBlocks provides more than direct neighbors?
			for (final class_2350 dir : class_2350.values()) {
				result.add(pos.method_10093(dir));
			}
			return;
		}
		final IBlockAnchor anchor = (IBlockAnchor) (state.method_26204());
		anchor.getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(final class_1936 level, final class_2338 pos, final Collection<class_2338> result) {
		final class_2680 state = level.method_8320(pos);
		if (isAir(state)) {
			return;
		}
		getConnectableBlocks(level, pos, state, result);
	}

	/**
	 * Get all connectable blocks from a block.
	 * Should not be invoked if {@link isAir} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, should not be any air.
	 * @param result The result holder.
	 */
	public static final void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		getPossibleConnectableBlocks(level, pos, state, result);
		result.removeIf((p) -> {
			final class_2680 s = level.method_8320(p);
			return isAir(s) || !isBlockConnectable0(level, p, s, pos, state);
		});
	}

	/**
	 * Check if two blocks are connectable.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2338 targetPos
	) {
		final class_2680 state = level.method_8320(pos);
		if (isAir(state)) {
			return false;
		}
		final class_2680 targetState = level.method_8320(targetPos);
		if (isAir(targetState)) {
			return false;
		}
		return isBlockConnectable(level, pos, state, targetPos, targetState);
	}

	/**
	 * Check if two blocks are connectable.
	 * Should not be invoked if either block is air.
	 *
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	public static final boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return
			isBlockConnectable0(level, pos, state, targetPos, targetState) &&
			isBlockConnectable0(level, targetPos, targetState, pos, state);
	}

	private static final boolean isBlockConnectable0(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return
			isFluidLogged(state) ||
			((IBlockAnchor) (state.method_26204())).isBlockConnectable(level, pos, state, targetPos, targetState);
	}

	/**
	 * Check if connectable blocks will change.
	 *
	 * @param level    World the block is in.
	 * @param pos      Position of the block.
	 * @param oldState Previous block state.
	 * @param newState Current block state.
	 */
	public static boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 newState
	) {
		if (oldState == newState) {
			return false;
		}
		if (isFluidLogged(oldState) && isFluidLogged(newState)) {
			return false;
		}
		final boolean wasAir = isAir(oldState);
		if (wasAir != isAir(newState)) {
			return true;
		}
		if (wasAir) {
			return false;
		}
		final IBlockAnchor anchor = (IBlockAnchor) (newState.method_26204());
		return anchor.willConnectivityChange(level, pos, oldState, newState);
	}

}
