package com.github.litermc.vtil.mixin.create;

import com.github.litermc.vtil.accessor.ControlledContraptionEntityAccessor;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;

@Pseudo
@Mixin(ControlledContraptionEntity.class)
public class MixinControlledContraptionEntity implements ControlledContraptionEntityAccessor {
	@Shadow(remap = false)
	protected class_2338 controllerPos;

	@Override
	public class_2338 vtil$getControllerPos() {
		return this.controllerPos;
	}

	@Override
	public void vtil$setControllerPos(class_2338 pos) {
		this.controllerPos = pos;
	}
}
