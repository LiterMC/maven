package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_5172;

@Mixin(class_5172.class)
public abstract class MixinChainBlock extends class_2248 implements IBlockAnchor {
	protected MixinChainBlock() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		switch (state.method_11654(class_2741.field_12496)) {
			case field_11048 -> {
				result.add(pos.method_10093(class_2350.field_11039));
				result.add(pos.method_10093(class_2350.field_11034));
			}
			case field_11052 -> {
				result.add(pos.method_10093(class_2350.field_11033));
				result.add(pos.method_10093(class_2350.field_11036));
			}
			case field_11051 -> {
				result.add(pos.method_10093(class_2350.field_11043));
				result.add(pos.method_10093(class_2350.field_11035));
			}
		}
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		final int xDiff = targetPos.method_10263() - pos.method_10263();
		final int yDiff = targetPos.method_10264() - pos.method_10264();
		final int zDiff = targetPos.method_10260() - pos.method_10260();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final class_2350 dir = class_2350.method_50026(xDiff, yDiff, zDiff);
		return dir.method_10166() == state.method_11654(class_2741.field_12496);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.method_26204().getClass() != this.getClass()) {
			return true;
		}
		return oldState.method_11654(class_2741.field_12496) != state.method_11654(class_2741.field_12496);
	}
}
