package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.BasicNeighbourBlockAnchor;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2349.class)
public abstract class MixinFenceGateBlock extends class_2248 implements BasicNeighbourBlockAnchor {
	protected MixinFenceGateBlock() {
		super(null);
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		final int xDiff = targetPos.method_10263() - pos.method_10263();
		final int yDiff = targetPos.method_10264() - pos.method_10264();
		final int zDiff = targetPos.method_10260() - pos.method_10260();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final class_2350 dir = class_2350.method_50026(xDiff, yDiff, zDiff);
		final class_2350 facing = state.method_11654(class_2383.field_11177);
		return switch (dir) {
			case field_11036, field_11033 -> true;
			default -> dir != facing && dir != facing.method_10153();
		};
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		return oldState.method_26204().getClass() != this.getClass();
	}
}
