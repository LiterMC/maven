package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.BasicNeighbourBlockAnchor;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_4970.class)
public abstract class MixinBlockBehaviour implements BasicNeighbourBlockAnchor {
}
