package com.github.litermc.vtil.util;

import org.valkyrienskies.mod.common.VSGameUtilsKt;

import java.util.HashMap;
import net.minecraft.class_3218;

public final class LevelUtil {
	private LevelUtil() {}

	private static final HashMap<String, class_3218> ID_TO_LEVEL_CACHE = new HashMap<>();

	public static void onServerLevelLoad(final class_3218 level) {
		ID_TO_LEVEL_CACHE.put(VSGameUtilsKt.getDimensionId(level), level);
	}

	public static void onServerLevelUnload(final class_3218 level) {
		ID_TO_LEVEL_CACHE.remove(VSGameUtilsKt.getDimensionId(level), level);
	}

	public static class_3218 getLevel(final String dimId) {
		return ID_TO_LEVEL_CACHE.get(dimId);
	}
}
