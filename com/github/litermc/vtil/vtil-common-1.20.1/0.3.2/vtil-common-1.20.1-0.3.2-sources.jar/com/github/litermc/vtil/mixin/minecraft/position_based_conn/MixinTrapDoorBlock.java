package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.BasicNeighbourBlockAnchor;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2760;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2533.class)
public abstract class MixinTrapDoorBlock extends class_2248 implements BasicNeighbourBlockAnchor {
	protected MixinTrapDoorBlock() {
		super(null);
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		final int xDiff = targetPos.method_10263() - pos.method_10263();
		final int yDiff = targetPos.method_10264() - pos.method_10264();
		final int zDiff = targetPos.method_10260() - pos.method_10260();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final class_2350 dir = class_2350.method_50026(xDiff, yDiff, zDiff);
		final boolean isOpen = state.method_11654(class_2741.field_12537);
		return switch (dir) {
			case field_11036 -> isOpen || state.method_11654(class_2741.field_12518) == class_2760.field_12619;
			case field_11033 -> isOpen || state.method_11654(class_2741.field_12518) == class_2760.field_12617;
			default -> !isOpen || state.method_11654(class_2383.field_11177) != dir;
		};
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		return oldState != state;
	}
}
