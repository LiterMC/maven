package com.github.litermc.vtil.accessor;

import net.minecraft.class_2338;

public interface ControlledContraptionEntityAccessor {
	class_2338 vtil$getControllerPos();

	void vtil$setControllerPos(class_2338 pos);
}
