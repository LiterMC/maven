package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2341;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

@Mixin(class_2341.class)
public abstract class MixinFaceAttachedHorizontalDirectionalBlock extends class_2248 implements IBlockAnchor {
	protected MixinFaceAttachedHorizontalDirectionalBlock() {
		super(null);
	}

	@Shadow
	protected static class_2350 getConnectedDirection(class_2680 state) {
		return null;
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		result.add(pos.method_10093(getConnectedDirection(state).method_10153()));
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return pos.method_10093(getConnectedDirection(state).method_10153()).equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.method_26204() != this) {
			return true;
		}
		return getConnectedDirection(oldState) != getConnectedDirection(state);
	}
}
