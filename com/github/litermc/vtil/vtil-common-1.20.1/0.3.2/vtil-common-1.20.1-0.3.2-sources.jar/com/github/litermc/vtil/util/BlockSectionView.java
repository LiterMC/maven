package com.github.litermc.vtil.util;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import net.minecraft.class_2338;

public final class BlockSectionView extends AbstractSet<class_2338> {
	private final class_2338 min;
	private final class_2338 max;
	private final int count;
	private final Iterable<class_2338> iterable;

	public BlockSectionView(final class_2338 pos1, final class_2338 pos2) {
		final int minX = Math.min(pos1.method_10263(), pos2.method_10263());
		final int minY = Math.min(pos1.method_10264(), pos2.method_10264());
		final int minZ = Math.min(pos1.method_10260(), pos2.method_10260());
		final int maxX = Math.max(pos1.method_10263(), pos2.method_10263());
		final int maxY = Math.max(pos1.method_10264(), pos2.method_10264());
		final int maxZ = Math.max(pos1.method_10260(), pos2.method_10260());
		this.min = new class_2338(
			Math.min(pos1.method_10263(), pos2.method_10263()),
			Math.min(pos1.method_10264(), pos2.method_10264()),
			Math.min(pos1.method_10260(), pos2.method_10260())
		);
		this.max = new class_2338(
			Math.max(pos1.method_10263(), pos2.method_10263()),
			Math.max(pos1.method_10264(), pos2.method_10264()),
			Math.max(pos1.method_10260(), pos2.method_10260())
		);
		this.count = (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
		this.iterable = class_2338.method_10094(minX, minY, minZ, maxX, maxY, maxZ);
	}

	@Override
	public int size() {
		return this.count;
	}

	@Override
	public Iterator<class_2338> iterator() {
		return this.iterable.iterator();
	}

	@Override
	public boolean contains(Object obj) {
		if (!(obj instanceof final class_2338 pos)) {
			return false;
		}
		return
			this.min.method_10263() <= pos.method_10263() && pos.method_10263() <= this.max.method_10263() &&
			this.min.method_10264() <= pos.method_10264() && pos.method_10264() <= this.max.method_10264() &&
			this.min.method_10260() <= pos.method_10260() && pos.method_10260() <= this.max.method_10260();
	}

	@Override
	public boolean containsAll(final Collection<?> collections) {
		if (!(collections instanceof final BlockSectionView view)) {
			return super.containsAll(collections);
		}
		return
			this.min.method_10263() <= view.min.method_10263() && this.min.method_10264() <= view.min.method_10264() && this.min.method_10260() <= view.min.method_10260() &&
			this.max.method_10263() >= view.max.method_10263() && this.max.method_10264() >= view.max.method_10264() && this.max.method_10260() >= view.max.method_10260();
	}
}
