package com.github.litermc.vtil.mixin.create;

import com.github.litermc.vtil.api.assemble.IMoveable;
import com.simibubi.create.content.kinetics.belt.BeltBlockEntity;
import com.simibubi.create.content.kinetics.belt.transport.BeltInventory;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;

@Pseudo
@Mixin(BeltBlockEntity.class)
public abstract class MixinBeltBlockEntity extends MixinKineticBlockEntity implements IMoveable {
	@Shadow(remap = false)
	protected class_2338 controller;

	@Shadow(remap = false)
	public abstract boolean isController();

	@Shadow(remap = false)
	public abstract BeltInventory getInventory();

	@Override
	public Object beforeMove(class_3218 level, class_2338 origin, class_2338 target) {
		super.beforeMove(level, origin, target);
		if (this.isController()) {
			this.getInventory().getTransportedItems().clear();
		}
		return null;
	}

	@Override
	public void afterMove(class_3218 level, class_2338 origin, class_2338 target, Object data) {
		super.afterMove(level, origin, target, null);
		if (this.controller != null && !this.controller.equals(class_2338.field_10980) && !this.isController()) {
			this.controller = this.controller.method_10059(origin).method_10081(target);
		}
	}
}
