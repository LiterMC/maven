package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2577;
import net.minecraft.class_2680;
import net.minecraft.class_3922;

@Mixin({
	class_3922.class,
	class_2577.class
})
public abstract class MixinOnlyNoCeilSupportedBlocks extends class_2248 implements IBlockAnchor {
	protected MixinOnlyNoCeilSupportedBlocks() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		for (final class_2350 dir : class_2350.values()) {
			if (dir != class_2350.field_11036) {
				result.add(pos.method_10093(dir));
			}
		}
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		final int xDiff = targetPos.method_10263() - pos.method_10263();
		final int yDiff = targetPos.method_10264() - pos.method_10264();
		final int zDiff = targetPos.method_10260() - pos.method_10260();
		if (Math.abs(xDiff) + Math.abs(yDiff) + Math.abs(zDiff) != 1) {
			return false;
		}
		final class_2350 dir = class_2350.method_50026(xDiff, yDiff, zDiff);
		return dir != class_2350.field_11036;
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		return oldState.method_26204().getClass() != this.getClass();
	}
}
