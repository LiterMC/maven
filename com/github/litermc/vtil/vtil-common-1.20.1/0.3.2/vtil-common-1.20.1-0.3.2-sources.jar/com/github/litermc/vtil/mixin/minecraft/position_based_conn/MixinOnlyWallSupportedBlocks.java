package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2222;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_2546;
import net.minecraft.class_2555;
import net.minecraft.class_2680;

@Mixin({
	class_2222.class,
	class_2546.class,
	class_2555.class
})
public abstract class MixinOnlyWallSupportedBlocks extends class_2248 implements IBlockAnchor {
	protected MixinOnlyWallSupportedBlocks() {
		super(null);
	}

	@Unique
	private static class_2338 getWallPos(final class_2338 pos, final class_2680 state) {
		return pos.method_10093(state.method_11654(class_2383.field_11177).method_10153());
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		result.add(getWallPos(pos, state));
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return getWallPos(pos, state).equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.method_26204().getClass() != this.getClass()) {
			return true;
		}
		return oldState.method_11654(class_2383.field_11177) != state.method_11654(class_2383.field_11177);
	}
}
