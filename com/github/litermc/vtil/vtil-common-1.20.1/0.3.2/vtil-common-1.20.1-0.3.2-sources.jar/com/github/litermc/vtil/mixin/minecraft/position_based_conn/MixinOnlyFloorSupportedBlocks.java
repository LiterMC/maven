package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2202;
import net.minecraft.class_2211;
import net.minecraft.class_2215;
import net.minecraft.class_2230;
import net.minecraft.class_2231;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2272;
import net.minecraft.class_2312;
import net.minecraft.class_2338;
import net.minecraft.class_2457;
import net.minecraft.class_2527;
import net.minecraft.class_2542;
import net.minecraft.class_2680;
import net.minecraft.class_5540;

@Mixin({
	class_5540.class,
	class_2202.class,
	class_2211.class,
	class_2215.class,
	class_2230.class,
	class_2231.class,
	class_2261.class,
	class_2272.class,
	class_2312.class,
	class_2457.class,
	class_2527.class,
	class_2542.class
})
public abstract class MixinOnlyFloorSupportedBlocks extends class_2248 implements IBlockAnchor {
	protected MixinOnlyFloorSupportedBlocks() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		result.add(pos.method_10074());
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return pos.method_10074().equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		return oldState.method_26204().getClass() != this.getClass();
	}
}
