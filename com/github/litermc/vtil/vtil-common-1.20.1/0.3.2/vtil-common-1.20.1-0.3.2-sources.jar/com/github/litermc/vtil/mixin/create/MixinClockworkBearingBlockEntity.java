package com.github.litermc.vtil.mixin.create;

import com.github.litermc.vtil.api.assemble.IMoveable;
import com.github.litermc.vtil.compat.create.MoveableIControlContraption;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.bearing.ClockworkBearingBlockEntity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

@Pseudo
@Mixin(ClockworkBearingBlockEntity.class)
public abstract class MixinClockworkBearingBlockEntity extends MixinKineticBlockEntity implements IMoveable {
	@Shadow(remap = false)
	protected ControlledContraptionEntity hourHand;

	@Shadow(remap = false)
	protected ControlledContraptionEntity minuteHand;

	@Override
	public Object beforeMove(class_3218 level, class_2338 origin, class_2338 target) {
		super.beforeMove(level, origin, target);
		final List<ControlledContraptionEntity> res =
			this.hourHand == null
				? this.minuteHand == null ? List.of() : List.of(this.minuteHand)
				: this.minuteHand == null ? List.of(this.hourHand) : List.of(this.hourHand, this.minuteHand);
		this.hourHand = null;
		this.minuteHand = null;
		return res;
	}

	@Override
	public void afterMove(class_3218 level, class_2338 origin, class_2338 target, Object data) {
		super.afterMove(level, origin, target, null);
		final class_2338 offset = target.method_10059(origin);
		for (final ControlledContraptionEntity entity : (List<ControlledContraptionEntity>) (data)) {
			MoveableIControlContraption.moveContraptionEntity(level, entity, offset);
		}
	}
}
