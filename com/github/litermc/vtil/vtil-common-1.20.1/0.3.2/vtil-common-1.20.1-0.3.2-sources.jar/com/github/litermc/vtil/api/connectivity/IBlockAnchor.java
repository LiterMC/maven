package com.github.litermc.vtil.api.connectivity;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * IBlockAnchor defines the interface for advanced block connectivity logic.
 */
public interface IBlockAnchor {
	/**
	 * Get all connectable blocks from current block.
	 * Will never be invoked if {@code BlockState.isAir()} returns {@code true}.
	 * All results should be add into the result collection.
	 *
	 * @param level  World the block is in.
	 * @param pos    Position of the block.
	 * @param state  The block state, will never be any air.
	 * @param result The result holder, must provides immutable {@link class_2338}es.
	 */
	void getConnectableBlocks(class_1936 level, class_2338 pos, class_2680 state, Collection<class_2338> result);

	/**
	 * Check if the target block is connectable.
	 * It must returns {@code true} if the block pos is a result from {@link getConnectableBlocks}.
	 * It must returns {@code false} if the block pos is not a result from {@link getConnectableBlocks}.
	 * @param level       World the block is in.
	 * @param pos         Position of the block.
	 * @param state       The block state, will never be any air.
	 * @param targetPos   Position of target block.
	 * @param targetState Target block state, will never be any air.
	 */
	boolean isBlockConnectable(class_1936 level, class_2338 pos, class_2680 state, class_2338 targetPos, class_2680 targetState);

	/**
	 * Check if connectable blocks will change.
	 * Will only be invoked if both states' {@code isAir()} returns {@code false}.
	 *
	 * @param level    World the block is in.
	 * @param pos      Position of the block.
	 * @param oldState Previous block state, will never be any air.
	 * @param state    Current block state, will never be any air.
	 */
	default boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		return oldState != state;
	}
}
