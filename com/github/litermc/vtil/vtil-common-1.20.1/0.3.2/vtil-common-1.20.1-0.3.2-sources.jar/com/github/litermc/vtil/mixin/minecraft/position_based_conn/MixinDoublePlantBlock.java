package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2756;

@Mixin(class_2320.class)
public abstract class MixinDoublePlantBlock extends class_2248 implements IBlockAnchor {
	protected MixinDoublePlantBlock() {
		super(null);
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		result.add(pos.method_10074());
		if (state.method_11654(class_2320.field_10929) == class_2756.field_12607) {
			result.add(pos.method_10084());
		}
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return
			pos.method_10074().equals(targetPos) ||
			state.method_11654(class_2320.field_10929) == class_2756.field_12607 && pos.method_10084().equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.method_26204().getClass() != this.getClass()) {
			return true;
		}
		return oldState.method_11654(class_2320.field_10929) != state.method_11654(class_2320.field_10929);
	}
}

