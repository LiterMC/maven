package com.github.litermc.vtil.mixin.create;

import com.github.litermc.vtil.api.assemble.IMoveable;
import com.github.litermc.vtil.compat.create.MoveableIControlContraption;
import com.simibubi.create.content.contraptions.ControlledContraptionEntity;
import com.simibubi.create.content.contraptions.bearing.MechanicalBearingBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;

@Pseudo
@Mixin(MechanicalBearingBlockEntity.class)
public abstract class MixinMechanicalBearingBlockEntity extends MixinKineticBlockEntity implements IMoveable {
	@Shadow(remap = false)
	protected ControlledContraptionEntity movedContraption;

	@Override
	public Object beforeMove(class_3218 level, class_2338 origin, class_2338 target) {
		super.beforeMove(level, origin, target);
		final ControlledContraptionEntity res = this.movedContraption;
		this.movedContraption = null;
		return res;
	}

	@Override
	public void afterMove(class_3218 level, class_2338 origin, class_2338 target, Object data) {
		super.afterMove(level, origin, target, null);
		final class_2338 offset = target.method_10059(origin);
		MoveableIControlContraption.moveContraptionEntity(level, (ControlledContraptionEntity) (data), offset);
	}
}
