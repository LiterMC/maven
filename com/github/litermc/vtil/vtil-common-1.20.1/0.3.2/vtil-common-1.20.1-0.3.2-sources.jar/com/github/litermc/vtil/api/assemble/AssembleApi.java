package com.github.litermc.vtil.api.assemble;

import com.github.litermc.vtil.compat.CompatMods;
import com.github.litermc.vtil.util.Pair;
import org.joml.Quaterniond;
import org.joml.RoundingMode;
import org.joml.Vector3d;
import org.joml.Vector3i;
import org.joml.primitives.AABBd;
import org.joml.primitives.AABBic;
import org.valkyrienskies.core.api.ships.ServerShip;
import org.valkyrienskies.core.api.ships.ServerShipTransformProvider;
import org.valkyrienskies.core.api.ships.properties.ShipTransform;
import org.valkyrienskies.core.apigame.world.ServerShipWorldCore;
import org.valkyrienskies.core.impl.game.ShipTeleportDataImpl;
import org.valkyrienskies.core.impl.game.ships.ShipTransformImpl;
import org.valkyrienskies.core.util.datastructures.DenseBlockPosSet;
import org.valkyrienskies.mod.common.VSGameUtilsKt;

import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.contraptions.glue.SuperGlueEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_1530;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3829;

public final class AssembleApi {
	private AssembleApi() {}

	/**
	 * Assemble a ship with given blockset.
	 *
	 * @param level    World the blocks are in.
	 * @param slug     Slug for the assembling ship.
	 * @param blocks   Block set to assemble, must contains at least one non-air block.
	 * @param rootShip Root ship for the assembling ship, or {@code null}. Rotation, velocity, scale, etc. will be extended.
	 * @return The instance for created ship.
	 */
	public static ServerShip createShip(
		final class_3218 level,
		final Set<class_2338> blocks,
		final ServerShip rootShip
	) {
		final class_2680 AIR = class_2246.field_10124.method_9564();
		final ServerShipWorldCore shipWorld = VSGameUtilsKt.getShipObjectWorld(level);
		final String levelId = VSGameUtilsKt.getDimensionId(level);

		final AABBd blocksBox = new AABBd();
		{
			final class_2338 pos = blocks.iterator().next();
			blocksBox.setMin(pos.method_10263(), pos.method_10264(), pos.method_10260()).setMax(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		for (final class_2338 pos : blocks) {
			blocksBox.union(pos.method_10263(), pos.method_10264(), pos.method_10260());
		}
		blocksBox.maxX += 1;
		blocksBox.maxY += 1;
		blocksBox.maxZ += 1;

		final Vector3i worldCenter = new Vector3i(blocksBox.center(new Vector3d()), RoundingMode.TRUNCATE);
		final ServerShip ship = shipWorld.createNewShipAtBlock(worldCenter, false, 1.0, levelId);
		final Vector3i shipCenter = ship.getChunkClaim().getCenterBlockCoordinates(VSGameUtilsKt.getYRange(level), new Vector3i());
		final Vector3i offset = shipCenter.sub(worldCenter, new Vector3i());
		final Map<class_2338, class_2680> blockStates = new HashMap<>(blocks.size());
		final List<class_1297> entities = new ArrayList<>();

		// get attachable entities
		for (final class_1297 entity : level.method_8335(null, new class_238(blocksBox.minX - 1, blocksBox.minY - 1, blocksBox.minZ - 1, blocksBox.maxX + 2, blocksBox.maxY + 2, blocksBox.maxZ + 2))) {
			if (entity instanceof final class_1530 he) {
				final class_2338 hanging = he.method_6896().method_10093(he.method_5735().method_10153());
				if (blocks.contains(hanging)) {
					entities.add(entity);
				}
			} else if (CompatMods.CREATE.isLoaded()) {
				if (entity instanceof final SeatEntity seat) {
					if (blocks.contains(seat.method_24515())) {
						entities.add(entity);
					}
				} else if (entity instanceof final SuperGlueEntity glue) {
					final class_238 bb = glue.method_5829();
					if (streamBlocksInAABB(bb).anyMatch(blocks::contains)) {
						entities.add(entity);
					}
				}
			}
		}

		// move blocks
		for (final class_2338 pos : blocks) {
			final class_2338 target = pos.method_10069(offset.x, offset.y, offset.z);
			final class_2680 oldState = level.method_8320(pos);
			final boolean wasAir = oldState.method_26215();

			final class_2586 be = level.method_8321(pos);
			IMoveable<?> moveableOld = MoveApi.getMover(be);
			if (moveableOld == null) {
				moveableOld = MoveApi.getMover(oldState.method_26204());
			}
			if (moveableOld != null) {
				moveableOld.beforeSaveForMove(level, pos, target);
			}

			final class_2680 state = level.method_8320(pos);
			if (wasAir && moveableOld == null && state == oldState) {
				continue;
			}

			blockStates.put(pos.method_10062(), state);
			final class_2487 nbt = level.method_8500(pos).method_20598(pos);
			if (nbt != null) {
				final class_2338 targetPos = pos.method_10069(offset.x, offset.y, offset.z);
				nbt.method_10569("x", targetPos.method_10263());
				nbt.method_10569("y", targetPos.method_10264());
				nbt.method_10569("z", targetPos.method_10260());
				level.method_8500(targetPos).method_12042(nbt);
			}

			class_3829.method_16825(be);

			final Object moveData = moveableOld != null ? moveableOld.beforeMove(level, pos, target) : null;

			// Note: Block.UPDATE_SUPPRESS_DROPS only works for Level.destroyBlock which drop the block's item form,
			// and it does not prevent contents from dropping.
			level.method_8652(pos, AIR, class_2248.field_31028 | class_2248.field_31031 | class_2248.field_31033);

			level.method_8652(target, state, class_2248.field_31028 | class_2248.field_31031 | class_2248.field_31033);
			IMoveable<?> moveableNew = MoveApi.getMover(level.method_8321(target));
			if (moveableNew == null) {
				moveableNew = MoveApi.getMover(state.method_26204());
			}
			if (moveableNew != null) {
				((IMoveable) (moveableNew)).afterMove(level, pos, target, moveData);
			}
		}

		if (blockStates.isEmpty()) {
			// No block present
			shipWorld.deleteShip(ship);
			return null;
		}

		// move entities
		for (final class_1297 entity : entities) {
			final class_243 pos = entity.method_19538();
			entity.method_5814(pos.field_1352 + offset.x, pos.field_1351 + offset.y, pos.field_1350 + offset.z);
		}

		final int MAX_BLOCK_UPDATE = 512 - 1;
		final int BLOCK_UPDATE_FLAGS = class_2248.field_31027 | class_2248.field_31033;

		// update blocks
		final DenseBlockPosSet tickedAirs = new DenseBlockPosSet();
		final class_2338.class_2339 airPos = new class_2338.class_2339();
		for (final Map.Entry<class_2338, class_2680> entry : blockStates.entrySet()) {
			final class_2338 pos = entry.getKey();
			final class_2680 state = entry.getValue();
			final class_2248 block = state.method_26204();
			final class_2338 targetPos = pos.method_10069(offset.x, offset.y, offset.z);
			level.method_8408(pos, block);
			state.method_26198(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			AIR.method_26183(level, pos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.method_19282(pos, state, AIR);

			level.method_8408(targetPos, block);
			state.method_26183(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			state.method_26198(level, targetPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			level.method_19282(targetPos, AIR, state);

			for (final class_2350 dir : class_2350.values()) {
				airPos.method_25505(targetPos, dir);
				if (blockStates.containsKey(airPos) || !tickedAirs.add(airPos.method_10263(), airPos.method_10264(), airPos.method_10260())) {
					continue;
				}
				AIR.method_26183(level, airPos, BLOCK_UPDATE_FLAGS, MAX_BLOCK_UPDATE);
			}
		}

		final Vector3d absPosition = ship.getTransform().getPositionInWorld().add(ship.getInertiaData().getCenterOfMassInShip(), new Vector3d()).sub(shipCenter.x, shipCenter.y, shipCenter.z);
		final Vector3d position = new Vector3d(absPosition);
		final Quaterniond rotation = new Quaterniond();
		final Vector3d velocity = new Vector3d();
		final Vector3d omega = new Vector3d();
		final Vector3d scaling = new Vector3d(1);
		double scale = 1.0;

		if (rootShip != null) {
			final ShipTransform selfTransform = rootShip.getTransform();
			selfTransform.getShipToWorld().transformPosition(position);
			rotation.set(selfTransform.getShipToWorldRotation());
			velocity.set(rootShip.getVelocity());
			omega.set(rootShip.getOmega());
			scaling.set(selfTransform.getShipToWorldScaling());
			scale = Math.sqrt(scaling.lengthSquared() / 3);
		}
		shipWorld.teleportShip(ship, new ShipTeleportDataImpl(position, rotation, velocity, omega, levelId, scale));

		// fix new ship's velocity and omega
		if (velocity.lengthSquared() != 0 || omega.lengthSquared() != 0) {
			final ServerShipTransformProvider oldProvider = ship.getTransformProvider();
			ship.setTransformProvider(new ServerShipTransformProvider() {
				@Override
				public NextTransformAndVelocityData provideNextTransformAndVelocity(final ShipTransform transform, final ShipTransform nextTransform) {
					if (!transform.getPositionInWorld().equals(nextTransform.getPositionInWorld()) || !transform.getShipToWorldRotation().equals(nextTransform.getShipToWorldRotation())) {
						ship.setTransformProvider(oldProvider);
						return null;
					}
					if (rootShip != null) {
						final ShipTransform selfTransform2 = rootShip.getTransform();
						selfTransform2.getShipToWorld().transformPosition(absPosition, position);
						rotation.set(selfTransform2.getShipToWorldRotation());
						velocity.set(rootShip.getVelocity());
						omega.set(rootShip.getOmega());
						scaling.set(selfTransform2.getShipToWorldScaling());
					}
					return new NextTransformAndVelocityData(new ShipTransformImpl(position, nextTransform.getPositionInShip(), rotation, scaling), velocity, omega);
				}
			});
		}
		return ship;
	}

	private static Stream<class_2338> streamBlocksInAABB(class_238 box) {
		final int
			minX = (int) (Math.round(box.field_1323)), maxX = (int) (Math.round(box.field_1320)),
			minY = (int) (Math.round(box.field_1322)), maxY = (int) (Math.round(box.field_1325)),
			minZ = (int) (Math.round(box.field_1321)), maxZ = (int) (Math.round(box.field_1324));
		final int widthX = maxX - minX, widthY = maxY - minY, widthZ = maxZ - minZ;
		return IntStream.range(0, widthX * widthY * widthZ).mapToObj((i) -> {
			final int x = i % widthX + minX;
			i /= widthX;
			final int z = i % widthZ + minZ;
			i /= widthZ;
			final int y = i + minY;
			return new class_2338(x, y, z);
		});
	}
}
