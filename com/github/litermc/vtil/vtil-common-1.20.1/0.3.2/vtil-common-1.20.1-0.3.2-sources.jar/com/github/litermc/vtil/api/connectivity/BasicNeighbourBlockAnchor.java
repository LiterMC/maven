package com.github.litermc.vtil.api.connectivity;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;

/**
 * A simple block anchor implemention that consider any direct neighbour as connectable.
 * It is by default implemented on {@link class_4970}.
 */
public interface BasicNeighbourBlockAnchor extends IBlockAnchor {
	@Override
	default void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		for (final class_2350 dir : class_2350.values()) {
			final class_2338 p = pos.method_10093(dir);
			if (this.isBlockConnectable(level, pos, state, p, level.method_8320(p))) {
				result.add(p);
			}
		}
	}

	@Override
	default boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return pos.method_19455(targetPos) == 1;
	}

	@Override
	default boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		final class_2338.class_2339 p = new class_2338.class_2339();
		for (final class_2350 dir : class_2350.values()) {
			p.method_25505(pos, dir);
			final class_2680 s = level.method_8320(p);
			if (((IBlockAnchor) (oldState.method_26204())).isBlockConnectable(level, pos, oldState, p, s) != this.isBlockConnectable(level, pos, state, p, s)) {
				return true;
			}
		}
		return false;
	}
}
