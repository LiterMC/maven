package com.github.litermc.vtil.mixin.minecraft.position_based_conn;

import com.github.litermc.vtil.api.connectivity.IBlockAnchor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Collection;
import net.minecraft.class_1936;
import net.minecraft.class_2195;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2383;
import net.minecraft.class_2680;

@Mixin(class_2195.class)
public abstract class MixinAttachedStemBlock extends class_2248 implements IBlockAnchor {
	protected MixinAttachedStemBlock() {
		super(null);
	}

	@Unique
	private static class_2338 getAttachingPos(final class_2338 pos, final class_2680 state) {
		return pos.method_10093(state.method_11654(class_2383.field_11177));
	}

	@Override
	public void getConnectableBlocks(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final Collection<class_2338> result
	) {
		result.add(pos.method_10074());
		result.add(getAttachingPos(pos, state));
	}

	@Override
	public boolean isBlockConnectable(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 state,
		final class_2338 targetPos,
		final class_2680 targetState
	) {
		return pos.method_10074().equals(targetPos) || getAttachingPos(pos, state).equals(targetPos);
	}

	@Override
	public boolean willConnectivityChange(
		final class_1936 level,
		final class_2338 pos,
		final class_2680 oldState,
		final class_2680 state
	) {
		if (oldState == state) {
			return false;
		}
		if (oldState.method_26204().getClass() != this.getClass()) {
			return true;
		}
		return oldState.method_11654(class_2383.field_11177) != state.method_11654(class_2383.field_11177);
	}
}
