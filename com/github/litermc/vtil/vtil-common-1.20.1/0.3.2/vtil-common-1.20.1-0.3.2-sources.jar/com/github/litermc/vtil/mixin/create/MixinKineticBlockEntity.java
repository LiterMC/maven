package com.github.litermc.vtil.mixin.create;

import com.github.litermc.vtil.api.assemble.IMoveable;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.Shadow;

@Pseudo
@Mixin(KineticBlockEntity.class)
public abstract class MixinKineticBlockEntity implements IMoveable {
	@Shadow(remap = false)
	public class_2338 source;

	@Override
	public Object beforeMove(class_3218 level, class_2338 origin, class_2338 target) {
		return null;
	}

	@Override
	public void afterMove(class_3218 level, class_2338 origin, class_2338 target, Object data) {
		if (this.source != null) {
			this.source = this.source.method_10059(origin).method_10081(target);
		}
	}
}
